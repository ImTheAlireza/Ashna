<?php
/**
 * Authentication, Unified Login/Registration, Password Fallback & AJAX Handlers
 *
 * @package Ashna
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Ashna_Auth {

	/**
	 * Singleton instance
	 *
	 * @var Ashna_Auth|null
	 */
	private static $instance = null;

	/**
	 * Get instance
	 *
	 * @return Ashna_Auth
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor
	 */
	private function __construct() {
		add_action( 'wp_ajax_nopriv_ashna_request_otp', array( $this, 'ajax_request_otp' ) );
		add_action( 'wp_ajax_ashna_request_otp', array( $this, 'ajax_request_otp' ) );

		add_action( 'wp_ajax_nopriv_ashna_verify_otp', array( $this, 'ajax_verify_otp' ) );
		add_action( 'wp_ajax_ashna_verify_otp', array( $this, 'ajax_verify_otp' ) );

		add_action( 'wp_ajax_nopriv_ashna_password_login', array( $this, 'ajax_password_login' ) );
		add_action( 'wp_ajax_ashna_password_login', array( $this, 'ajax_password_login' ) );
	}

	/**
	 * Send clean JSON error response
	 *
	 * @param array $data Error payload.
	 */
	private function send_error( $data ) {
		if ( ob_get_length() ) {
			ob_clean();
		}
		wp_send_json_error( $data );
	}

	/**
	 * Send clean JSON success response
	 *
	 * @param array $data Success payload.
	 */
	private function send_success( $data ) {
		if ( ob_get_length() ) {
			ob_clean();
		}
		wp_send_json_success( $data );
	}

	/**
	 * Handle AJAX Request OTP
	 */
	public function ajax_request_otp() {
		Ashna_Session::verify_request();

		$raw_identifier = isset( $_POST['identifier'] ) ? sanitize_text_field( wp_unslash( $_POST['identifier'] ) ) : '';
		if ( empty( $raw_identifier ) ) {
			$this->send_error( array( 'message' => 'لطفاً شماره موبایل یا ایمیل خود را وارد کنید.' ) );
		}

		// Verify Captcha if enabled
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$captcha_ok = Ashna_Security::verify_captcha( wp_unslash( $_POST ) );
		if ( is_wp_error( $captcha_ok ) ) {
			$this->send_error(
				array(
					'message'     => $captcha_ok->get_error_message(),
					'new_captcha' => 'math' === Ashna_Helper::get_option( 'captcha_type' ) ? Ashna_Security::generate_math_captcha() : null,
				)
			);
		}

		$parsed     = Ashna_Helper::parse_identifier( $raw_identifier );
		$type       = $parsed['type'];
		$identifier = $parsed['normalized'];
		$login_mode = Ashna_Helper::get_option( 'login_mode', 'phone_and_email' );

		if ( 'invalid' === $type ) {
			if ( 'phone_only' === $login_mode ) {
				$this->send_error( array( 'message' => 'شماره موبایل وارد شده معتبر نیست. (مثال: 09123456789)' ) );
			} elseif ( 'email_only' === $login_mode ) {
				$this->send_error( array( 'message' => 'آدرس ایمیل وارد شده معتبر نیست.' ) );
			} else {
				$this->send_error( array( 'message' => 'لطفاً یک شماره موبایل معتبر (مثل 09123456789) یا آدرس ایمیل صحیح وارد کنید.' ) );
			}
		}

		if ( 'phone_only' === $login_mode && 'phone' !== $type ) {
			$this->send_error( array( 'message' => 'ورود فقط با شماره موبایل امکان‌پذیر است.' ) );
		}

		if ( 'email_only' === $login_mode && 'email' !== $type ) {
			$this->send_error( array( 'message' => 'ورود فقط با آدرس ایمیل امکان‌پذیر است.' ) );
		}

		$account = self::resolve_account( $identifier, $type );
		if ( $account['error'] ) {
			$this->send_error(
				array(
					'message' => $account['error']->get_error_message(),
					'code'    => $account['error']->get_error_code(),
				)
			);
		}
		$existing_user = $account['user'];
		$auto_register = (bool) Ashna_Helper::get_option( 'auto_register', 1 );

		if ( ! $existing_user && ! $auto_register ) {
			$this->send_error( array( 'message' => 'حساب کاربری با این مشخصات یافت نشد.' ) );
		}

		$can_request = Ashna_Security::can_request_otp( $identifier );
		if ( is_wp_error( $can_request ) ) {
			$data = $can_request->get_error_data();
			$this->send_error(
				array(
					'message'   => $can_request->get_error_message(),
					'code'      => $can_request->get_error_code(),
					'remaining' => isset( $data['remaining'] ) ? (int) $data['remaining'] : 0,
				)
			);
		}

		$dispatch = Ashna_Gateway_Manager::dispatch_otp( $identifier, $type );
		if ( is_wp_error( $dispatch ) ) {
			$this->send_error(
				array(
					'message' => 'خطا در ارسال کد تایید: ' . $dispatch->get_error_message(),
				)
			);
		}

		$channel_labels = array(
			'sms'       => 'پیامک',
			'bale'      => 'پیام‌رسان بله',
			'sms+bale'  => 'پیامک و پیام‌رسان بله',
			'email'     => 'ایمیل',
			'messenger' => Ashna_Gateway_Msgway_Messenger::route_label(),
		);
		$channel_label  = isset( $channel_labels[ $dispatch['channel'] ] ) ? $channel_labels[ $dispatch['channel'] ] : 'پیامک';

		$is_new_user   = empty( $existing_user );
		$require_name  = $is_new_user ? Ashna_Helper::get_option( 'require_name_on_register', 'optional' ) : 'disabled';
		$require_email = ( $is_new_user && 'phone' === $type ) ? Ashna_Helper::get_option( 'require_email_on_register', 'disabled' ) : 'disabled';

		$response_data = array(
			'message'       => sprintf( 'کد تایید از طریق %s به %s ارسال شد.', $channel_label, Ashna_Helper::mask_identifier( $identifier ) ),
			'identifier'    => $identifier,
			'masked'        => Ashna_Helper::mask_identifier( $identifier ),
			'type'          => $type,
			'channel'       => $dispatch['channel'],
			'cooldown'      => absint( Ashna_Helper::get_option( 'resend_cooldown', 60 ) ),
			'expiry'        => absint( Ashna_Helper::get_option( 'otp_expiry', 120 ) ),
			'otp_length'    => absint( Ashna_Helper::get_option( 'otp_length', 5 ) ),
			'is_new_user'   => $is_new_user,
			'require_name'  => $require_name,
			'require_email' => $require_email,
		);

		if ( 'sandbox' === $dispatch['gateway'] && Ashna_Helper::get_option( 'show_debug_code_in_toast', 0 ) ) {
			$response_data['debug_code'] = $dispatch['code'];
		}

		$this->send_success( $response_data );
	}

	/**
	 * Handle AJAX Verify OTP & Unified Login / Auto-Register
	 */
	public function ajax_verify_otp() {
		Ashna_Session::verify_request();

		$raw_identifier = isset( $_POST['identifier'] ) ? sanitize_text_field( wp_unslash( $_POST['identifier'] ) ) : '';
		$raw_code       = isset( $_POST['code'] ) ? sanitize_text_field( wp_unslash( $_POST['code'] ) ) : '';
		$redirect_to    = isset( $_POST['redirect_to'] ) ? esc_url_raw( wp_unslash( $_POST['redirect_to'] ) ) : '';
		$full_name      = isset( $_POST['full_name'] ) ? sanitize_text_field( wp_unslash( $_POST['full_name'] ) ) : '';
		$extra_email    = isset( $_POST['user_email'] ) ? sanitize_email( wp_unslash( $_POST['user_email'] ) ) : '';

		$parsed     = Ashna_Helper::parse_identifier( $raw_identifier );
		$type       = $parsed['type'];
		$identifier = $parsed['normalized'];

		if ( 'invalid' === $type ) {
			$this->send_error( array( 'message' => 'شناسه کاربری نامعتبر است.' ) );
		}

		$account = self::resolve_account( $identifier, $type );
		if ( $account['error'] ) {
			$this->send_error(
				array(
					'message' => $account['error']->get_error_message(),
					'code'    => $account['error']->get_error_code(),
				)
			);
		}
		$user        = $account['user'];
		$is_new_user = false;

		if ( ! $user ) {
			if ( ! Ashna_Helper::get_option( 'auto_register', 1 ) ) {
				$this->send_error( array( 'message' => 'ثبت‌نام خودکار غیرفعال است.' ) );
			}

			$name_mode  = Ashna_Helper::get_option( 'require_name_on_register', 'optional' );
			$email_mode = Ashna_Helper::get_option( 'require_email_on_register', 'disabled' );

			if ( 'required' === $name_mode && empty( $full_name ) ) {
				$this->send_error( array( 'message' => 'لطفاً نام و نام خانوادگی خود را وارد کنید.' ) );
			}

			if ( 'phone' === $type && 'required' === $email_mode && ( empty( $extra_email ) || ! is_email( $extra_email ) ) ) {
				$this->send_error( array( 'message' => 'لطفاً یک آدرس ایمیل معتبر وارد کنید.' ) );
			}
		}

		$verified = Ashna_Security::verify_otp( $identifier, $raw_code );
		if ( is_wp_error( $verified ) ) {
			$this->send_error(
				array(
					'message' => $verified->get_error_message(),
					'code'    => $verified->get_error_code(),
				)
			);
		}

		if ( ! $user ) {
			$user = self::register_user(
				$identifier,
				$type,
				array(
					'full_name'  => $full_name,
					'user_email' => $extra_email,
				)
			);
			if ( is_wp_error( $user ) ) {
				$this->send_error( array( 'message' => $user->get_error_message() ) );
			}
			$is_new_user = true;
		} else {
			if ( 'phone' === $type ) {
				self::sync_user_phone_meta( $user->ID, $identifier );
			}
		}

		$logged_in = Ashna_Session::login(
			$user,
			array(
				'method'      => 'otp',
				'identifier'  => $identifier,
				'is_new_user' => $is_new_user,
			)
		);
		if ( is_wp_error( $logged_in ) ) {
			$this->send_error(
				array(
					'message' => $logged_in->get_error_message(),
					'code'    => $logged_in->get_error_code(),
				)
			);
		}
		do_action( 'ashna_otp_user_authenticated', $user, $identifier, $type, $is_new_user );

		$this->send_success(
			self::login_response(
				$user,
				$redirect_to,
				$is_new_user ? 'ثبت‌نام و ورود شما با موفقیت انجام شد! در حال انتقال...' : 'ورود با موفقیت انجام شد! در حال انتقال...',
				array( 'is_new_user' => $is_new_user )
			)
		);
	}

	/**
	 * Success payload shared by every sign-in path.
	 *
	 * The nonce belongs to the new session, so follow-up requests on the same page (for
	 * example registering a passkey right after the OTP step) are accepted.
	 *
	 * @param WP_User $user        Signed-in user.
	 * @param string  $redirect_to Requested redirect.
	 * @param string  $message     Message.
	 * @param array   $extra       Extra fields.
	 * @return array
	 */
	public static function login_response( $user, $redirect_to, $message, $extra = array() ) {
		$redirect = Ashna_Session::redirect_url( $user, $redirect_to );
		$state    = Ashna_Session::client_state();

		$payload = array_merge(
			array(
				'message'     => $message,
				'redirect_to' => $redirect,
				'redirect'    => $redirect,
				'user_id'     => $user->ID,
				'nonce'       => $state['nonce'],
				'logged_in'   => $state['logged_in'],
			),
			$extra
		);

		/**
		 * Filters the sign-in response (e.g. to add a token for a headless front end).
		 *
		 * @param array   $payload Response data.
		 * @param WP_User $user    Signed-in user.
		 */
		return apply_filters( 'ashna_otp_login_response', $payload, $user );
	}

	/**
	 * Handle AJAX Password Login Fallback (with Brute-Force Protection)
	 */
	public function ajax_password_login() {
		Ashna_Session::verify_request();

		if ( ! Ashna_Helper::get_option( 'allow_password_login', 0 ) ) {
			$this->send_error( array( 'message' => 'ورود با رمز عبور غیرفعال است.' ) );
		}

		$raw_identifier = isset( $_POST['identifier'] ) ? sanitize_text_field( wp_unslash( $_POST['identifier'] ) ) : '';
		$password       = isset( $_POST['password'] ) ? wp_unslash( $_POST['password'] ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$redirect_to    = isset( $_POST['redirect_to'] ) ? esc_url_raw( wp_unslash( $_POST['redirect_to'] ) ) : '';

		if ( empty( $raw_identifier ) || empty( $password ) ) {
			$this->send_error( array( 'message' => 'لطفاً شناسه کاربری و رمز عبور را وارد کنید.' ) );
		}

		$parsed     = Ashna_Helper::parse_identifier( $raw_identifier );
		$identifier = 'invalid' !== $parsed['type'] ? $parsed['normalized'] : $raw_identifier;

		$lockout = Ashna_Security::check_lockout( $identifier );
		if ( is_wp_error( $lockout ) ) {
			$this->send_error( array( 'message' => $lockout->get_error_message() ) );
		}

		// Locate the account, then let WordPress authenticate it through the full `authenticate`
		// filter chain (2FA, login limiters, membership approval ...) exactly like wp-login.php.
		$user = null;
		foreach ( self::password_candidates( $identifier, $parsed['type'] ) as $candidate ) {
			if ( wp_check_password( $password, $candidate->user_pass, $candidate->ID ) ) {
				$user = $candidate;
				break;
			}
		}

		$generic = 'نام کاربری/شماره یا رمز عبور اشتباه است.';
		if ( ! $user ) {
			Ashna_Security::record_failed_password_attempt( $identifier );
			do_action( 'wp_login_failed', $raw_identifier, new WP_Error( 'incorrect_password', $generic ) );
			$this->send_error( array( 'message' => $generic ) );
		}

		$authenticated = wp_authenticate( $user->user_login, $password );
		if ( is_wp_error( $authenticated ) ) {
			$credential_errors = array( 'incorrect_password', 'invalid_username', 'invalid_email', 'empty_password', 'empty_username' );
			if ( in_array( $authenticated->get_error_code(), $credential_errors, true ) ) {
				Ashna_Security::record_failed_password_attempt( $identifier );
				$this->send_error( array( 'message' => $generic ) );
			}
			$readable = Ashna_Session::readable_error( $authenticated );
			$this->send_error(
				array(
					'message' => $readable->get_error_message(),
					'code'    => $readable->get_error_code(),
				)
			);
		}

		Ashna_Security::clear_password_attempts( $identifier );

		$logged_in = Ashna_Session::login(
			$authenticated,
			array(
				'method'        => 'password',
				'identifier'    => $identifier,
				'authenticated' => true,
			)
		);
		if ( is_wp_error( $logged_in ) ) {
			$this->send_error(
				array(
					'message' => $logged_in->get_error_message(),
					'code'    => $logged_in->get_error_code(),
				)
			);
		}

		$this->send_success( self::login_response( $authenticated, $redirect_to, 'ورود با موفقیت انجام شد! در حال انتقال...' ) );
	}

	/**
	 * Accounts a password sign-in may belong to (a phone can match more than one account).
	 *
	 * @param string $identifier Normalized phone/email or raw username.
	 * @param string $type       phone|email|invalid.
	 * @return WP_User[]
	 */
	private static function password_candidates( $identifier, $type ) {
		if ( 'email' === $type ) {
			$user = get_user_by( 'email', $identifier );
			if ( ! $user ) {
				$user = get_user_by( 'login', $identifier );
			}
			return $user ? array( $user ) : array();
		}
		if ( 'phone' !== $type ) {
			$user = get_user_by( 'login', $identifier );
			return $user ? array( $user ) : array();
		}

		$ids = array();
		foreach ( self::verified_phone_lookups( $identifier ) as $meta_query ) {
			$ids = array_merge( $ids, self::user_ids_by_meta( $meta_query, 5 ) );
		}
		$ids = array_merge( $ids, self::unverified_phone_candidates( $identifier ) );

		$users = array();
		foreach ( array_slice( array_values( array_unique( array_map( 'absint', $ids ) ) ), 0, 5 ) as $id ) {
			$user = get_user_by( 'id', $id );
			if ( $user ) {
				$users[] = $user;
			}
		}
		return $users;
	}

	/**
	 * Find an existing WordPress user by normalized phone or email (backward-compatible API).
	 * Supports users registered via Ashna, Digits, WooCommerce, MihanPanel, or standard WP login.
	 *
	 * @param string $identifier Normalized phone (09XXXXXXXXX) or email.
	 * @param string $type       'phone' or 'email'.
	 * @return WP_User|false False when no account — or no single safe account — matches.
	 */
	public static function find_user( $identifier, $type = 'phone' ) {
		$account = self::resolve_account( $identifier, $type );
		return $account['user'] ? $account['user'] : false;
	}

	/**
	 * Resolve the account that owns a phone/email, without guessing.
	 *
	 * 1. Phones verified by an OTP sign-in (Ashna, then Digits) are trusted.
	 * 2. Unverified profile data (WooCommerce billing phone, legacy "mobile" field, phone-like
	 *    usernames) is used only for ordinary accounts that have no other verified phone.
	 *    Staff accounts (admins, shop managers, editors ...) are never opened through
	 *    unverified data: one mistyped billing phone must not hand out admin access.
	 * 3. When more than one account matches, nobody is signed in and nothing is created.
	 *
	 * @param string $identifier Normalized phone or email.
	 * @param string $type       'phone' or 'email'.
	 * @return array { user: WP_User|null, error: WP_Error|null }
	 */
	public static function resolve_account( $identifier, $type = 'phone' ) {
		$none = array(
			'user'  => null,
			'error' => null,
		);

		if ( 'email' === $type ) {
			$user = get_user_by( 'email', $identifier );
			return $user ? array( 'user' => $user, 'error' => null ) : $none;
		}
		if ( 'phone' !== $type || '' === (string) $identifier ) {
			return $none;
		}

		// 1. Verified phones.
		foreach ( self::verified_phone_lookups( $identifier ) as $meta_query ) {
			$ids = self::user_ids_by_meta( $meta_query, 2 );
			if ( 1 === count( $ids ) ) {
				$user = get_user_by( 'id', $ids[0] );
				if ( $user ) {
					return array( 'user' => $user, 'error' => null );
				}
			} elseif ( count( $ids ) > 1 ) {
				return array( 'user' => null, 'error' => self::ambiguous_error() );
			}
		}

		// 2. Unverified profile data.
		/**
		 * Extra candidate user IDs for a phone (integrations, custom profile fields).
		 *
		 * @param int[]  $ids        Candidate IDs.
		 * @param string $identifier Normalized phone (09XXXXXXXXX).
		 */
		$ids = apply_filters( 'ashna_otp_phone_candidates', self::unverified_phone_candidates( $identifier ), $identifier );
		$ids = array_values( array_unique( array_filter( array_map( 'absint', (array) $ids ) ) ) );

		$eligible  = array();
		$staff_hit = false;
		foreach ( $ids as $id ) {
			$user = get_user_by( 'id', $id );
			if ( ! $user ) {
				continue;
			}
			if ( self::is_staff_account( $user ) ) {
				$staff_hit = true;
				continue;
			}
			if ( self::has_other_verified_phone( $user->ID, $identifier ) ) {
				continue;
			}
			$eligible[] = $user;
		}

		if ( 1 === count( $eligible ) ) {
			return array( 'user' => $eligible[0], 'error' => null );
		}
		if ( count( $eligible ) > 1 ) {
			return array( 'user' => null, 'error' => self::ambiguous_error() );
		}
		if ( $staff_hit ) {
			return array(
				'user'  => null,
				'error' => new WP_Error( 'ashna_staff_phone_unverified', 'ورود با کد یکبارمصرف برای این شماره فعال نیست. لطفاً با رمز عبور وارد شوید یا با پشتیبانی سایت تماس بگیرید.' ),
			);
		}

		return $none;
	}

	/**
	 * Whether an account has staff capabilities (never opened through unverified phone data).
	 *
	 * @param WP_User $user User.
	 * @return bool
	 */
	public static function is_staff_account( $user ) {
		$is_staff = false;
		foreach ( array( 'manage_options', 'edit_users', 'promote_users', 'activate_plugins', 'manage_woocommerce', 'edit_others_posts' ) as $cap ) {
			if ( user_can( $user, $cap ) ) {
				$is_staff = true;
				break;
			}
		}
		return (bool) apply_filters( 'ashna_otp_is_staff_account', $is_staff, $user );
	}

	/**
	 * Meta queries for phones verified by an OTP sign-in (Ashna first, then Digits).
	 *
	 * @param string $identifier Normalized phone.
	 * @return array[]
	 */
	private static function verified_phone_lookups( $identifier ) {
		$intl_plus = Ashna_Helper::to_international_phone( $identifier, true );
		$intl_raw  = Ashna_Helper::to_international_phone( $identifier, false );
		$no_zero   = ltrim( $identifier, '0' );

		return array(
			array(
				array(
					'key'   => 'ashna_phone',
					'value' => $identifier,
				),
			),
			array(
				'relation' => 'OR',
				array(
					'key'     => 'digits_phone',
					'value'   => array( $intl_plus, $intl_raw, $identifier, $no_zero ),
					'compare' => 'IN',
				),
				array(
					'key'     => 'digits_phone_no',
					'value'   => array( $no_zero, $identifier ),
					'compare' => 'IN',
				),
			),
		);
	}

	/**
	 * Candidate IDs from unverified profile data.
	 *
	 * @param string $identifier Normalized phone.
	 * @return int[]
	 */
	private static function unverified_phone_candidates( $identifier ) {
		$intl_plus = Ashna_Helper::to_international_phone( $identifier, true );
		$intl_raw  = Ashna_Helper::to_international_phone( $identifier, false );
		$no_zero   = ltrim( $identifier, '0' );

		$ids = self::user_ids_by_meta(
			array(
				'relation' => 'OR',
				array(
					'key'     => 'billing_phone',
					'value'   => array( $identifier, $intl_plus, $intl_raw, $no_zero ),
					'compare' => 'IN',
				),
				array(
					'key'     => 'mobile',
					'value'   => array( $identifier, $intl_plus, $no_zero ),
					'compare' => 'IN',
				),
			),
			5
		);

		$login_candidates = array( $identifier, $intl_raw, $intl_plus, $no_zero, 'u_' . $identifier );
		$custom_prefix    = sanitize_key( Ashna_Helper::get_option( 'username_prefix', '' ) );
		if ( ! empty( $custom_prefix ) ) {
			$login_candidates[] = $custom_prefix . $identifier;
		}
		foreach ( array_unique( $login_candidates ) as $candidate_login ) {
			$user_by_login = get_user_by( 'login', $candidate_login );
			if ( $user_by_login ) {
				$ids[] = (int) $user_by_login->ID;
			}
		}

		return array_values( array_unique( $ids ) );
	}

	/**
	 * Whether the account already has a different verified phone.
	 *
	 * @param int    $user_id    User ID.
	 * @param string $identifier Normalized phone.
	 * @return bool
	 */
	private static function has_other_verified_phone( $user_id, $identifier ) {
		$verified = (string) get_user_meta( $user_id, 'ashna_phone', true );
		if ( '' !== $verified ) {
			return Ashna_Helper::normalize_phone( $verified ) !== $identifier;
		}
		$digits = (string) get_user_meta( $user_id, 'digits_phone', true );
		if ( '' !== $digits ) {
			return Ashna_Helper::normalize_phone( $digits ) !== $identifier;
		}
		return false;
	}

	/**
	 * User IDs matching a meta query.
	 *
	 * @param array $meta_query Meta query.
	 * @param int   $limit      Max IDs.
	 * @return int[]
	 */
	private static function user_ids_by_meta( $meta_query, $limit = 2 ) {
		$ids = get_users(
			array(
				'meta_query'  => $meta_query, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
				'number'      => $limit,
				'fields'      => 'ID',
				'count_total' => false,
			)
		);
		return array_values( array_map( 'absint', (array) $ids ) );
	}

	/**
	 * Error for a phone shared by several accounts.
	 *
	 * @return WP_Error
	 */
	private static function ambiguous_error() {
		return new WP_Error( 'ashna_ambiguous_account', 'این شماره به بیش از یک حساب کاربری متصل است. لطفاً با ایمیل یا رمز عبور وارد شوید یا با پشتیبانی سایت تماس بگیرید.' );
	}

	/**
	 * Synchronize user phone number across Ashna, WooCommerce, and Digits meta keys
	 * Ensures 100% forward & backward compatibility even if plugins are switched in the future
	 *
	 * @param int    $user_id    WordPress User ID.
	 * @param string $identifier Normalized phone (09XXXXXXXXX).
	 */
	public static function sync_user_phone_meta( $user_id, $identifier ) {
		$intl_plus = Ashna_Helper::to_international_phone( $identifier, true ); // +989123456789
		$no_zero   = ltrim( $identifier, '0' );                                 // 9123456789

		// 1. Ashna native meta
		update_user_meta( $user_id, 'ashna_phone', $identifier );

		// 2. WooCommerce native billing_phone
		if ( ! get_user_meta( $user_id, 'billing_phone', true ) ) {
			update_user_meta( $user_id, 'billing_phone', $identifier );
		}

		// 3. Digits native meta keys (for seamless cross-plugin compatibility)
		if ( ! get_user_meta( $user_id, 'digits_phone', true ) ) {
			update_user_meta( $user_id, 'digits_phone', $intl_plus );
		}
		if ( ! get_user_meta( $user_id, 'digits_phone_no', true ) ) {
			update_user_meta( $user_id, 'digits_phone_no', $no_zero );
		}
		if ( ! get_user_meta( $user_id, 'digt_countrycode', true ) ) {
			update_user_meta( $user_id, 'digt_countrycode', '+98' );
		}
	}

	/**
	 * Automatically register a new user from verified phone or email
	 *
	 * @param string $identifier Normalized phone or email.
	 * @param string $type       'phone' or 'email'.
	 * @param array  $extra      Extra profile fields (full_name, user_email).
	 * @return WP_User|WP_Error
	 */
	public static function register_user( $identifier, $type = 'phone', $extra = array() ) {
		$prefix = sanitize_key( Ashna_Helper::get_option( 'username_prefix', '' ) );

		if ( 'email' === $type ) {
			$email_local = explode( '@', $identifier )[0];
			$base_login  = sanitize_user( $email_local, true );
			if ( empty( $base_login ) ) {
				$base_login = ( ! empty( $prefix ) ? $prefix : 'user_' ) . wp_rand( 10000, 99999 );
			}
			$user_login = $base_login;
			$suffix     = 1;
			while ( username_exists( $user_login ) ) {
				$user_login = $base_login . '_' . $suffix;
				++$suffix;
			}
			$user_email = $identifier;
		} else {
			$user_login = ! empty( $prefix ) ? ( $prefix . $identifier ) : $identifier;
			if ( username_exists( $user_login ) ) {
				$user_login = $identifier . '_' . wp_rand( 100, 999 );
			}
			$user_email = ! empty( $extra['user_email'] ) && is_email( $extra['user_email'] ) && ! email_exists( $extra['user_email'] )
				? $extra['user_email']
				: '';
		}

		$desired_role = self::safe_registration_role( Ashna_Helper::get_option( 'default_user_role', 'customer' ) );

		$full_name    = ! empty( $extra['full_name'] ) ? trim( $extra['full_name'] ) : '';
		$first_name   = '';
		$last_name    = '';
		$display_name = 'phone' === $type ? $identifier : explode( '@', $identifier )[0];

		if ( ! empty( $full_name ) ) {
			$display_name = $full_name;
			$name_parts   = preg_split( '/\s+/', $full_name, 2 );
			$first_name   = $name_parts[0];
			$last_name    = isset( $name_parts[1] ) ? $name_parts[1] : '';
		}

		$userdata = array(
			'user_login'   => $user_login,
			'user_pass'    => wp_generate_password( 24, true, true ),
			'user_email'   => $user_email,
			'first_name'   => $first_name,
			'last_name'    => $last_name,
			'display_name' => $display_name,
			'role'         => $desired_role,
		);

		$woocommerce = class_exists( 'WooCommerce' );
		if ( $woocommerce ) {
			// Same customer pipeline as WooCommerce's own registration (wc_create_new_customer()).
			$userdata         = (array) apply_filters( 'woocommerce_new_customer_data', $userdata );
			$userdata['role'] = self::safe_registration_role( isset( $userdata['role'] ) ? $userdata['role'] : $desired_role );
		}

		$user_id = wp_insert_user( $userdata );
		if ( is_wp_error( $user_id ) ) {
			return $user_id;
		}

		if ( 'phone' === $type ) {
			self::sync_user_phone_meta( $user_id, $identifier );
		}

		if ( ! empty( $first_name ) ) {
			update_user_meta( $user_id, 'billing_first_name', $first_name );
		}
		if ( ! empty( $last_name ) ) {
			update_user_meta( $user_id, 'billing_last_name', $last_name );
		}

		update_user_meta( $user_id, 'ashna_registered_via_otp', 1 );

		if ( $woocommerce ) {
			// Lets WooCommerce (new-account e-mail) and its extensions treat the account as a customer sign-up.
			do_action( 'woocommerce_created_customer', $user_id, $userdata, true );
		}

		do_action( 'ashna_otp_user_registered', $user_id, $identifier, $type, $extra );

		return get_user_by( 'id', $user_id );
	}

	/**
	 * Role for accounts created by Ashna. Roles with staff capabilities are refused even if
	 * selected by mistake (or injected through a settings import).
	 *
	 * @param string $role Requested role.
	 * @return string
	 */
	public static function safe_registration_role( $role ) {
		$roles = wp_roles();
		$role  = sanitize_key( (string) $role );
		if ( 'customer' === $role && ! $roles->is_role( 'customer' ) ) {
			$role = sanitize_key( (string) get_option( 'default_role', 'subscriber' ) );
		}

		$role = (string) apply_filters( 'ashna_otp_registration_role', $role );

		$dangerous = array( 'manage_options', 'edit_users', 'create_users', 'promote_users', 'delete_users', 'activate_plugins', 'install_plugins', 'edit_plugins', 'edit_theme_options', 'manage_woocommerce', 'edit_others_posts', 'unfiltered_html', 'manage_network' );
		$role_obj  = $roles->get_role( $role );
		$is_safe   = (bool) $role_obj;
		if ( $role_obj ) {
			foreach ( $dangerous as $cap ) {
				if ( $role_obj->has_cap( $cap ) ) {
					$is_safe = false;
					break;
				}
			}
		}

		if ( $is_safe ) {
			return $role;
		}
		return $roles->is_role( 'customer' ) ? 'customer' : 'subscriber';
	}
}
