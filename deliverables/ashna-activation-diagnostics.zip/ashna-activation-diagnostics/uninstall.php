<?php
/** Remove ONLY this diagnostic tool's reports, never Ashna settings. */
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}
delete_metadata( 'user', 0, '_ashna_activation_diagnostics_activate', '', true );
delete_metadata( 'user', 0, '_ashna_activation_diagnostics_error_scrape', '', true );
delete_metadata( 'user', 0, '_ashna_activation_diagnostics_capture_until', '', true );
delete_metadata( 'user', 0, '_ashna_activation_diagnostics_loader_message', '', true );
