<?php
/**
 * Template used at build time for a licensed, protectable PHP file.
 * The marker is replaced BEFORE encoding; never edit an encoded file.
 *
 * @package Ashna
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// --------------------------------------------------------------------------------------------------- Start RTL License

$rtlLicenseClassName = 'RTL_License_c1595a7238d64f3a';

if (
	class_exists($rtlLicenseClassName, false)
	&& method_exists($rtlLicenseClassName, 'isActive')
) {
	try {
		$rtlLicenseReflection = new \ReflectionClass($rtlLicenseClassName);
		$rtlLicenseFilePath   = $rtlLicenseReflection->getFileName();

		if (is_string($rtlLicenseFilePath) && is_file($rtlLicenseFilePath)) {
			$rtlLicenseFileHash = @sha1_file($rtlLicenseFilePath);

			if (
				is_string($rtlLicenseFileHash)
				&& hash_equals('3fac0395eb82fa65036a1e9aabcf0aac9c2bcedc', $rtlLicenseFileHash)
			) {
				$rtlLicenseClass = new $rtlLicenseClassName();

				if ($rtlLicenseClass->{'isActive'}() === true) {
					// لایسنس فعال است؛ کد امکانات لایسنس‌دار را اینجا قرار دهید.

// ---- Source: includes/class-ashna-plugin.php ----
/**
 * Core Plugin Kernel & Lifecycle Manager
 *
 * @package Ashna
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Ashna_Plugin {

	/**
	 * Singleton instance
	 *
	 * @var Ashna_Plugin|null
	 */
	private static $instance = null;

	/** Prevent duplicate service hooks when bootstrapping after plugins_loaded. */
	private $services_initialized = false;

	/**
	 * Get singleton instance
	 *
	 * @return Ashna_Plugin
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor
	 */
	private function __construct() {
		$this->init_hooks();
	}

	/**
	 * Register lifecycle and initialization hooks
	 */
	private function init_hooks() {
		register_activation_hook( ASHNA_OTP_FILE, array( 'Ashna_Activator', 'activate' ) );
		register_deactivation_hook( ASHNA_OTP_FILE, array( 'Ashna_Activator', 'deactivate' ) );

		add_action( 'ashna_otp_daily_cleanup', array( 'Ashna_Logger', 'run_scheduled_cleanup' ) );
		add_filter( 'cron_schedules', array( 'Ashna_Failover', 'register_cron_schedule' ) ); // phpcs:ignore WordPress.WP.CronInterval.CronSchedulesInterval, WordPress.WP.CronInterval.ChangeDetected -- 5-minute gateway health probe, background only.
		add_action( 'ashna_otp_gateway_probe', array( 'Ashna_Failover', 'run_probe' ) );
		add_filter( 'plugin_action_links_' . ASHNA_OTP_BASENAME, array( $this, 'plugin_action_links' ) );

		if ( did_action( 'plugins_loaded' ) ) {
			// Licensed boot happens after plugins_loaded. Do not attach a callback
			// to an already-fired priority. During activation, only register the
			// lifecycle hooks; WordPress will invoke activate() after inclusion.
			if ( ! defined( 'WP_SANDBOX_SCRAPING' ) || ! WP_SANDBOX_SCRAPING ) {
				$this->on_plugins_loaded();
			}
		} else {
			add_action( 'plugins_loaded', array( $this, 'on_plugins_loaded' ) );
		}
	}

	/**
	 * Boot services when WordPress plugins are loaded
	 */
	public function on_plugins_loaded() {
		if ( $this->services_initialized ) {
			return;
		}
		$this->services_initialized = true;

		Ashna_Activator::maybe_upgrade();
		Ashna_Failover::ensure_probe_scheduled();

		Ashna_Session::init();
		Ashna_Auth::instance();
		Ashna_SSO::init();
		new Ashna_Passkey();
		Ashna_Frontend::instance();
		Ashna_WooCommerce::instance();
		Ashna_Integrations::init();

		if ( did_action( 'elementor/loaded' ) || class_exists( '\Elementor\Plugin' ) ) {
			Ashna_Elementor::instance();
		} else {
			add_action(
				'elementor/loaded',
				function () {
					Ashna_Elementor::instance();
				}
			);
		}

		if ( is_admin() ) {
			Ashna_Admin::instance();
		}
	}

	/**
	 * Add quick action links to the WordPress Plugins page
	 *
	 * @param array $links Existing links.
	 * @return array
	 */
	public function plugin_action_links( $links ) {
		$settings_link = '<a href="' . esc_url( admin_url( 'admin.php?page=ashna-otp' ) ) . '" style="font-weight:700;color:#2563eb;">تنظیمات</a>';
		$logs_link     = '<a href="' . esc_url( admin_url( 'admin.php?page=ashna-otp-logs' ) ) . '">لاگ کدها</a>';
		array_unshift( $links, $settings_link, $logs_link );
		return $links;
	}
}


// ---- Source: includes/core/class-ashna-activator.php ----
/**
 * Plugin Activator, Deactivator & Database Schema Manager
 *
 * @package Ashna
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Ashna_Activator {

	/**
	 * Database schema version
	 */
	const DB_VERSION = '2.6.0';

	/**
	 * Run on plugin activation
	 */
	public static function activate() {
		self::create_tables();

		if ( false === get_option( 'ashna_otp_settings' ) ) {
			update_option( 'ashna_otp_settings', Ashna_Helper::default_settings() );
		}

		if ( ! wp_next_scheduled( 'ashna_otp_daily_cleanup' ) ) {
			wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'ashna_otp_daily_cleanup' );
		}
		Ashna_Failover::ensure_probe_scheduled();
		self::ensure_attack_mode_option();
		self::ensure_digits_meta_flag();

		update_option( 'ashna_otp_db_version', self::DB_VERSION );
	}

	/**
	 * Store the "attack mode is off" state once.
	 *
	 * The option is read on every front-end page view and every OTP request, so it is autoloaded
	 * and always present: a missing autoloaded option still costs one options-table query per
	 * request, while an existing one travels with the already-loaded alloptions array.
	 */
	public static function ensure_attack_mode_option() {
		if ( false === get_option( Ashna_Rate_Limiter::ATTACK_OPTION ) ) {
			add_option(
				Ashna_Rate_Limiter::ATTACK_OPTION,
				array(
					'since' => 0,
					'until' => 0,
					'peak'  => 0,
				),
				'',
				true
			);
		}
	}

	/**
	 * Decide once whether the Digits phone keys can exist in this database.
	 *
	 * Digits stores the phone under `digits_phone`, `digits_phone_no` and `digt_countrycode`; Ashna
	 * reads and writes those keys for cross-plugin compatibility. Their existence is a property of
	 * the site (has Digits ever been used here?), not of a request, so it is answered once and then
	 * read for free from the autoloaded options. The answer is never downgraded: a site that
	 * deactivates Digits after using it keeps the keys reachable for its accounts.
	 */
	public static function ensure_digits_meta_flag() {
		if ( null !== get_option( Ashna_Auth::DIGITS_META_OPTION, null ) ) {
			return;
		}

		global $wpdb;

		$present = class_exists( 'Digits' );
		if ( ! $present ) {
			$keys    = array( 'digits_phone', 'digits_phone_no', 'digt_countrycode' );
			$holders = implode( ', ', array_fill( 0, count( $keys ), '%s' ) );
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- one-off activation check, %s placeholders are prepared.
			$present = (bool) $wpdb->get_var( $wpdb->prepare( "SELECT 1 FROM {$wpdb->usermeta} WHERE meta_key IN ({$holders}) LIMIT 1", $keys ) );
		}

		add_option( Ashna_Auth::DIGITS_META_OPTION, $present ? 'yes' : 'no', '', true );
	}

	/**
	 * Run on plugin deactivation
	 */
	public static function deactivate() {
		$timestamp = wp_next_scheduled( 'ashna_otp_daily_cleanup' );
		if ( $timestamp ) {
			wp_unschedule_event( $timestamp, 'ashna_otp_daily_cleanup' );
		}
		Ashna_Failover::unschedule_probe();
	}

	/**
	 * Check and run DB upgrade & cron registration if needed
	 */
	public static function maybe_upgrade() {
		$installed_version = get_option( 'ashna_otp_db_version' );
		if ( self::DB_VERSION !== $installed_version ) {
			self::create_tables();
			if ( false === get_option( 'ashna_otp_settings' ) ) {
				update_option( 'ashna_otp_settings', Ashna_Helper::default_settings() );
			}
			if ( ! wp_next_scheduled( 'ashna_otp_daily_cleanup' ) ) {
				wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'ashna_otp_daily_cleanup' );
			}
			self::ensure_attack_mode_option();
			self::ensure_digits_meta_flag();
			update_option( 'ashna_otp_db_version', self::DB_VERSION );
		}
	}

	/**
	 * Create custom database tables
	 */
	public static function create_tables() {
		global $wpdb;

		$table_name      = $wpdb->prefix . 'ashna_otp_logs';
		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE {$table_name} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			recipient varchar(191) NOT NULL,
			channel varchar(32) NOT NULL DEFAULT 'sms',
			gateway varchar(50) NOT NULL DEFAULT 'sandbox',
			otp_code varchar(20) NOT NULL DEFAULT '',
			otp_hash varchar(255) NOT NULL DEFAULT '',
			status varchar(32) NOT NULL DEFAULT 'sent',
			attempts smallint(5) unsigned NOT NULL DEFAULT 0,
			ip_address varchar(64) NOT NULL DEFAULT '',
			ip_subnet varchar(64) NOT NULL DEFAULT '',
			response_message text NULL,
			expires_at datetime NOT NULL,
			verified_at datetime NULL,
			created_at datetime NOT NULL,
			PRIMARY KEY  (id),
			KEY recipient_idx (recipient),
			KEY ip_address_idx (ip_address),
			KEY ip_subnet_idx (ip_subnet,created_at),
			KEY status_idx (status),
			KEY created_at_idx (created_at),
			KEY recipient_time_idx (recipient,created_at,status,channel),
			KEY ip_time_idx (ip_address,created_at,channel),
			KEY created_at_status_channel_idx (created_at,status,channel)
		) {$charset_collate};";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );

		self::create_sso_table();
	}

	/**
	 * Identity table for the social sign-in providers (Google, Telegram).
	 *
	 * One row per (provider, subject). The unique key is what makes a concurrent double callback
	 * harmless: the second insert loses the race and is simply rejected.
	 */
	public static function create_sso_table() {
		global $wpdb;

		$table_name      = $wpdb->prefix . 'ashna_sso_identities';
		$charset_collate = $wpdb->get_charset_collate();

		$sql = "CREATE TABLE {$table_name} (
			id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
			provider varchar(20) NOT NULL,
			subject varchar(191) NOT NULL,
			user_id bigint(20) unsigned NOT NULL,
			email varchar(191) NOT NULL DEFAULT '',
			phone varchar(32) NOT NULL DEFAULT '',
			created_at datetime NOT NULL,
			last_login datetime NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY provider_subject (provider,subject),
			KEY user_idx (user_id)
		) {$charset_collate};";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );
	}
}


// ---- Source: includes/core/class-ashna-helper.php ----
/**
 * Helper Utility Functions & Settings Cache Manager for Ashna
 *
 * @package Ashna
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Ashna_Helper {

	/**
	 * In-memory runtime cache of merged plugin settings
	 *
	 * @var array|null
	 */
	private static $settings_cache = null;

	/**
	 * Default plugin settings (v2.3)
	 *
	 * @return array
	 */
	public static function default_settings() {
		return array(
			// 1. General & Auth Flow Settings
			'login_mode'                => 'phone_and_email', // phone_only | phone_and_email | email_only
			'mobile_delivery_channel'   => 'sms',             // sms | bale | bale_fallback_sms | sms_fallback_bale | both | messenger | messenger_fallback_sms
			'otp_length'                => 5,
			'otp_expiry'                => 120,               // seconds
			'resend_cooldown'           => 60,                // seconds
			'auto_register'             => 1,
			'default_user_role'         => 'customer',        // falls back to subscriber if WooCommerce not active
			'username_prefix'           => '',
			'require_name_on_register'  => 'optional',        // disabled | optional | required
			'require_email_on_register' => 'disabled',        // disabled | optional | required
			'allow_password_login'      => 0,
			'enable_passkey'            => 1,                 // WebAuthn Biometric Passkey Login
			'passkey_prompt_after_otp'  => 1,                 // Offer 1-click Passkey enrollment after OTP verify
			'passkey_wc_myaccount'      => 1,                 // Show Passkey manager in WooCommerce My Account
			'passkey_btn_text'          => 'ورود سریع با اثر انگشت / چهره (Passkey)',
			'show_terms_checkbox'       => 0,
			'terms_text'                => 'ورود و ثبت‌نام شما به معنای پذیرش قوانین و مقررات سایت است.',
			'terms_url'                 => '',
			'redirect_behavior'         => 'auto',            // auto | referer | custom | myaccount
			'redirect_url'              => '',
			'custom_redirect_url'       => '',
			'admin_redirect_url'        => '',
			'session_remember'          => 1,                 // keep users signed in on this device (WordPress "remember me")
			'session_days'              => 14,                // length of a remembered session, in days (1–365)
			'respect_login_gates'       => 1,                 // let approval / ban / lockout plugins refuse a sign-in (wp_authenticate_user)
			'respect_plugin_redirects'  => 1,                 // apply login_redirect + woocommerce_login_redirect (membership plugins, Dokan)
			'send_welcome_message'      => 0,
			'welcome_message_text'      => 'به {site_name} خوش آمدید! حساب کاربری شما با موفقیت ایجاد شد.',
			'show_debug_code_in_toast'  => 0,

			// Social sign-in (OpenID Connect). Secrets are stored here and never sent back to the
			// browser: an empty field in the settings form means "keep the saved value".
			'sso_google_enabled'        => 0,
			'sso_google_client_id'      => '',
			'sso_google_client_secret'  => '',
			'sso_telegram_enabled'      => 0,
			'sso_telegram_client_id'    => '',
			'sso_telegram_client_secret' => '',
			'sso_show_on_forms'         => 1,
			'sso_ask_phone'             => 1,

			// 2. Active & 3 Backup SMS Gateways (Failover Chain)
			'active_sms_gateway'        => 'sandbox',         // sandbox | smsir | kavenegar | melipayamak | farazsms | ippanel
			'backup_sms_gateway'        => 'none',            // legacy alias
			'backup_sms_gateway_1'      => 'none',            // 1st priority failover
			'backup_sms_gateway_2'      => 'none',            // 2nd priority failover
			'backup_sms_gateway_3'      => 'none',            // 3rd priority failover
			'gateway_timeout'           => 5,                 // seconds to wait for one gateway before failing over (2–15)
			'gateway_cooldown'          => 5,                 // minutes a failing gateway is skipped before a quick re-check (1–60)
			'gateway_adaptive'          => 1,                 // learn each gateway's normal response time and fail over sooner
			'gateway_probe'             => 1,                 // background health check of the delivery path every 5 minutes

			// SMS.ir Settings
			'smsir_api_key'             => '',
			'smsir_template_id'         => '',
			'smsir_param_name'          => 'CODE',

			// Kavenegar Settings
			'kavenegar_api_key'         => '',
			'kavenegar_template'        => '',

			// Melipayamak Settings (console API key; username/password = legacy REST fallback)
			'melipayamak_api_key'       => '',
			'melipayamak_username'      => '',
			'melipayamak_password'      => '',
			'melipayamak_body_id'       => '',

			// FarazSMS Settings (api.iranpayamak.com)
			'farazsms_api_key'          => '',
			'farazsms_from_number'      => '',                // optional sender line
			'farazsms_pattern_code'     => '',
			'farazsms_param_name'       => 'code',

			// IPPanel Settings (Edge API)
			'ippanel_api_key'           => '',
			'ippanel_from_number'       => '+983000505',
			'ippanel_pattern_code'      => '',
			'ippanel_param_name'        => 'code',

			// Rahpayam / MsgWay (SMS gateway + Iranian messengers)
			'msgway_api_key'               => '',
			'msgway_sms_template_id'       => '',
			'msgway_sms_line'              => 0,              // 0 = Rahpayam default line
			'msgway_messenger_mode'        => 'smart',        // smart | gap | igap | custom
			'msgway_messenger_template_id' => '',
			'msgway_messenger_provider'    => 0,              // provider ID for "custom"

			// 3. Bale Messenger & Email Settings
			'bale_mode'                 => 'safir',           // safir (Safir v3) | bot
			'bale_api_key'              => '',                // Safir v3 api-access-key
			'bale_bot_id'               => '',                // Safir v3 numeric bot ID
			'bale_bot_token'            => '',
			'bale_message_template'     => "کد تایید ورود شما به {site_name}:\n*{code}*\nاین کد تا {expiry} ثانیه معتبر است.",

			'email_subject'             => 'کد تایید ورود به {site_name}',
			'email_from_name'           => '',
			'email_from_address'        => '',
			'email_heading'             => 'کد یکبارمصرف ورود به حساب کاربری',
			'email_body_text'           => 'برای ورود به حساب کاربری خود در {site_name}، کد تایید زیر را در فرم ورود وارد نمایید:',

			// 4. Appearance Studio & UI Customization
			'theme_preset'              => 'modern_blue',     // modern_blue | digistyle_red | emerald_fresh | dark_luxury
			'primary_color'             => '#2563eb',
			'card_bg_color'             => '#ffffff',
			'text_color'                => '#111827',
			'border_radius'             => 16,                // px
			'digit_box_style'           => 'box',             // box | underline | pill
			'logo_url'                  => '',
			'form_max_width'            => 420,
			'form_title'                => 'ورود / ثبت‌نام',
			'form_subtitle'             => 'برای ادامه، شماره موبایل یا ایمیل خود را وارد کنید.',
			'button_text'               => 'دریافت کد تایید',
			'verify_button_text'        => 'تایید و ورود به حساب',
			'custom_css'                => '',

			// 4.1. Layout, Split-Screen, Drawer Modal & Standalone Canvas (Category 1)
			'form_layout'               => 'card',            // card | split_right | split_left
			'card_position'             => 'center',          // center | right | left
			'split_bg_color'            => '#1e3a8a',
			'split_image_url'           => '',
			'split_badge_text'          => 'احراز هویت سریع و امن',
			'split_title'               => 'ورود آسان و بدون فراموشی رمز عبور',
			'split_subtitle'            => 'با کد یکبارمصرف پیامکی، پیام‌رسان بله یا اثر انگشت در چند ثانیه وارد حساب کاربری خود شوید.',
			'split_features'            => "ارسال فوری کد تایید از طریق پیامک و بله\nورود ۱ ثانیه‌ای با اثر انگشت و تشخیص چهره\nامنیت کامل اطلاعات و حساب کاربری شما",
			'modal_style'               => 'center',          // center | drawer_left | drawer_right | bottom_sheet
			'modal_mobile_sheet'        => 1,
			'standalone_page_id'        => 0,
			'canvas_bg_style'           => 'mesh_dark',       // mesh_light | mesh_dark | brand_gradient | custom_image | solid
			'canvas_bg_color'           => '#0f172a',
			'canvas_bg_image'           => '',
			'canvas_show_back_link'     => 1,

			// 4.2. Card Styling, Glassmorphism, Shadows, Gradients & Patterns (Category 2)
			'secondary_color'           => '#4f46e5',
			'button_bg_mode'            => 'solid',           // solid | gradient
			'glassmorphism'             => 0,
			'card_bg_opacity'           => 85,                // 20..100 (%)
			'backdrop_blur'             => 16,                // 0..32 (px)
			'card_shadow'               => 'medium',          // none | soft | medium | deep | glow
			'card_border_style'         => 'subtle',          // subtle | none | glow | top_accent
			'card_padding'              => 32,                // 20..48 (px)
			'bg_pattern'                => 'none',            // none | dots | grid | waves | geometric

			// 4.3. Typography, Fonts & Input Field Styles (Category 3)
			'font_family'               => 'vazirmatn',       // vazirmatn | iransans | yekanbakh | dana | estedad | theme_inherit
			'title_font_size'           => 20,                // 16..28 (px)
			'subtitle_font_size'        => 14,                // 12..17 (px)
			'btn_font_size'             => 15,                // 13..18 (px)
			'input_style'               => 'filled',          // filled | outlined | underlined | soft_pill
			'input_height'              => 48,                // 42..58 (px)
			'input_bg_color'            => '#f8fafc',
			'input_border_color'        => '#d1d5db',
			'input_addon_style'         => 'icon',            // icon | ir_flag | none

			// 4.4. OTP Boxes, Countdown Timer Styles & Micro-Animations (Category 4)
			'digit_box_size'            => 48,                // 40..60 (px)
			'digit_box_gap'             => 8,                 // 4..16 (px)
			'timer_style'               => 'progress_bar',    // progress_bar | circular_ring | minimal_badge | simple_text
			'form_animation'            => 'fade_up',         // fade_up | zoom_spring | slide_rtl | none
			'otp_auto_submit'           => 1,
			'error_shake_effect'        => 1,

			// 5. WooCommerce & Integrations
			'wc_replace_myaccount'      => 1,
			'wc_checkout_otp_box'       => 1,
			'wp_login_integration'      => 0,
			'enable_global_modal'       => 1,
			'login_url_to_ashna'        => 1,                 // every front-end "log in"/"register" link (wp_login_url, PMPro, Dokan) → Ashna login page (needs a standalone page)
			'replace_member_forms'      => 1,                 // guest login forms of PMPro / Ultimate Member / MemberPress shortcodes → Ashna form
			'role_redirects'            => array(),           // role => URL after sign-in
			'dokan_vendor_signup'       => 1,                 // vendor sign-up inside the OTP form when Dokan is active

			// 6. Security, Firewall & Captcha
			'max_requests_per_hour'     => 5,
			'max_ip_requests_per_hour'  => 15,
			'max_verify_attempts'       => 5,
			'lockout_duration'          => 900,               // 15 minutes
			'trust_proxy_headers'       => 1,                 // read proxy headers, but only from trusted proxies (Cloudflare, private network, list below)
			'trusted_proxies'           => '',                // extra proxy/CDN IPs or CIDRs (e.g. ArvanCloud ranges), one per line
			'max_requests_per_day'      => 10,                // codes per mobile/e-mail per 24 hours
			'max_ip_requests_per_minute' => 5,                // code requests per IP per minute
			'max_subnet_requests_per_minute' => 20,           // per /24 (IPv4) or /64 (IPv6) network per minute; 0 = off
			'attack_mode_threshold'     => 20,                // site-wide requests per minute that switch on attack mode; 0 = off
			'attack_mode_minutes'       => 30,                // how long attack mode (captcha for everyone) lasts
			'daily_send_cap'            => 0,                 // max codes sent site-wide per day (credit guard); 0 = unlimited
			'captcha_type'              => 'none',            // none | arcaptcha | math | recaptcha_v3 | turnstile
			'captcha_site_key'          => '',
			'captcha_secret_key'        => '',
			'blocked_phones'            => '',                // newline or comma separated
			'blocked_ips'               => '',                // newline or comma separated
			'whitelisted_identifiers'   => '',                // newline or comma separated

			// 7. Maintenance
			'log_retention_days'        => 30,
			'delete_data_on_uninstall'  => 0,
		);
	}

	/**
	 * Get all settings merged with defaults (cached in memory per request)
	 *
	 * @return array
	 */
	public static function get_settings() {
		if ( null !== self::$settings_cache ) {
			return self::$settings_cache;
		}

		$saved = get_option( 'ashna_otp_settings', array() );
		if ( ! is_array( $saved ) ) {
			$saved = array();
		}

		$merged = wp_parse_args( $saved, self::default_settings() );

		if ( empty( $merged['email_from_name'] ) ) {
			$merged['email_from_name'] = get_bloginfo( 'name' );
		}
		if ( empty( $merged['email_from_address'] ) ) {
			$merged['email_from_address'] = get_bloginfo( 'admin_email' );
		}

		self::$settings_cache = $merged;
		return self::$settings_cache;
	}

	/**
	 * Update settings in DB and refresh runtime cache
	 *
	 * @param array $new_settings Sanitized settings array.
	 * @return bool
	 */
	public static function save_settings( $new_settings ) {
		self::$settings_cache = null;
		return update_option( 'ashna_otp_settings', $new_settings );
	}

	/**
	 * Flush runtime settings cache
	 */
	public static function flush_cache() {
		self::$settings_cache = null;
	}

	/**
	 * Site-local "now" on the scale used for created_at / expires_at (site wall clock, formatted
	 * with gmdate()). Same value as current_time( 'timestamp' ).
	 *
	 * Never strtotime( current_time( 'mysql' ) ): strtotime() reads PHP's default timezone, which
	 * some plugins change with date_default_timezone_set() (Site Health warns about it). With
	 * Tehran as the default, codes would be born expired and minute limits would span 3.5 hours.
	 *
	 * @return int
	 */
	public static function local_now() {
		return time() + (int) ( (float) get_option( 'gmt_offset' ) * HOUR_IN_SECONDS );
	}

	/**
	 * A stored local datetime ('Y-m-d H:i:s') on the local_now() scale, independent of PHP's timezone.
	 *
	 * @param string $datetime Local datetime from the log table.
	 * @return int 0 when it cannot be parsed.
	 */
	public static function local_ts( $datetime ) {
		$parsed = date_create_immutable_from_format( '!Y-m-d H:i:s', (string) $datetime, new DateTimeZone( 'UTC' ) );
		return $parsed ? $parsed->getTimestamp() : 0;
	}

	/**
	 * Get a specific setting value
	 *
	 * @param string $key     Setting key.
	 * @param mixed  $default Fallback default.
	 * @return mixed
	 */
	public static function get_option( $key, $default = null ) {
		$settings = self::get_settings();
		if ( isset( $settings[ $key ] ) ) {
			return $settings[ $key ];
		}
		return $default;
	}

	/**
	 * Coerce a request value to a string.
	 *
	 * PHP string functions (strlen, ltrim, strtolower, ...) throw a TypeError on PHP 8 when they
	 * receive an array, so a request such as `redirect_to[]=x` used to end in a blank HTTP 500.
	 * Every value taken straight out of $_POST/$_GET/$_REQUEST goes through here first.
	 *
	 * @param mixed  $value    Raw request value.
	 * @param string $fallback Returned when the request sent a list or an object.
	 * @return string
	 */
	public static function as_string( $value, $fallback = '' ) {
		return is_scalar( $value ) ? (string) $value : $fallback;
	}

	/**
	 * Convert Persian and Arabic numerals to English numerals
	 *
	 * @param string $input Input string.
	 * @return string
	 */
	public static function convert_digits( $input ) {
		$persian = array( '۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹' );
		$arabic  = array( '٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩' );
		$english = array( '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' );

		$input = str_replace( $persian, $english, (string) $input );
		$input = str_replace( $arabic, $english, $input );
		return trim( $input );
	}

	/**
	 * Normalize Iranian mobile number to standard 09XXXXXXXXX format
	 *
	 * @param string $phone Raw phone number.
	 * @return string Normalized phone or cleaned digits.
	 */
	public static function normalize_phone( $phone ) {
		$phone = self::convert_digits( $phone );
		$phone = preg_replace( '/[^0-9]/', '', $phone );

		if ( strpos( $phone, '0098' ) === 0 ) {
			$phone = '0' . substr( $phone, 4 );
		} elseif ( strpos( $phone, '98' ) === 0 && strlen( $phone ) === 12 ) {
			$phone = '0' . substr( $phone, 2 );
		} elseif ( strpos( $phone, '9' ) === 0 && strlen( $phone ) === 10 ) {
			$phone = '0' . $phone;
		}

		return $phone;
	}

	/**
	 * Format phone number to international format (989XXXXXXXXX or +989XXXXXXXXX)
	 *
	 * @param string $phone     Phone number.
	 * @param bool   $with_plus Whether to prepend '+'.
	 * @return string
	 */
	public static function to_international_phone( $phone, $with_plus = false ) {
		$normalized = self::normalize_phone( $phone );
		if ( strpos( $normalized, '0' ) === 0 ) {
			$intl = '98' . substr( $normalized, 1 );
		} else {
			$intl = $normalized;
		}
		return $with_plus ? '+' . $intl : $intl;
	}

	/**
	 * Validate Iranian mobile number
	 *
	 * @param string $phone Phone number.
	 * @return bool
	 */
	public static function is_valid_phone( $phone ) {
		$normalized = self::normalize_phone( $phone );
		return (bool) preg_match( '/^09[0-9]{9}$/', $normalized );
	}

	/**
	 * Detect whether input is 'phone', 'email', or 'invalid'
	 *
	 * @param string $input Raw user input.
	 * @return array { type: 'phone'|'email'|'invalid', normalized: string }
	 */
	public static function parse_identifier( $input ) {
		$converted = trim( (string) self::convert_digits( $input ) );

		// 191 = the log table's recipient column (utf8mb4 index limit); no real address is longer.
		if ( strlen( $converted ) <= 191 && is_email( $converted ) ) {
			return array(
				'type'       => 'email',
				'normalized' => strtolower( sanitize_email( $converted ) ),
			);
		}

		$phone = self::normalize_phone( $converted );
		if ( self::is_valid_phone( $phone ) ) {
			return array(
				'type'       => 'phone',
				'normalized' => $phone,
			);
		}

		return array(
			'type'       => 'invalid',
			'normalized' => sanitize_text_field( $converted ),
		);
	}

	/**
	 * Mask phone or email for display
	 *
	 * @param string $identifier Phone or email.
	 * @return string
	 */
	public static function mask_identifier( $identifier ) {
		if ( is_email( $identifier ) ) {
			$parts  = explode( '@', $identifier );
			$name   = $parts[0];
			$domain = $parts[1];
			$masked = substr( $name, 0, min( 2, strlen( $name ) ) ) . '***';
			return $masked . '@' . $domain;
		}

		if ( strlen( $identifier ) === 11 ) {
			return substr( $identifier, 0, 4 ) . '***' . substr( $identifier, -4 );
		}

		return $identifier;
	}

	/**
	 * Get the visitor's IP address (proxy headers only from trusted proxies; see Ashna_IP).
	 *
	 * @return string
	 */
	public static function get_client_ip() {
		return Ashna_IP::client();
	}

	/**
	 * Generate numeric OTP code
	 *
	 * @param int $length Length between 4 and 8.
	 * @return string
	 */
	public static function generate_otp_code( $length = 5 ) {
		$length = max( 4, min( 8, absint( $length ) ) );
		$min    = (int) pow( 10, $length - 1 );
		$max    = (int) pow( 10, $length ) - 1;
		return (string) wp_rand( $min, $max );
	}

	/**
	 * Parse newline or comma separated list into clean array
	 *
	 * @param string $raw Raw list string.
	 * @return array
	 */
	public static function parse_list( $raw ) {
		if ( empty( $raw ) ) {
			return array();
		}
		$items = preg_split( '/[\r\n,]+/', (string) $raw );
		$clean = array();
		foreach ( $items as $item ) {
			$val = trim( self::convert_digits( $item ) );
			if ( '' !== $val ) {
				$clean[] = $val;
			}
		}
		return array_unique( $clean );
	}

	/**
	 * Return the authentic official Bale Messenger logo (using Wikimedia Commons File:Bale_logo.png with local fallback)
	 *
	 * @param int $size Width/Height in px.
	 * @return string HTML markup.
	 */
	public static function get_bale_logo_svg( $size = 24 ) {
		$size      = absint( $size ) ? absint( $size ) : 24;
		$local_url = ASHNA_OTP_URL . 'assets/images/bale-logo.png?v=' . ASHNA_OTP_VERSION;
		return sprintf(
			'<img class="ashna-bale-real-logo" src="%2$s" width="%1$d" height="%1$d" alt="Bale" style="width:%1$dpx !important;height:%1$dpx !important;min-width:%1$dpx;min-height:%1$dpx;max-width:none !important;object-fit:contain !important;display:block !important;flex-shrink:0 !important;border:none !important;box-shadow:none !important;background:transparent !important;filter:drop-shadow(0 0 6px rgba(10,202,155,0.55));" />',
			$size,
			esc_url( $local_url )
		);
	}

	/**
	 * Convert a hex color (#ffffff) and percentage opacity (0..100) into an rgba() CSS value
	 *
	 * @param string $hex         Hex color code.
	 * @param int    $opacity_pct Opacity percentage (0 to 100).
	 * @return string
	 */
	public static function hex_to_rgba( $hex, $opacity_pct = 100 ) {
		$hex = ltrim( trim( (string) $hex ), '#' );
		if ( 3 === strlen( $hex ) ) {
			$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
		}
		if ( 6 !== strlen( $hex ) || ! ctype_xdigit( $hex ) ) {
			return 'rgba(255, 255, 255, 0.85)';
		}
		$r     = hexdec( substr( $hex, 0, 2 ) );
		$g     = hexdec( substr( $hex, 2, 2 ) );
		$b     = hexdec( substr( $hex, 4, 2 ) );
		$alpha = max( 0, min( 100, (int) $opacity_pct ) ) / 100;
		return sprintf( 'rgba(%d, %d, %d, %s)', $r, $g, $b, rtrim( rtrim( number_format( $alpha, 2, '.', '' ), '0' ), '.' ) ?: '0' );
	}

	/**
	 * Return CSS font-family stack for the selected Persian font family
	 *
	 * @param string $font_key Font identifier.
	 * @return string
	 */
	public static function get_font_stack( $font_key = 'vazirmatn' ) {
		switch ( $font_key ) {
			case 'iransans':
				return "'IRANSansX', 'IRANSans', 'IRANSansWeb', 'Vazirmatn', Tahoma, sans-serif";
			case 'yekanbakh':
				return "'YekanBakh', 'Yekan Bakh', 'YekanBakhFaNum', 'IRANYekan', 'IRANYekanX', 'Vazirmatn', Tahoma, sans-serif";
			case 'dana':
				return "'Dana', 'DanaFaNum', 'Anjoman', 'Vazirmatn', Tahoma, sans-serif";
			case 'estedad':
				return "'Estedad', 'Shabnam', 'Vazirmatn', Tahoma, sans-serif";
			case 'theme_inherit':
				return 'inherit';
			case 'vazirmatn':
			default:
				return "'Vazirmatn', Tahoma, -apple-system, BlinkMacSystemFont, sans-serif";
		}
	}
}


// ---- Source: includes/core/class-ashna-ip.php ----
/**
 * Client IP resolution that cannot be spoofed with request headers.
 *
 * Proxy headers (CF-Connecting-IP, X-Forwarded-For, AR-Real-IP, X-Real-IP) are read only
 * when the TCP peer (REMOTE_ADDR) is a proxy the site actually sits behind: Cloudflare's
 * published edge ranges, a private/loopback address (local reverse proxy or load balancer)
 * or a range the site owner listed (e.g. ArvanCloud). Anyone else can put any IP in those
 * headers, so for them the peer address is used — rotating fake headers no longer resets
 * per-IP limits.
 *
 * @package Ashna
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Ashna_IP {

	/**
	 * Cloudflare edge ranges (https://www.cloudflare.com/ips/).
	 */
	const CLOUDFLARE = array(
		'173.245.48.0/20',
		'103.21.244.0/22',
		'103.22.200.0/22',
		'103.31.4.0/22',
		'141.101.64.0/18',
		'108.162.192.0/18',
		'190.93.240.0/20',
		'188.114.96.0/20',
		'197.234.240.0/22',
		'198.41.128.0/17',
		'162.158.0.0/15',
		'104.16.0.0/13',
		'104.24.0.0/14',
		'172.64.0.0/13',
		'131.0.72.0/22',
		'2400:cb00::/32',
		'2606:4700::/32',
		'2803:f800::/32',
		'2405:b500::/32',
		'2405:8100::/32',
		'2a06:98c0::/29',
		'2c0f:f248::/32',
	);

	/**
	 * Private, loopback and link-local ranges (a proxy on the same host or network).
	 */
	const PRIVATE_RANGES = array(
		'10.0.0.0/8',
		'172.16.0.0/12',
		'192.168.0.0/16',
		'127.0.0.0/8',
		'100.64.0.0/10',
		'169.254.0.0/16',
		'::1/128',
		'fc00::/7',
		'fe80::/10',
	);

	/**
	 * Request headers proxies use to pass the visitor address.
	 */
	const PROXY_HEADERS = array( 'HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_AR_REAL_IP', 'HTTP_X_REAL_IP' );

	/**
	 * The visitor's IP address.
	 *
	 * @return string
	 */
	public static function client() {
		$remote = self::valid( self::server( 'REMOTE_ADDR' ) );
		if ( '' === $remote ) {
			$remote = '127.0.0.1';
		}

		$ip = $remote;
		if ( Ashna_Helper::get_option( 'trust_proxy_headers', 1 ) && self::is_trusted_proxy( $remote ) ) {
			$ip = self::from_proxy_headers( $remote );
		} elseif ( self::has_proxy_headers() && ! self::is_private( $remote ) ) {
			self::note_untrusted_proxy( $remote );
		}

		/**
		 * Filters the resolved visitor IP.
		 *
		 * @param string $ip     Resolved IP.
		 * @param string $remote TCP peer address (REMOTE_ADDR).
		 */
		$filtered = apply_filters( 'ashna_otp_client_ip', $ip, $remote );
		$filtered = self::valid( $filtered );
		return '' !== $filtered ? $filtered : $ip;
	}

	/**
	 * Visitor IP as reported by a trusted proxy.
	 *
	 * @param string $remote Trusted TCP peer.
	 * @return string
	 */
	private static function from_proxy_headers( $remote ) {
		// Cloudflare overwrites CF-Connecting-IP itself, so it is authoritative when the peer is Cloudflare.
		if ( self::is_cloudflare( $remote ) ) {
			$cf = self::valid( self::server( 'HTTP_CF_CONNECTING_IP' ) );
			if ( '' !== $cf ) {
				return $cf;
			}
		}

		// A CDN edge listed by the site owner (e.g. ArvanCloud) sends its own visitor header.
		if ( ! self::is_private( $remote ) ) {
			$arvan = self::valid( self::server( 'HTTP_AR_REAL_IP' ) );
			if ( '' !== $arvan ) {
				return $arvan;
			}
		}

		// Every proxy appends the address it received the request from: walk the chain from the
		// closest hop and stop at the first address that is not one of our proxies. Entries left
		// of that point were written by the client and are ignored.
		$chain = self::forwarded_chain();
		if ( ! empty( $chain ) ) {
			foreach ( array_reverse( $chain ) as $hop ) {
				if ( ! self::is_trusted_proxy( $hop ) ) {
					return $hop;
				}
			}
			return $chain[0];
		}

		foreach ( array( 'HTTP_AR_REAL_IP', 'HTTP_X_REAL_IP' ) as $header ) {
			$value = self::valid( self::server( $header ) );
			if ( '' !== $value ) {
				return $value;
			}
		}

		return $remote;
	}

	/**
	 * Valid IPs from X-Forwarded-For, left (client) to right (closest proxy).
	 *
	 * @return string[]
	 */
	private static function forwarded_chain() {
		$raw = self::server( 'HTTP_X_FORWARDED_FOR' );
		if ( '' === $raw ) {
			return array();
		}
		$chain = array();
		foreach ( explode( ',', $raw ) as $part ) {
			$ip = self::valid( $part );
			if ( '' !== $ip ) {
				$chain[] = $ip;
			}
		}
		return array_slice( $chain, -20 );
	}

	/**
	 * Whether a peer is a proxy whose headers may be read.
	 *
	 * @param string $ip IP.
	 * @return bool
	 */
	public static function is_trusted_proxy( $ip ) {
		if ( self::is_private( $ip ) || self::is_cloudflare( $ip ) ) {
			return true;
		}
		/**
		 * Extra trusted proxy IPs/CIDRs (load balancers, CDNs).
		 *
		 * @param string[] $ranges Ranges from the settings.
		 */
		$ranges = apply_filters( 'ashna_otp_trusted_proxies', self::custom_proxies() );
		return self::in_any( $ip, (array) $ranges );
	}

	/**
	 * Proxy ranges entered by the site owner.
	 *
	 * @return string[]
	 */
	public static function custom_proxies() {
		$ranges = array();
		foreach ( preg_split( '/[\s,]+/', (string) Ashna_Helper::get_option( 'trusted_proxies', '' ) ) as $item ) {
			$item = trim( $item );
			if ( '' !== $item && self::valid_range( $item ) ) {
				$ranges[] = $item;
			}
		}
		return $ranges;
	}

	/**
	 * Whether an IP is in Cloudflare's edge ranges.
	 *
	 * @param string $ip IP.
	 * @return bool
	 */
	public static function is_cloudflare( $ip ) {
		return self::in_any( $ip, self::CLOUDFLARE );
	}

	/**
	 * Whether an IP is private, loopback or link-local.
	 *
	 * @param string $ip IP.
	 * @return bool
	 */
	public static function is_private( $ip ) {
		return self::in_any( $ip, self::PRIVATE_RANGES );
	}

	/**
	 * Whether an IP is inside any of the given IPs/CIDRs.
	 *
	 * @param string   $ip     IP.
	 * @param string[] $ranges IPs or CIDRs.
	 * @return bool
	 */
	public static function in_any( $ip, array $ranges ) {
		foreach ( $ranges as $range ) {
			if ( self::in_range( $ip, $range ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Whether an IP is inside an IP/CIDR (IPv4 or IPv6).
	 *
	 * @param string $ip    IP.
	 * @param string $range IP or CIDR.
	 * @return bool
	 */
	public static function in_range( $ip, $range ) {
		$range = trim( (string) $range );
		$bits  = null;
		if ( false !== strpos( $range, '/' ) ) {
			list( $range, $bits ) = explode( '/', $range, 2 );
			$bits                 = (int) $bits;
		}
		$ip_bin    = @inet_pton( (string) $ip ); // phpcs:ignore Generic.PHP.NoSilencedErrors.Discouraged
		$range_bin = @inet_pton( $range ); // phpcs:ignore Generic.PHP.NoSilencedErrors.Discouraged
		if ( false === $ip_bin || false === $range_bin || strlen( $ip_bin ) !== strlen( $range_bin ) ) {
			return false;
		}
		$max  = strlen( $ip_bin ) * 8;
		$bits = null === $bits ? $max : max( 0, min( $max, $bits ) );

		$bytes = intdiv( $bits, 8 );
		if ( $bytes > 0 && substr( $ip_bin, 0, $bytes ) !== substr( $range_bin, 0, $bytes ) ) {
			return false;
		}
		$rest = $bits % 8;
		if ( 0 === $rest ) {
			return true;
		}
		$mask = ( 0xff << ( 8 - $rest ) ) & 0xff;
		return ( ord( $ip_bin[ $bytes ] ) & $mask ) === ( ord( $range_bin[ $bytes ] ) & $mask );
	}

	/**
	 * Network an IP belongs to: /24 for IPv4, /64 for IPv6 (attackers rotate inside it).
	 *
	 * @param string $ip IP.
	 * @return string
	 */
	public static function subnet( $ip ) {
		$bin = @inet_pton( (string) $ip ); // phpcs:ignore Generic.PHP.NoSilencedErrors.Discouraged
		if ( false === $bin ) {
			return '';
		}
		if ( 4 === strlen( $bin ) ) {
			return inet_ntop( substr( $bin, 0, 3 ) . "\0" ) . '/24';
		}
		return inet_ntop( substr( $bin, 0, 8 ) . str_repeat( "\0", 8 ) ) . '/64';
	}

	/**
	 * Normalized IP or ''.
	 *
	 * @param mixed $value Candidate.
	 * @return string
	 */
	public static function valid( $value ) {
		$value = trim( (string) $value );
		if ( '' !== $value && '[' === $value[0] && false !== strpos( $value, ']' ) ) {
			$value = substr( $value, 1, strpos( $value, ']' ) - 1 ); // [IPv6]:port
		} elseif ( substr_count( $value, ':' ) === 1 && false !== strpos( $value, '.' ) ) {
			$value = substr( $value, 0, strpos( $value, ':' ) ); // IPv4:port
		}
		if ( ! filter_var( $value, FILTER_VALIDATE_IP ) ) {
			return '';
		}
		$bin = @inet_pton( $value ); // phpcs:ignore Generic.PHP.NoSilencedErrors.Discouraged
		return false === $bin ? '' : inet_ntop( $bin );
	}

	/**
	 * Whether a string is a valid IP or CIDR.
	 *
	 * @param string $range Candidate.
	 * @return bool
	 */
	public static function valid_range( $range ) {
		$parts = explode( '/', (string) $range, 2 );
		if ( '' === self::valid( $parts[0] ) ) {
			return false;
		}
		if ( ! isset( $parts[1] ) ) {
			return true;
		}
		$max = false !== strpos( $parts[0], ':' ) ? 128 : 32;
		return ctype_digit( $parts[1] ) && (int) $parts[1] <= $max;
	}

	/**
	 * Whether the request carries proxy headers.
	 *
	 * @return bool
	 */
	private static function has_proxy_headers() {
		foreach ( self::PROXY_HEADERS as $header ) {
			if ( '' !== self::server( $header ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Remember that proxy headers arrived from a peer we do not trust, so the admin can be
	 * told the site may be behind an unlisted CDN (written at most every 10 minutes).
	 *
	 * @param string $remote Peer address.
	 */
	private static function note_untrusted_proxy( $remote ) {
		$hint = get_option( 'ashna_otp_proxy_hint', array() );
		$now  = time();
		if ( is_array( $hint ) && isset( $hint['seen'] ) && $now - (int) $hint['seen'] < 10 * MINUTE_IN_SECONDS ) {
			return;
		}
		$headers = array();
		foreach ( self::PROXY_HEADERS as $header ) {
			if ( '' !== self::server( $header ) ) {
				$headers[] = str_replace( '_', '-', substr( $header, 5 ) );
			}
		}
		update_option(
			'ashna_otp_proxy_hint',
			array(
				'remote'  => $remote,
				'headers' => $headers,
				'arvan'   => '' !== self::server( 'HTTP_AR_REAL_IP' ),
				'seen'    => $now,
			),
			false
		);
	}

	/**
	 * Recent "proxy headers from an untrusted peer" sighting, or null.
	 *
	 * @return array|null
	 */
	public static function untrusted_proxy_hint() {
		$hint = get_option( 'ashna_otp_proxy_hint', array() );
		if ( ! is_array( $hint ) || empty( $hint['remote'] ) || time() - (int) $hint['seen'] > DAY_IN_SECONDS ) {
			return null;
		}
		if ( self::is_trusted_proxy( $hint['remote'] ) ) {
			return null; // Already fixed.
		}
		return $hint;
	}

	/**
	 * What this request looks like, for the settings screen.
	 *
	 * @return array
	 */
	public static function diagnostics() {
		$headers = array();
		foreach ( self::PROXY_HEADERS as $header ) {
			$value = self::server( $header );
			if ( '' !== $value ) {
				$headers[ str_replace( '_', '-', substr( $header, 5 ) ) ] = $value;
			}
		}
		$remote = self::valid( self::server( 'REMOTE_ADDR' ) );
		return array(
			'remote'   => $remote,
			'headers'  => $headers,
			'trusted'  => '' !== $remote && self::is_trusted_proxy( $remote ),
			'resolved' => self::client(),
		);
	}

	/**
	 * Raw $_SERVER value.
	 *
	 * @param string $key Key.
	 * @return string
	 */
	private static function server( $key ) {
		return isset( $_SERVER[ $key ] ) ? sanitize_text_field( wp_unslash( $_SERVER[ $key ] ) ) : '';
	}
}


// ---- Source: includes/core/class-ashna-jwt.php ----
/**
 * Minimal, strict OpenID Connect ID-token verifier.
 *
 * Deliberately small: one algorithm (RS256), one job (verify a signed JWT against a JWKS and
 * check the claims that matter). No package, no "alg" negotiation, no key confusion.
 *
 * @package Ashna
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Ashna_JWT {

	/**
	 * Verify a JWT and return its claims.
	 *
	 * @param string $jwt   Compact JWS.
	 * @param array  $keys  JWKS keys array (`keys` member of the JWKS document).
	 * @param array  $args  {
	 *     @type string $iss   Expected issuer (exact match).
	 *     @type string $aud   Expected audience (client id).
	 *     @type string $nonce Expected nonce, when the flow uses one.
	 *     @type int    $leeway Clock skew allowance in seconds.
	 * }
	 * @return array|WP_Error Claims on success.
	 */
	public static function verify( $jwt, array $keys, array $args ) {
		$args = wp_parse_args(
			$args,
			array(
				'iss'    => '',
				'aud'    => '',
				'nonce'  => '',
				'leeway' => 60,
			)
		);

		$parts = explode( '.', (string) $jwt );
		if ( 3 !== count( $parts ) ) {
			return new WP_Error( 'ashna_jwt_shape', 'توکن هویت معتبر نیست.' );
		}

		$header = json_decode( self::b64url_decode( $parts[0] ), true );
		$claims = json_decode( self::b64url_decode( $parts[1] ), true );
		$sig    = self::b64url_decode( $parts[2] );

		if ( ! is_array( $header ) || ! is_array( $claims ) || '' === $sig ) {
			return new WP_Error( 'ashna_jwt_shape', 'توکن هویت معتبر نیست.' );
		}

		// Exactly one algorithm. "none" and HS256 are the two classic bypasses: refuse both by
		// name, not by exclusion, so a future provider cannot widen this by accident.
		$alg = isset( $header['alg'] ) ? (string) $header['alg'] : '';
		if ( 'RS256' !== $alg ) {
			return new WP_Error( 'ashna_jwt_alg', 'الگوریتم امضای توکن پذیرفته نیست.' );
		}

		$kid = isset( $header['kid'] ) ? (string) $header['kid'] : '';

		$public_key = self::public_key_for( $keys, $kid );
		if ( is_wp_error( $public_key ) ) {
			return $public_key;
		}

		$ok = openssl_verify( $parts[0] . '.' . $parts[1], $sig, $public_key, OPENSSL_ALGO_SHA256 );
		if ( 1 !== $ok ) {
			return new WP_Error( 'ashna_jwt_signature', 'امضای توکن هویت معتبر نیست.' );
		}

		$now = time();

		if ( ! empty( $args['iss'] ) && ( ! isset( $claims['iss'] ) || ! is_string( $claims['iss'] ) || $args['iss'] !== $claims['iss'] ) ) {
			return new WP_Error( 'ashna_jwt_iss', 'صادرکنندهٔ توکن هویت مورد انتظار نیست.' );
		}

		if ( '' !== (string) $args['aud'] ) {
			$aud = isset( $claims['aud'] ) ? $claims['aud'] : array();
			$aud = is_array( $aud ) ? $aud : array( $aud );
			$aud = array_map( 'strval', $aud );
			if ( ! in_array( (string) $args['aud'], $aud, true ) ) {
				return new WP_Error( 'ashna_jwt_aud', 'توکن هویت برای این سایت صادر نشده است.' );
			}
		}

		if ( empty( $claims['exp'] ) || (int) $claims['exp'] < ( $now - (int) $args['leeway'] ) ) {
			return new WP_Error( 'ashna_jwt_expired', 'توکن هویت منقضی شده است.' );
		}

		if ( ! empty( $claims['iat'] ) && (int) $claims['iat'] > ( $now + (int) $args['leeway'] ) ) {
			return new WP_Error( 'ashna_jwt_iat', 'زمان توکن هویت معتبر نیست.' );
		}

		if ( ! empty( $claims['nbf'] ) && (int) $claims['nbf'] > ( $now + (int) $args['leeway'] ) ) {
			return new WP_Error( 'ashna_jwt_nbf', 'توکن هویت هنوز معتبر نشده است.' );
		}

		if ( '' !== (string) $args['nonce'] ) {
			if ( ! isset( $claims['nonce'] ) || ! hash_equals( (string) $args['nonce'], (string) $claims['nonce'] ) ) {
				return new WP_Error( 'ashna_jwt_nonce', 'nonce توکن هویت مطابقت ندارد.' );
			}
		}

		if ( empty( $claims['sub'] ) || ! is_scalar( $claims['sub'] ) ) {
			return new WP_Error( 'ashna_jwt_sub', 'شناسهٔ کاربر در توکن هویت نیست.' );
		}

		return $claims;
	}

	/**
	 * Pick the RSA key that signed the token (by `kid`, else the only RSA key present).
	 *
	 * @param array  $keys JWKS keys.
	 * @param string $kid  Key id from the token header.
	 * @return string|WP_Error PEM public key.
	 */
	private static function public_key_for( array $keys, $kid ) {
		$candidates = array();
		foreach ( $keys as $key ) {
			if ( ! is_array( $key ) || empty( $key['kty'] ) || 'RSA' !== $key['kty'] ) {
				continue;
			}
			if ( isset( $key['use'] ) && 'sig' !== $key['use'] ) {
				continue;
			}
			$candidates[] = $key;
		}

		if ( '' !== $kid ) {
			foreach ( $candidates as $key ) {
				if ( isset( $key['kid'] ) && (string) $key['kid'] === $kid ) {
					return self::jwk_to_pem( $key );
				}
			}
			// The provider rotated its keys: the caller refetches the JWKS once and retries.
			return new WP_Error( 'ashna_jwt_kid', 'کلید امضای توکن پیدا نشد.' );
		}

		if ( 1 === count( $candidates ) ) {
			return self::jwk_to_pem( $candidates[0] );
		}

		return new WP_Error( 'ashna_jwt_kid', 'کلید امضای توکن پیدا نشد.' );
	}

	/**
	 * Convert an RSA JWK ({n, e}) into a PEM public key.
	 *
	 * @param array $jwk JWK.
	 * @return string|WP_Error
	 */
	private static function jwk_to_pem( array $jwk ) {
		if ( empty( $jwk['n'] ) || empty( $jwk['e'] ) ) {
			return new WP_Error( 'ashna_jwt_jwk', 'کلید عمومی ارائه‌دهنده ناقص است.' );
		}

		$n = self::b64url_decode( $jwk['n'] );
		$e = self::b64url_decode( $jwk['e'] );
		if ( '' === $n || '' === $e ) {
			return new WP_Error( 'ashna_jwt_jwk', 'کلید عمومی ارائه‌دهنده ناقص است.' );
		}

		$modulus  = self::der_integer( $n );
		$exponent = self::der_integer( $e );

		$rsa_key = self::der( 0x30, $modulus . $exponent ); // SEQUENCE { INTEGER n, INTEGER e }

		// AlgorithmIdentifier: rsaEncryption (1.2.840.113549.1.1.1) + NULL parameters
		$algorithm = self::der( 0x30, "\x06\x09\x2a\x86\x48\x86\xf7\x0d\x01\x01\x01\x05\x00" );

		$subject_public_key = self::der( 0x03, "\x00" . $rsa_key ); // BIT STRING, 0 unused bits
		$spki               = self::der( 0x30, $algorithm . $subject_public_key );

		$pem = "-----BEGIN PUBLIC KEY-----\n"
			. chunk_split( base64_encode( $spki ), 64, "\n" ) // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- PEM encoding, not obfuscation.
			. "-----END PUBLIC KEY-----\n";

		$key = openssl_pkey_get_public( $pem );
		if ( false === $key ) {
			return new WP_Error( 'ashna_jwt_jwk', 'کلید عمومی ارائه‌دهنده خوانده نشد.' );
		}

		return $pem;
	}

	/**
	 * DER INTEGER from raw big-endian bytes (leading zero added when the high bit is set).
	 *
	 * @param string $bytes Raw bytes.
	 * @return string
	 */
	private static function der_integer( $bytes ) {
		$bytes = ltrim( $bytes, "\x00" );
		if ( '' === $bytes ) {
			$bytes = "\x00";
		}
		if ( ord( $bytes[0] ) > 0x7f ) {
			$bytes = "\x00" . $bytes;
		}
		return self::der( 0x02, $bytes );
	}

	/**
	 * Wrap bytes in a DER tag with a definite length.
	 *
	 * @param int    $tag   DER tag.
	 * @param string $bytes Payload.
	 * @return string
	 */
	private static function der( $tag, $bytes ) {
		$length = strlen( $bytes );
		if ( $length < 0x80 ) {
			$encoded = chr( $length );
		} else {
			$len_bytes = ltrim( pack( 'N', $length ), "\x00" ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- binary packing, not obfuscation.
			$encoded   = chr( 0x80 | strlen( $len_bytes ) ) . $len_bytes;
		}
		return chr( $tag ) . $encoded . $bytes;
	}

	/**
	 * Base64url decode (RFC 7515).
	 *
	 * @param string $value Encoded value.
	 * @return string
	 */
	public static function b64url_decode( $value ) {
		$value = strtr( (string) $value, '-_', '+/' );
		$pad   = strlen( $value ) % 4;
		if ( $pad ) {
			$value .= str_repeat( '=', 4 - $pad );
		}
		$decoded = base64_decode( $value, true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- JWT decoding, not obfuscation.
		return false === $decoded ? '' : $decoded;
	}
}


// ---- Source: includes/core/class-ashna-logger.php ----
/**
 * OTP Logger, Analytics & Log Table Repository
 *
 * @package Ashna
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Ashna_Logger {

	/**
	 * Get table name
	 *
	 * @return string
	 */
	public static function table_name() {
		global $wpdb;
		return $wpdb->prefix . 'ashna_otp_logs';
	}

	/**
	 * Column sizes of the log table (characters; response_message is a TEXT column, kept short).
	 *
	 * On MySQL, wpdb refuses the whole INSERT/UPDATE when one value is longer than its column, so
	 * values are trimmed first (gateway error pages can be long; addresses are already capped).
	 *
	 * @param array $row Column => value.
	 * @return array
	 */
	private static function fit_columns( array $row ) {
		$limits = array(
			'recipient'        => 191,
			'channel'          => 32,
			'gateway'          => 50,
			'otp_code'         => 20,
			'otp_hash'         => 255,
			'status'           => 32,
			'ip_address'       => 64,
			'ip_subnet'        => 64,
			'response_message' => 2000,
		);
		foreach ( $limits as $column => $max ) {
			if ( isset( $row[ $column ] ) && is_string( $row[ $column ] ) && mb_strlen( $row[ $column ], 'UTF-8' ) > $max ) {
				$row[ $column ] = mb_substr( $row[ $column ], 0, $max, 'UTF-8' );
			}
		}
		return $row;
	}

	/**
	 * Insert a new OTP log/session entry
	 *
	 * @param array $data Log data.
	 * @return int|false Inserted ID or false on error.
	 */
	public static function insert( $data ) {
		global $wpdb;

		$now_ts     = Ashna_Helper::local_now();
		$now_local  = gmdate( 'Y-m-d H:i:s', $now_ts );
		$expiry_sec = absint( Ashna_Helper::get_option( 'otp_expiry', 120 ) );
		$expires_at = gmdate( 'Y-m-d H:i:s', $now_ts + $expiry_sec );

		$defaults = array(
			'recipient'        => '',
			'channel'          => 'sms',
			'gateway'          => 'sandbox',
			'otp_code'         => '',
			'otp_hash'         => '',
			'status'           => 'sent',
			'attempts'         => 0,
			'ip_address'       => Ashna_Helper::get_client_ip(),
			'ip_subnet'        => '',
			'response_message' => '',
			'expires_at'       => $expires_at,
			'verified_at'      => null,
			'created_at'       => $now_local,
		);

		$row = wp_parse_args( $data, $defaults );
		if ( '' === $row['ip_subnet'] ) {
			$row['ip_subnet'] = Ashna_IP::subnet( $row['ip_address'] );
		}
		$row = self::fit_columns( $row );

		// Expire previous active codes for this recipient
		self::expire_previous_codes( $row['recipient'] );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$result = $wpdb->insert(
			self::table_name(),
			array(
				'recipient'        => $row['recipient'],
				'channel'          => $row['channel'],
				'gateway'          => $row['gateway'],
				'otp_code'         => $row['otp_code'],
				'otp_hash'         => $row['otp_hash'],
				'status'           => $row['status'],
				'attempts'         => (int) $row['attempts'],
				'ip_address'       => $row['ip_address'],
				'ip_subnet'        => $row['ip_subnet'],
				'response_message' => $row['response_message'],
				'expires_at'       => $row['expires_at'],
				'verified_at'      => $row['verified_at'],
				'created_at'       => $row['created_at'],
			),
			array( '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%s' )
		);

		if ( false === $result ) {
			return false;
		}

		self::flush_stats_cache();
		return (int) $wpdb->insert_id;
	}

	/**
	 * Reserve a send slot BEFORE any gateway is contacted.
	 *
	 * The row exists from the first millisecond, so concurrent requests count it and a burst
	 * of parallel requests cannot all pass the limits before anything was logged.
	 *
	 * @param string $recipient Normalized phone or email.
	 * @param string $ip        Visitor IP.
	 * @param string $subnet    Visitor network (/24 or /64).
	 * @return int Reservation (log row) ID, 0 on failure.
	 */
	public static function reserve( $recipient, $ip, $subnet ) {
		global $wpdb;
		$now = current_time( 'mysql' );
		$fit = self::fit_columns(
			array(
				'recipient'  => (string) $recipient,
				'ip_address' => (string) $ip,
				'ip_subnet'  => (string) $subnet,
			)
		);

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery
		$result = $wpdb->insert(
			self::table_name(),
			array(
				'recipient'        => $fit['recipient'],
				'channel'          => 'pending',
				'gateway'          => '',
				'otp_code'         => '',
				'otp_hash'         => '',
				'status'           => 'pending',
				'attempts'         => 0,
				'ip_address'       => $fit['ip_address'],
				'ip_subnet'        => $fit['ip_subnet'],
				'response_message' => '',
				'expires_at'       => $now,
				'created_at'       => $now,
			),
			array( '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s', '%s' )
		);

		return false === $result ? 0 : (int) $wpdb->insert_id;
	}

	/**
	 * Turn a reservation into the final log entry once the gateways answered.
	 *
	 * @param int   $id   Reservation ID.
	 * @param array $data channel, gateway, otp_code (display value), otp_hash, status (sent|failed), response_message.
	 * @return bool
	 */
	public static function complete( $id, array $data ) {
		global $wpdb;
		$table = self::table_name();

		if ( isset( $data['status'] ) && 'sent' === $data['status'] ) {
			// The caller already knows the recipient (it is in $data), so the lookup only runs for
			// a caller that did not pass one — same behaviour, one query less on every send.
			$recipient = isset( $data['recipient'] ) ? (string) $data['recipient'] : '';
			if ( '' !== $recipient ) {
				// Whatever the reservation stored (fit_columns() truncates long values), the row
				// is addressed with exactly the same string.
				$fitted    = self::fit_columns( array( 'recipient' => $recipient ) );
				$recipient = (string) $fitted['recipient'];
			} else {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$recipient = (string) $wpdb->get_var( $wpdb->prepare( "SELECT recipient FROM {$table} WHERE id = %d", $id ) );
			}
			if ( '' !== $recipient ) {
				// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
				$wpdb->query( $wpdb->prepare( "UPDATE {$table} SET status = 'expired' WHERE recipient = %s AND status = 'sent' AND id <> %d", $recipient, $id ) );
			}
		}

		$expiry_sec = absint( Ashna_Helper::get_option( 'otp_expiry', 120 ) );
		$fields     = array_intersect_key( $data, array_flip( array( 'channel', 'gateway', 'otp_code', 'otp_hash', 'status', 'response_message' ) ) );

		$fields['expires_at'] = gmdate( 'Y-m-d H:i:s', Ashna_Helper::local_now() + $expiry_sec );
		return self::update( $id, $fields );
	}

	/**
	 * Remove a reservation that was refused by the limits.
	 *
	 * @param int $id Reservation ID.
	 */
	public static function delete( $id ) {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->delete( self::table_name(), array( 'id' => absint( $id ) ), array( '%d' ) );
	}

	/**
	 * Flush cached admin analytics transients
	 */
	public static function flush_stats_cache() {
		delete_transient( 'ashna_admin_stats_cache' );
		delete_transient( 'ashna_admin_chart_cache' );
	}

	/**
	 * Mark previous sent codes for recipient as expired
	 *
	 * @param string $recipient Phone or email.
	 */
	public static function expire_previous_codes( $recipient ) {
		global $wpdb;
		$table = self::table_name();

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table name from $wpdb->prefix (%i needs WP 6.2).
		$wpdb->query(
			$wpdb->prepare(
				"UPDATE {$table} SET status = 'expired' WHERE recipient = %s AND status = 'sent'",
				$recipient
			)
		);
		// phpcs:enable
	}

	/**
	 * Update log status and message
	 *
	 * @param int   $id     Log ID.
	 * @param array $fields Fields to update.
	 * @return bool
	 */
	public static function update( $id, $fields ) {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$updated = (bool) $wpdb->update(
			self::table_name(),
			self::fit_columns( $fields ),
			array( 'id' => absint( $id ) )
		);
		if ( $updated ) {
			self::flush_stats_cache();
		}
		return $updated;
	}

	/**
	 * Get latest active OTP record for a recipient
	 *
	 * @param string $recipient Normalized phone or email.
	 * @return object|null
	 */
	public static function get_latest_record( $recipient ) {
		global $wpdb;
		$table = self::table_name();

		// The caller needs the state of the code, never the gateway's message text: selecting the
		// columns saves reading (and moving) the whole `response_message` TEXT column on every
		// sign-in attempt. `id` and `otp_hash` are part of the result contract.
		$columns = 'id, recipient, channel, gateway, otp_code, otp_hash, status, attempts, ip_address, ip_subnet, expires_at, verified_at, created_at';

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table/column list are fixed strings from $wpdb->prefix (%i needs WP 6.2).
		return $wpdb->get_row(
			$wpdb->prepare(
				"SELECT {$columns} FROM {$table} WHERE recipient = %s AND status <> 'pending' AND channel <> 'passkey' ORDER BY id DESC LIMIT 1",
				$recipient
			)
		);
		// phpcs:enable
	}

	/**
	 * Get paginated logs for admin page
	 *
	 * @param array $args Query arguments.
	 * @return array { items: array, total: int }
	 */
	public static function get_logs( $args = array() ) {
		global $wpdb;
		$table = self::table_name();

		$defaults = array(
			'per_page' => 20,
			'paged'    => 1,
			'search'   => '',
			'status'   => '',
			'channel'  => '',
		);
		$args     = wp_parse_args( $args, $defaults );

		$where  = array( '1=1' );
		$values = array();

		if ( ! empty( $args['search'] ) ) {
			$where[]  = '(recipient LIKE %s OR ip_address LIKE %s OR gateway LIKE %s)';
			$like     = '%' . $wpdb->esc_like( $args['search'] ) . '%';
			$values[] = $like;
			$values[] = $like;
			$values[] = $like;
		}

		if ( ! empty( $args['status'] ) ) {
			$where[]  = 'status = %s';
			$values[] = $args['status'];
		}

		if ( ! empty( $args['channel'] ) ) {
			$where[]  = 'channel = %s';
			$values[] = $args['channel'];
		}

		$where_sql = implode( ' AND ', $where );
		$offset    = max( 0, ( absint( $args['paged'] ) - 1 ) * absint( $args['per_page'] ) );
		$limit     = absint( $args['per_page'] );

		if ( ! empty( $values ) ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare -- placeholders live in $where_sql.
			$total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE {$where_sql}", $values ) );

			$query_values   = $values;
			$query_values[] = $limit;
			$query_values[] = $offset;
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.ReplacementsWrongNumber -- placeholders live in $where_sql.
			$items = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE {$where_sql} ORDER BY id DESC LIMIT %d OFFSET %d", $query_values ) );
		} else {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$items = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} ORDER BY id DESC LIMIT %d OFFSET %d", $limit, $offset ) );
		}

		return array(
			'items' => is_array( $items ) ? $items : array(),
			'total' => $total,
		);
	}

	/**
	 * Get summary statistics for admin dashboard (Single aggregated SQL + 60s Transient Cache)
	 *
	 * @return array
	 */
	public static function get_stats() {
		$cached = get_transient( 'ashna_admin_stats_cache' );
		if ( is_array( $cached ) ) {
			return $cached;
		}

		global $wpdb;
		$table = self::table_name();
		$today = gmdate( 'Y-m-d 00:00:00', Ashna_Helper::local_now() );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$agg = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT COUNT(*) AS total_all,
				        SUM(CASE WHEN created_at >= %s THEN 1 ELSE 0 END) AS today_count,
				        SUM(CASE WHEN status = 'verified' THEN 1 ELSE 0 END) AS verified_count,
				        SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) AS failed_count
				 FROM {$table}",
				$today
			)
		);
		$otp_users = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->usermeta} WHERE meta_key = 'ashna_registered_via_otp'" );
		// phpcs:enable

		$total_all      = $agg ? (int) $agg->total_all : 0;
		$today_count    = $agg ? (int) $agg->today_count : 0;
		$verified_count = $agg ? (int) $agg->verified_count : 0;
		$failed_count   = $agg ? (int) $agg->failed_count : 0;

		$conversion_rate = $total_all > 0 ? round( ( $verified_count / $total_all ) * 100, 1 ) : 0;

		$stats = array(
			'total'           => $total_all,
			'today'           => $today_count,
			'verified'        => $verified_count,
			'failed'          => $failed_count,
			'otp_users'       => $otp_users,
			'conversion_rate' => $conversion_rate,
		);

		set_transient( 'ashna_admin_stats_cache', $stats, 60 );
		return $stats;
	}

	/**
	 * Get 7-day chart analytics data without double timezone offset (Cached 60s)
	 *
	 * @param int $days Number of days.
	 * @return array
	 */
	public static function get_daily_chart_data( $days = 7 ) {
		if ( 7 === $days ) {
			$cached = get_transient( 'ashna_admin_chart_cache' );
			if ( is_array( $cached ) ) {
				return $cached;
			}
		}

		global $wpdb;
		$table    = self::table_name();
		$now_ts   = Ashna_Helper::local_now();
		$start_dt = gmdate( 'Y-m-d 00:00:00', $now_ts - ( ( $days - 1 ) * DAY_IN_SECONDS ) );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- table name from $wpdb->prefix (%i needs WP 6.2).
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT DATE(created_at) as day_date,
				        COUNT(*) as total_count,
				        SUM(CASE WHEN status = 'verified' THEN 1 ELSE 0 END) as verified_count,
				        SUM(CASE WHEN status = 'failed' THEN 1 ELSE 0 END) as failed_count
				 FROM {$table}
				 WHERE created_at >= %s
				 GROUP BY DATE(created_at)
				 ORDER BY day_date ASC",
				$start_dt
			),
			OBJECT_K
		);
		// phpcs:enable

		$chart   = array();
		$max_val = 1;

		for ( $i = $days - 1; $i >= 0; $i-- ) {
			$day_ts  = $now_ts - ( $i * DAY_IN_SECONDS );
			$day_key = gmdate( 'Y-m-d', $day_ts );
			// Pass true as 3rd param to date_i18n since $day_ts already includes site timezone offset
			$label   = date_i18n( 'j F', $day_ts, true );

			$total    = isset( $rows[ $day_key ] ) ? (int) $rows[ $day_key ]->total_count : 0;
			$verified = isset( $rows[ $day_key ] ) ? (int) $rows[ $day_key ]->verified_count : 0;
			$failed   = isset( $rows[ $day_key ] ) ? (int) $rows[ $day_key ]->failed_count : 0;

			if ( $total > $max_val ) {
				$max_val = $total;
			}

			$chart[] = array(
				'date'     => $day_key,
				'label'    => $label,
				'total'    => $total,
				'verified' => $verified,
				'failed'   => $failed,
			);
		}

		foreach ( $chart as &$point ) {
			$point['height_pct'] = $point['total'] > 0 ? max( 10, round( ( $point['total'] / $max_val ) * 100 ) ) : 4;
		}

		if ( 7 === $days ) {
			set_transient( 'ashna_admin_chart_cache', $chart, 60 );
		}

		return $chart;
	}

	/**
	 * Clear all logs or logs older than retention period
	 *
	 * @param bool $all Whether to truncate all logs.
	 * @return int Number of rows deleted.
	 */
	public static function clear_logs( $all = false ) {
		global $wpdb;
		$table = self::table_name();

		if ( $all ) {
			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
			$res = (int) $wpdb->query( "TRUNCATE TABLE {$table}" );
			self::flush_stats_cache();
			return $res;
		}

		$days   = max( 1, absint( Ashna_Helper::get_option( 'log_retention_days', 30 ) ) );
		$cutoff = gmdate( 'Y-m-d H:i:s', Ashna_Helper::local_now() - ( $days * DAY_IN_SECONDS ) );

		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$res = (int) $wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE created_at < %s", $cutoff ) );
		self::flush_stats_cache();
		return $res;
	}

	/**
	 * Scheduled WP-Cron callback to purge expired logs automatically
	 */
	public static function run_scheduled_cleanup() {
		self::clear_logs( false );
		Ashna_Security::purge_used_captcha_tokens();
	}
}


// ---- Source: includes/core/class-ashna-passkey.php ----
/**
 * W3C WebAuthn / FIDO2 Biometric & Passwordless Passkey Manager for Ashna
 *
 * Supports FaceID, TouchID, Android Biometrics, and Windows Hello without external dependencies.
 *
 * @package Ashna
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.Security.NonceVerification.Missing -- every AJAX handler below calls Ashna_Session::verify_request() first.
class Ashna_Passkey {

	/**
	 * User meta key storing array of passkey credentials
	 */
	const META_CREDENTIALS = '_ashna_passkeys';

	/**
	 * User meta key indexing individual credential IDs for fast lookup
	 */
	const META_CRED_INDEX = '_ashna_passkey_id';

	/**
	 * Constructor: Register AJAX endpoints, shortcode & WooCommerce My Account hooks
	 */
	public function __construct() {
		// Registration endpoints (logged-in users)
		add_action( 'wp_ajax_ashna_passkey_register_options', array( $this, 'ajax_register_options' ) );
		add_action( 'wp_ajax_ashna_passkey_register_verify', array( $this, 'ajax_register_verify' ) );
		add_action( 'wp_ajax_ashna_passkey_delete', array( $this, 'ajax_delete_passkey' ) );

		// Authentication endpoints (guest users & logged-in re-auth)
		add_action( 'wp_ajax_nopriv_ashna_passkey_login_options', array( $this, 'ajax_login_options' ) );
		add_action( 'wp_ajax_ashna_passkey_login_options', array( $this, 'ajax_login_options' ) );
		add_action( 'wp_ajax_nopriv_ashna_passkey_login_verify', array( $this, 'ajax_login_verify' ) );
		add_action( 'wp_ajax_ashna_passkey_login_verify', array( $this, 'ajax_login_verify' ) );

		// Shortcode for managing passkeys anywhere
		add_shortcode( 'ashna_passkey_manager', array( $this, 'render_passkey_manager_shortcode' ) );

		// WooCommerce My Account dashboard integration
		if ( Ashna_Helper::get_option( 'enable_passkey', 1 ) && Ashna_Helper::get_option( 'passkey_wc_myaccount', 1 ) ) {
			add_action( 'woocommerce_account_dashboard', array( $this, 'echo_passkey_manager_box' ), 25 );
		}
	}

	/**
	 * Get Relying Party ID (effective domain name without port or protocol)
	 *
	 * @return string
	 */
	public static function get_rp_id() {
		$host = wp_parse_url( home_url(), PHP_URL_HOST );
		return $host ? strtolower( $host ) : 'localhost';
	}

	/**
	 * Base64URL encode binary data
	 *
	 * @param string $data Binary string.
	 * @return string
	 */
	public static function base64url_encode( $data ) {
		return rtrim( strtr( base64_encode( $data ), '+/', '-_' ), '=' ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- WebAuthn base64url / PEM encoding.
	}

	/**
	 * Base64URL decode to binary string
	 *
	 * @param string $data Base64URL string.
	 * @return string
	 */
	public static function base64url_decode( $data ) {
		$remainder = strlen( $data ) % 4;
		if ( $remainder ) {
			$data .= str_repeat( '=', 4 - $remainder );
		}
		return (string) base64_decode( strtr( $data, '-_', '+/' ) ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode -- WebAuthn base64url decoding.
	}

	/**
	 * Get all registered Passkeys for a user
	 *
	 * @param int $user_id WordPress User ID.
	 * @return array
	 */
	public static function get_user_passkeys( $user_id ) {
		$list = get_user_meta( $user_id, self::META_CREDENTIALS, true );
		return is_array( $list ) ? $list : array();
	}

	/**
	 * Save a new Passkey credential for a user
	 *
	 * @param int   $user_id    WordPress User ID.
	 * @param array $credential Credential data array.
	 * @return bool
	 */
	public static function save_user_passkey( $user_id, $credential ) {
		if ( empty( $credential['id'] ) || empty( $credential['public_key_pem'] ) ) {
			return false;
		}

		$passkeys = self::get_user_passkeys( $user_id );
		$cred_id  = sanitize_text_field( $credential['id'] );

		// Keep max 8 passkeys per user
		if ( count( $passkeys ) >= 8 && ! isset( $passkeys[ $cred_id ] ) ) {
			array_shift( $passkeys );
		}

		$passkeys[ $cred_id ] = array(
			'id'             => $cred_id,
			'public_key_pem' => $credential['public_key_pem'],
			'alg'            => isset( $credential['alg'] ) ? (int) $credential['alg'] : -7,
			'label'          => ! empty( $credential['label'] ) ? sanitize_text_field( $credential['label'] ) : self::detect_device_label(),
			'created_at'     => current_time( 'mysql' ),
			'last_used'      => current_time( 'mysql' ),
		);

		update_user_meta( $user_id, self::META_CREDENTIALS, wp_slash( $passkeys ) ); // Meta API unslashes.

		// Ensure index meta exists for O(1) lookup by credential ID
		$indexed = get_user_meta( $user_id, self::META_CRED_INDEX, false );
		if ( ! is_array( $indexed ) || ! in_array( $cred_id, $indexed, true ) ) {
			add_user_meta( $user_id, self::META_CRED_INDEX, $cred_id, false );
		}

		return true;
	}

	/**
	 * Delete a specific Passkey for a user
	 *
	 * @param int    $user_id WordPress User ID.
	 * @param string $cred_id Base64URL Credential ID.
	 * @return bool
	 */
	public static function delete_user_passkey( $user_id, $cred_id ) {
		$passkeys = self::get_user_passkeys( $user_id );
		if ( ! isset( $passkeys[ $cred_id ] ) ) {
			return false;
		}

		unset( $passkeys[ $cred_id ] );
		update_user_meta( $user_id, self::META_CREDENTIALS, wp_slash( $passkeys ) ); // Meta API unslashes.
		delete_user_meta( $user_id, self::META_CRED_INDEX, $cred_id );
		return true;
	}

	/**
	 * Find WordPress User by Credential ID
	 *
	 * @param string $cred_id Base64URL Credential ID.
	 * @return WP_User|null
	 */
	public static function find_user_by_credential_id( $cred_id ) {
		$cred_id = sanitize_text_field( $cred_id );
		if ( empty( $cred_id ) ) {
			return null;
		}

		$users = get_users(
			array(
				'meta_key'   => self::META_CRED_INDEX, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- one indexed lookup per passkey sign-in.
				'meta_value' => $cred_id, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
				'number'     => 1,
			)
		);

		if ( ! empty( $users[0] ) && $users[0] instanceof WP_User ) {
			return $users[0];
		}

		return null;
	}

	/**
	 * Detect friendly Persian device label from User-Agent
	 *
	 * @return string
	 */
	public static function detect_device_label() {
		$ua = isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) : '';
		if ( stripos( $ua, 'iPhone' ) !== false || stripos( $ua, 'iPad' ) !== false ) {
			return 'آیفون / آیپد (FaceID / TouchID)';
		}
		if ( stripos( $ua, 'Macintosh' ) !== false || stripos( $ua, 'Mac OS' ) !== false ) {
			return 'مک‌بوک اپل (TouchID)';
		}
		if ( stripos( $ua, 'Android' ) !== false ) {
			return 'گوشی اندروید (اثر انگشت / چهره)';
		}
		if ( stripos( $ua, 'Windows' ) !== false ) {
			return 'ویندوز (Windows Hello)';
		}
		return 'دستگاه بیومتریک من';
	}

	/**
	 * AJAX: Generate WebAuthn Registration Options for logged-in user
	 */
	public function ajax_register_options() {
		if ( true !== Ashna_Session::verify_request() ) {
			return;
		}

		if ( ! is_user_logged_in() ) {
			wp_send_json_error( array( 'message' => 'برای ثبت کلید بیومتریک ابتدا وارد حساب کاربری خود شوید.' ) );
			return; // wp_send_json() ends the request: never continue past a response.
		}

		$user      = wp_get_current_user();
		$challenge = self::base64url_encode( random_bytes( 32 ) );

		set_transient( 'ashna_pk_reg_' . $user->ID, $challenge, 120 );

		$existing = self::get_user_passkeys( $user->ID );
		$exclude  = array();
		foreach ( $existing as $cred_id => $item ) {
			$exclude[] = array(
				'id'   => $cred_id,
				'type' => 'public-key',
			);
		}

		$phone        = get_user_meta( $user->ID, 'ashna_phone', true );
		$display_name = ! empty( $user->display_name ) ? $user->display_name : ( $phone ? $phone : $user->user_login );

		wp_send_json_success(
			array(
				'rp'               => array(
					'name' => get_bloginfo( 'name' ),
					'id'   => self::get_rp_id(),
				),
				'user'             => array(
					'id'          => self::base64url_encode( 'ashna_u_' . $user->ID ),
					'name'        => $phone ? $phone : $user->user_login,
					'displayName' => $display_name,
				),
				'challenge'        => $challenge,
				'pubKeyCredParams' => array(
					array(
						'type' => 'public-key',
						'alg'  => -7, // ES256 (ECDSA P-256 with SHA-256)
					),
					array(
						'type' => 'public-key',
						'alg'  => -257, // RS256 (RSASSA-PKCS1-v1_5 with SHA-256)
					),
				),
				'timeout'          => 60000,
				'excludeCredentials' => $exclude,
				'authenticatorSelection' => array(
					'residentKey'      => 'preferred',
					'userVerification' => 'preferred',
				),
				'attestation'      => 'none',
			)
		);
	}

	/**
	 * AJAX: Verify WebAuthn Registration & Save User's Public Key
	 */
	public function ajax_register_verify() {
		if ( true !== Ashna_Session::verify_request() ) {
			return;
		}

		if ( ! is_user_logged_in() ) {
			wp_send_json_error( array( 'message' => 'نشست کاربری شما منقضی شده است.' ) );
			return; // wp_send_json() ends the request: never continue past a response.
		}

		$user              = wp_get_current_user();
		$expected_challenge = get_transient( 'ashna_pk_reg_' . $user->ID );
		delete_transient( 'ashna_pk_reg_' . $user->ID );

		if ( empty( $expected_challenge ) ) {
			wp_send_json_error( array( 'message' => 'فرصت ثبت کلید بیومتریک به پایان رسید. لطفاً دوباره تلاش کنید.' ) );
			return; // wp_send_json() ends the request: never continue past a response.
		}

		$cred_id         = isset( $_POST['credential_id'] ) ? sanitize_text_field( wp_unslash( $_POST['credential_id'] ) ) : '';
		$client_data_b64 = isset( $_POST['client_data_json'] ) ? sanitize_text_field( wp_unslash( $_POST['client_data_json'] ) ) : '';
		$auth_data_b64   = isset( $_POST['authenticator_data'] ) ? sanitize_text_field( wp_unslash( $_POST['authenticator_data'] ) ) : '';
		$spki_b64        = isset( $_POST['public_key_spki'] ) ? sanitize_text_field( wp_unslash( $_POST['public_key_spki'] ) ) : '';
		$alg             = isset( $_POST['public_key_alg'] ) ? (int) $_POST['public_key_alg'] : -7;

		if ( empty( $cred_id ) || empty( $client_data_b64 ) || empty( $spki_b64 ) ) {
			wp_send_json_error( array( 'message' => 'اطلاعات کلید بیومتریک از مرورگر دریافت نشد.' ) );
			return; // wp_send_json() ends the request: never continue past a response.
		}

		$client_data_raw = self::base64url_decode( $client_data_b64 );
		$client_data     = json_decode( $client_data_raw, true );

		if ( ! is_array( $client_data ) || empty( $client_data['type'] ) || 'webauthn.create' !== $client_data['type'] ) {
			wp_send_json_error( array( 'message' => 'پاسخ WebAuthn نامعتبر است.' ) );
			return; // wp_send_json() ends the request: never continue past a response.
		}

		if ( empty( $client_data['challenge'] ) || ! hash_equals( (string) $expected_challenge, (string) $client_data['challenge'] ) ) {
			wp_send_json_error( array( 'message' => 'چالش امنیتی ثبت Passkey تطابق ندارد.' ) );
			return; // wp_send_json() ends the request: never continue past a response.
		}

		$origin_host = isset( $client_data['origin'] ) ? strtolower( (string) wp_parse_url( $client_data['origin'], PHP_URL_HOST ) ) : '';
		$rp_id       = self::get_rp_id();
		if ( $origin_host !== $rp_id ) {
			wp_send_json_error( array( 'message' => 'دامنه مبدا درخواست با دامنه سایت همخوانی ندارد.' ) );
			return; // wp_send_json() ends the request: never continue past a response.
		}

		if ( ! empty( $auth_data_b64 ) ) {
			$auth_data_bin = self::base64url_decode( $auth_data_b64 );
			if ( strlen( $auth_data_bin ) < 37 ) {
				wp_send_json_error( array( 'message' => 'ساختار داده احراز هویت معتبر نیست.' ) );
				return; // wp_send_json() ends the request: never continue past a response.
			}
			$rp_id_hash = substr( $auth_data_bin, 0, 32 );
			if ( ! hash_equals( hash( 'sha256', $rp_id, true ), $rp_id_hash ) ) {
				wp_send_json_error( array( 'message' => 'شناسه دامنه کلید امنیتی معتبر نیست.' ) );
				return; // wp_send_json() ends the request: never continue past a response.
			}
		}

		// Convert SPKI DER to standard PEM Public Key & validate with OpenSSL
		$spki_der = self::base64url_decode( $spki_b64 );
		$pem_key  = "-----BEGIN PUBLIC KEY-----\n" . chunk_split( base64_encode( $spki_der ), 64, "\n" ) . "-----END PUBLIC KEY-----\n"; // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- WebAuthn base64url / PEM encoding.

		if ( function_exists( 'openssl_pkey_get_public' ) ) {
			$pkey_res = @openssl_pkey_get_public( $pem_key ); // phpcs:ignore Generic.PHP.NoSilencedErrors.Discouraged -- an invalid key returns false and is handled.
			if ( false === $pkey_res ) {
				wp_send_json_error( array( 'message' => 'کلید عمومی تولیدشده توسط دستگاه قابل تایید نیست.' ) );
				return; // wp_send_json() ends the request: never continue past a response.
			}
		}

		self::save_user_passkey(
			$user->ID,
			array(
				'id'             => $cred_id,
				'public_key_pem' => $pem_key,
				'alg'            => $alg,
				'label'          => self::detect_device_label(),
			)
		);

		wp_send_json_success(
			array(
				'message' => 'ورود بیومتریک (اثر انگشت / چهره) برای این دستگاه با موفقیت فعال شد!',
				'label'   => self::detect_device_label(),
				'cred_id' => $cred_id,
			)
		);
	}

	/**
	 * AJAX: Delete a Passkey for the current user
	 */
	public function ajax_delete_passkey() {
		if ( true !== Ashna_Session::verify_request() ) {
			return;
		}

		if ( ! is_user_logged_in() ) {
			wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز.' ) );
			return; // wp_send_json() ends the request: never continue past a response.
		}

		$cred_id = isset( $_POST['credential_id'] ) ? sanitize_text_field( wp_unslash( $_POST['credential_id'] ) ) : '';
		if ( empty( $cred_id ) || ! self::delete_user_passkey( get_current_user_id(), $cred_id ) ) {
			wp_send_json_error( array( 'message' => 'کلید مورد نظر یافت نشد.' ) );
			return; // wp_send_json() ends the request: never continue past a response.
		}

		wp_send_json_success( array( 'message' => 'دستگاه بیومتریک حذف شد.' ) );
	}

	/**
	 * AJAX: Generate WebAuthn Login Challenge (Assertion Options)
	 */
	public function ajax_login_options() {
		if ( true !== Ashna_Session::verify_request() ) {
			return;
		}

		if ( ! Ashna_Helper::get_option( 'enable_passkey', 1 ) ) {
			wp_send_json_error( array( 'message' => 'ورود بیومتریک در حال حاضر غیرفعال است.' ) );
			return; // wp_send_json() ends the request: never continue past a response.
		}

		$challenge = self::base64url_encode( random_bytes( 32 ) );
		$token_key = 'ashna_pk_auth_' . md5( $challenge ); // 256-bit random challenge; not tied to an IP that may change mid-flow.

		set_transient( $token_key, $challenge, 120 );

		// Optional: if user typed their phone/email in the form, scope allowCredentials
		$allow_credentials = array();
		$raw_identifier    = isset( $_POST['identifier'] ) ? sanitize_text_field( wp_unslash( $_POST['identifier'] ) ) : '';
		if ( ! empty( $raw_identifier ) ) {
			$parsed = Ashna_Helper::parse_identifier( $raw_identifier );
			if ( 'invalid' !== $parsed['type'] ) {
				$user = Ashna_Auth::find_user( $parsed['normalized'], $parsed['type'] );
				if ( $user ) {
					$passkeys = self::get_user_passkeys( $user->ID );
					foreach ( $passkeys as $cid => $pk ) {
						$allow_credentials[] = array(
							'id'   => $cid,
							'type' => 'public-key',
						);
					}
				}
			}
		}

		wp_send_json_success(
			array(
				'challenge'        => $challenge,
				'rpId'             => self::get_rp_id(),
				'timeout'          => 60000,
				'userVerification' => 'preferred',
				'allowCredentials' => $allow_credentials,
			)
		);
	}

	/**
	 * AJAX: Verify WebAuthn Cryptographic Assertion & Log User In
	 */
	public function ajax_login_verify() {
		if ( true !== Ashna_Session::verify_request() ) {
			return;
		}

		if ( ! Ashna_Helper::get_option( 'enable_passkey', 1 ) ) {
			wp_send_json_error( array( 'message' => 'ورود بیومتریک غیرفعال است.' ) );
			return; // wp_send_json() ends the request: never continue past a response.
		}

		$cred_id         = isset( $_POST['credential_id'] ) ? sanitize_text_field( wp_unslash( $_POST['credential_id'] ) ) : '';
		$client_data_b64 = isset( $_POST['client_data_json'] ) ? sanitize_text_field( wp_unslash( $_POST['client_data_json'] ) ) : '';
		$auth_data_b64   = isset( $_POST['authenticator_data'] ) ? sanitize_text_field( wp_unslash( $_POST['authenticator_data'] ) ) : '';
		$signature_b64   = isset( $_POST['signature'] ) ? sanitize_text_field( wp_unslash( $_POST['signature'] ) ) : '';
		$redirect_to     = isset( $_POST['redirect_to'] ) ? esc_url_raw( Ashna_Helper::as_string( wp_unslash( $_POST['redirect_to'] ) ) ) : '';

		if ( empty( $cred_id ) || empty( $client_data_b64 ) || empty( $auth_data_b64 ) || empty( $signature_b64 ) ) {
			wp_send_json_error( array( 'message' => 'اطلاعات تایید بیومتریک ناقص است.' ) );
			return; // wp_send_json() ends the request: never continue past a response.
		}

		$client_data_raw = self::base64url_decode( $client_data_b64 );
		$client_data     = json_decode( $client_data_raw, true );

		if ( ! is_array( $client_data ) || empty( $client_data['type'] ) || 'webauthn.get' !== $client_data['type'] ) {
			wp_send_json_error( array( 'message' => 'نوع پاسخ WebAuthn معتبر نیست.' ) );
			return; // wp_send_json() ends the request: never continue past a response.
		}

		$challenge = isset( $client_data['challenge'] ) ? sanitize_text_field( $client_data['challenge'] ) : '';
		$token_key = 'ashna_pk_auth_' . md5( $challenge );
		$saved_ch  = get_transient( $token_key );
		delete_transient( $token_key );

		if ( empty( $saved_ch ) || ! hash_equals( (string) $saved_ch, (string) $challenge ) ) {
			wp_send_json_error( array( 'message' => 'چالش امنیتی منقضی شده است. لطفاً دوباره دکمه ورود بیومتریک را بزنید.' ) );
			return; // wp_send_json() ends the request: never continue past a response.
		}

		$origin_host = isset( $client_data['origin'] ) ? strtolower( (string) wp_parse_url( $client_data['origin'], PHP_URL_HOST ) ) : '';
		$rp_id       = self::get_rp_id();
		if ( $origin_host !== $rp_id ) {
			wp_send_json_error( array( 'message' => 'دامنه درخواست نامعتبر است.' ) );
			return; // wp_send_json() ends the request: never continue past a response.
		}

		$auth_data_bin = self::base64url_decode( $auth_data_b64 );
		if ( strlen( $auth_data_bin ) < 37 ) {
			wp_send_json_error( array( 'message' => 'داده احراز هویت نامعتبر است.' ) );
			return; // wp_send_json() ends the request: never continue past a response.
		}

		$rp_id_hash = substr( $auth_data_bin, 0, 32 );
		if ( ! hash_equals( hash( 'sha256', $rp_id, true ), $rp_id_hash ) ) {
			wp_send_json_error( array( 'message' => 'شناسه دامنه کلید امنیتی مطابقت ندارد.' ) );
			return; // wp_send_json() ends the request: never continue past a response.
		}

		// Check User Present (UP) flag (bit 0)
		$flags = ord( $auth_data_bin[32] );
		if ( 0 === ( $flags & 0x01 ) ) {
			wp_send_json_error( array( 'message' => 'حضور کاربر توسط سنسور بیومتریک تایید نشد.' ) );
			return; // wp_send_json() ends the request: never continue past a response.
		}

		// Locate user owning this Credential ID
		$user = self::find_user_by_credential_id( $cred_id );
		if ( ! $user ) {
			wp_send_json_error( array( 'message' => 'هیچ حساب کاربری با این کلید بیومتریک در سایت یافت نشد. لطفاً یک‌بار با کد تایید وارد شوید و Passkey را ثبت کنید.' ) );
			return; // wp_send_json() ends the request: never continue past a response.
		}

		$passkeys = self::get_user_passkeys( $user->ID );
		if ( empty( $passkeys[ $cred_id ]['public_key_pem'] ) ) {
			wp_send_json_error( array( 'message' => 'کلید عمومی این دستگاه در حساب شما یافت نشد.' ) );
			return; // wp_send_json() ends the request: never continue past a response.
		}

		$pem_key       = $passkeys[ $cred_id ]['public_key_pem'];
		$signature_bin = self::base64url_decode( $signature_b64 );
		$signed_data   = $auth_data_bin . hash( 'sha256', $client_data_raw, true );

		// Fail closed: without OpenSSL the signature cannot be checked, so nobody is signed in.
		if ( ! function_exists( 'openssl_verify' ) ) {
			wp_send_json_error( array( 'message' => 'ورود بیومتریک روی این سرور در دسترس نیست (افزونه OpenSSL در PHP فعال نیست).' ) );
			return; // wp_send_json() ends the request: never continue past a response.
		}
		$verified = @openssl_verify( $signed_data, $signature_bin, $pem_key, OPENSSL_ALGO_SHA256 ); // phpcs:ignore Generic.PHP.NoSilencedErrors.Discouraged -- a malformed signature returns -1/false and is refused below.
		if ( 1 !== $verified ) {
			wp_send_json_error( array( 'message' => 'امضای دیجیتال بیومتریک تایید نشد.' ) );
			return; // wp_send_json() ends the request: never continue past a response.
		}

		// Update last_used timestamp
		$passkeys[ $cred_id ]['last_used'] = current_time( 'mysql' );
		update_user_meta( $user->ID, self::META_CREDENTIALS, wp_slash( $passkeys ) ); // Meta API unslashes.

		$phone      = get_user_meta( $user->ID, 'ashna_phone', true );
		$identifier = $phone ? $phone : $user->user_email;

		// Sign in through the shared WordPress-native session (same gates, cookies and hooks as OTP).
		$logged_in = Ashna_Session::login(
			$user,
			array(
				'method'     => 'passkey',
				'identifier' => $identifier,
			)
		);
		if ( is_wp_error( $logged_in ) ) {
			wp_send_json_error(
				array(
					'message' => $logged_in->get_error_message(),
					'code'    => $logged_in->get_error_code(),
				)
			);
			return; // wp_send_json() ends the request: never continue past a response.
		}

		// Log successful Passkey login in Ashna Logs
		Ashna_Logger::insert(
			array(
				'recipient'        => $identifier ? $identifier : $user->user_login,
				'channel'          => 'passkey',
				'gateway'          => 'webauthn',
				'otp_code'         => 'PASSKEY',
				'status'           => 'verified',
				'response_message' => 'ورود بیومتریک موفق (' . ( isset( $passkeys[ $cred_id ]['label'] ) ? $passkeys[ $cred_id ]['label'] : 'Passkey' ) . ')',
			)
		);

		wp_send_json_success(
			Ashna_Auth::login_response(
				$user,
				$redirect_to,
				sprintf( 'خوش آمدید %s! ورود بیومتریک انجام شد...', $user->display_name ),
				array(),
				array( 'form' => isset( $_POST['context'] ) ? sanitize_key( Ashna_Helper::as_string( wp_unslash( $_POST['context'] ) ) ) : '' ) // phpcs:ignore WordPress.Security.NonceVerification.Missing -- verified at the top.
			)
		);
	}

	/**
	 * Output Passkey Manager Box in WooCommerce My Account Dashboard
	 */
	public function echo_passkey_manager_box() {
		// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		echo $this->render_passkey_manager_shortcode();
	}

	/**
	 * Shortcode `[ashna_passkey_manager]` to manage user's registered Passkeys
	 *
	 * @return string
	 */
	public function render_passkey_manager_shortcode() {
		if ( ! is_user_logged_in() || ! Ashna_Helper::get_option( 'enable_passkey', 1 ) ) {
			return '';
		}

		if ( class_exists( 'Ashna_Frontend' ) ) {
			Ashna_Frontend::instance()->enqueue_assets( true );
		}

		$user_id  = get_current_user_id();
		$passkeys = self::get_user_passkeys( $user_id );

		ob_start();
		?>
		<div class="ashna-passkey-account-card" dir="rtl">
			<div class="ashna-pk-card-head">
				<div class="ashna-pk-card-title">
					<span class="ashna-pk-badge-icon">
						<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M2 12C2 6.5 6.5 2 12 2a10 10 0 0 1 8 4"/><path d="M5 19.5C5.5 18 6 15 6 12c0-.7.12-1.37.34-2"/><path d="M17.29 21.02c.12-.6.43-2.3.5-3.02"/><path d="M12 10a2 2 0 0 0-2 2c0 1.02-.1 2.51-.26 4"/><path d="M8.65 22c.21-.66.45-1.32.57-2"/><path d="M14 13.12c0 2.38 0 6.38-1 8.88"/><path d="M2 16h.01"/><path d="M21.8 16c.2-2 .131-5.354 0-6"/><path d="M9 6.8a6 6 0 0 1 9 5.2c0 .47 0 1.17-.02 2"/></svg>
					</span>
					<div>
						<h4>ورود بیومتریک و بدون رمز (Passkey)</h4>
						<p>با ثبت اثر انگشت یا تشخیص چهره، دفعات بعد در ۱ ثانیه و بدون نیاز به پیامک وارد شوید.</p>
					</div>
				</div>
				<button type="button" class="ashna-btn-register-passkey">
					<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.3"><line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/></svg>
					<span>افزودن این دستگاه</span>
				</button>
			</div>

			<div class="ashna-pk-msg" style="display:none;"></div>

			<?php if ( ! empty( $passkeys ) ) : ?>
				<div class="ashna-pk-list">
					<?php foreach ( $passkeys as $cid => $pk ) : ?>
						<div class="ashna-pk-item" data-cred-id="<?php echo esc_attr( $cid ); ?>">
							<div class="ashna-pk-item-info">
								<strong><?php echo esc_html( $pk['label'] ); ?></strong>
								<small>ثبت‌شده در: <span dir="ltr"><?php echo esc_html( $pk['created_at'] ); ?></span></small>
							</div>
							<button type="button" class="ashna-pk-delete-btn" data-cred-id="<?php echo esc_attr( $cid ); ?>">حذف</button>
						</div>
					<?php endforeach; ?>
				</div>
			<?php else : ?>
				<p class="ashna-pk-empty">هنوز هیچ دستگاه بیومتریکی برای حساب شما ثبت نشده است.</p>
			<?php endif; ?>
		</div>
		<?php
		return ob_get_clean();
	}
}
// phpcs:enable WordPress.Security.NonceVerification.Missing


// ---- Source: includes/core/class-ashna-rate-limiter.php ----
/**
 * SMS-bombing protection: per-minute/hour/day limits per mobile number, IP and network,
 * a site-wide daily credit guard and an automatic "attack mode".
 *
 * Race-free by construction: a request first reserves its slot (a "pending" log row) and
 * only then re-counts everything up to and including its own row. Of N parallel requests
 * that all passed the quick pre-check, only those inside the limit keep their slot — the
 * rest are refused before any gateway is contacted. (Previously the log row was written
 * after sending, so a burst of parallel requests could all pass the limits.)
 *
 * @package Ashna
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Ashna_Rate_Limiter {

	const ATTACK_OPTION = 'ashna_otp_attack_mode';
	const STATS_OPTION  = 'ashna_otp_block_stats';

	/**
	 * Effective limits from the settings (0 = off where allowed).
	 *
	 * @return array
	 */
	public static function limits() {
		return array(
			'cooldown'       => absint( Ashna_Helper::get_option( 'resend_cooldown', 60 ) ),
			// 0 switches a window off (unlimited); any other value keeps the historical floor,
			// so an accidental "1" cannot open a window wider than the old minimum.
			'number_hour'    => self::window_limit( 'max_requests_per_hour', 5, 1 ),
			'number_day'     => self::window_limit( 'max_requests_per_day', 10, 1 ),
			'ip_minute'      => self::window_limit( 'max_ip_requests_per_minute', 5, 1 ),
			'ip_hour'        => self::window_limit( 'max_ip_requests_per_hour', 15, 2 ),
			'subnet_minute'  => absint( Ashna_Helper::get_option( 'max_subnet_requests_per_minute', 20 ) ),
			'daily_cap'      => absint( Ashna_Helper::get_option( 'daily_send_cap', 0 ) ),
			'attack_trigger' => absint( Ashna_Helper::get_option( 'attack_mode_threshold', 20 ) ),
			'attack_minutes' => max( 5, absint( Ashna_Helper::get_option( 'attack_mode_minutes', 30 ) ) ),
		);
	}

	/**
	 * One rate-limit window: 0 = off (unlimited), otherwise never below $floor.
	 *
	 * @param string $option Setting key.
	 * @param int    $default Default when the setting is missing.
	 * @param int    $floor   Smallest value that still enforces a limit.
	 * @return int 0 when the window is switched off.
	 */
	private static function window_limit( $option, $default, $floor ) {
		$value = absint( Ashna_Helper::get_option( $option, $default ) );
		return $value > 0 ? max( $floor, $value ) : 0;
	}

	/**
	 * Reserve a send slot for a recipient, or explain why not.
	 *
	 * Three steps, each safe to interleave with the same steps of parallel requests:
	 * precheck() (read-only) → Ashna_Logger::reserve() (one INSERT) → recount() (counts rows
	 * up to and including our own; refused rows are removed). See tests/security.php, which
	 * replays every interleaving of parallel requests through these steps.
	 *
	 * @param string $recipient Normalized phone or email.
	 * @param string $ip        Visitor IP (defaults to the resolved client IP).
	 * @return int|WP_Error Reservation ID.
	 */
	public static function reserve( $recipient, $ip = '' ) {
		$ip = '' !== $ip ? $ip : Ashna_Helper::get_client_ip();

		$check = self::precheck( $recipient, $ip );
		if ( is_wp_error( $check ) ) {
			return $check;
		}

		$id = Ashna_Logger::reserve( $recipient, $ip, Ashna_IP::subnet( $ip ) );
		if ( ! $id ) {
			return new WP_Error( 'ashna_reserve_failed', 'خطای موقت در ثبت درخواست. لطفاً چند لحظه بعد دوباره تلاش کنید.' );
		}

		$check = self::recount( $recipient, $ip, $id );
		return is_wp_error( $check ) ? $check : $id;
	}

	/**
	 * Step 1 — blacklist, lockout and a quick read-only look at every limit. Most abusive
	 * requests stop here without writing anything.
	 *
	 * @param string $recipient Recipient.
	 * @param string $ip        IP.
	 * @return true|WP_Error
	 */
	public static function precheck( $recipient, $ip ) {
		$blacklist = Ashna_Security::check_blacklist( $recipient, $ip );
		if ( is_wp_error( $blacklist ) ) {
			return self::refuse( $blacklist, $recipient, $ip );
		}
		if ( Ashna_Security::is_whitelisted( $recipient, $ip ) ) {
			return true;
		}
		$lockout = Ashna_Security::check_lockout( $recipient, $ip );
		if ( is_wp_error( $lockout ) ) {
			return self::refuse( $lockout, $recipient, $ip );
		}
		$check = self::evaluate( $recipient, $ip, Ashna_IP::subnet( $ip ), 0 );
		return is_wp_error( $check ) ? self::refuse( $check, $recipient, $ip ) : true;
	}

	/**
	 * Step 3 — with our reservation stored, count everything up to and including it. Of any
	 * number of parallel requests, only those inside the limits keep their slot.
	 *
	 * @param string $recipient Recipient.
	 * @param string $ip        IP.
	 * @param int    $id        Reservation ID.
	 * @return true|WP_Error
	 */
	public static function recount( $recipient, $ip, $id ) {
		if ( Ashna_Security::is_whitelisted( $recipient, $ip ) ) {
			return true;
		}
		$check = self::evaluate( $recipient, $ip, Ashna_IP::subnet( $ip ), $id );
		if ( is_wp_error( $check ) ) {
			Ashna_Logger::delete( $id );
			return self::refuse( $check, $recipient, $ip );
		}
		self::maybe_enter_attack_mode();
		return true;
	}

	/**
	 * Check every window. With $upto_id = 0 the request is not stored yet (it would add one);
	 * otherwise rows up to and including the reservation are counted.
	 *
	 * @param string $recipient Recipient.
	 * @param string $ip        IP.
	 * @param string $subnet    Network.
	 * @param int    $upto_id   Reservation ID or 0.
	 * @return true|WP_Error
	 */
	public static function evaluate( $recipient, $ip, $subnet, $upto_id = 0 ) {
		global $wpdb;
		$table  = Ashna_Logger::table_name();
		$limits = self::limits();
		$now    = Ashna_Helper::local_now();
		$extra  = $upto_id ? 0 : 1;
		$upto   = $upto_id ? $wpdb->prepare( ' AND id <= %d', $upto_id ) : '';
		$before = $upto_id ? $wpdb->prepare( ' AND id < %d', $upto_id ) : '';
		$at     = static function ( $seconds ) use ( $now ) {
			return gmdate( 'Y-m-d H:i:s', $now - $seconds );
		};
		// Upper bound for the short windows: rows "from the future" were written before the clock went
		// back (DST ends, or the site timezone was changed) and must not count as this minute.
		$soon = $at( -5 );

		// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQL.NotPrepared

		// Mobile number / e-mail: resend cooldown, per hour, per day (failed sends do not count).
		// IP: per minute and per hour. Both windows travel in one UNION ALL round trip — the
		// numbers are the same ones the two separate queries produced before.
		$counts = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT 'number' AS scope,
				        COUNT(*) AS day_count,
				        SUM(CASE WHEN created_at >= %s THEN 1 ELSE 0 END) AS hour_count,
				        MAX(CASE WHEN created_at >= %s AND created_at <= %s{$before} THEN created_at ELSE NULL END) AS last_recent,
				        0 AS minute_count
				 FROM {$table}
				 WHERE recipient = %s AND status <> 'failed' AND channel <> 'passkey' AND created_at >= %s{$upto}
				 UNION ALL
				 SELECT 'ip' AS scope,
				        NULL AS day_count,
				        COUNT(*) AS hour_count,
				        NULL AS last_recent,
				        SUM(CASE WHEN created_at >= %s AND created_at <= %s THEN 1 ELSE 0 END) AS minute_count
				 FROM {$table}
				 WHERE ip_address = %s AND channel <> 'passkey' AND created_at >= %s{$upto}",
				$at( HOUR_IN_SECONDS ),
				$at( max( 1, $limits['cooldown'] ) ),
				$soon,
				$recipient,
				$at( DAY_IN_SECONDS ),
				$at( MINUTE_IN_SECONDS ),
				$soon,
				$ip,
				$at( HOUR_IN_SECONDS )
			)
		);

		$number = null;
		$by_ip  = null;
		foreach ( (array) $counts as $row ) {
			if ( 'ip' === $row->scope ) {
				$by_ip = $row;
			} else {
				$number = $row;
			}
		}

		if ( $limits['cooldown'] > 0 && $number && ! empty( $number->last_recent ) ) {
			$remaining = min( $limits['cooldown'], max( 1, $limits['cooldown'] - ( $now - Ashna_Helper::local_ts( $number->last_recent ) ) ) );
			return new WP_Error(
				'ashna_cooldown',
				sprintf( 'لطفاً %d ثانیه دیگر برای درخواست مجدد کد صبر کنید.', $remaining ),
				array( 'remaining' => $remaining )
			);
		}
		if ( $limits['number_hour'] > 0 && $number && (int) $number->hour_count + $extra > $limits['number_hour'] ) {
			return new WP_Error( 'ashna_rate_limit_recipient', 'تعداد درخواست‌های کد برای این شماره/ایمیل در یک ساعت گذشته بیش از حد مجاز است. لطفاً کمی بعد تلاش کنید.' );
		}
		if ( $limits['number_day'] > 0 && $number && (int) $number->day_count + $extra > $limits['number_day'] ) {
			return new WP_Error( 'ashna_rate_limit_recipient_day', 'سقف دریافت کد برای این شماره/ایمیل در ۲۴ ساعت گذشته پر شده است. لطفاً فردا دوباره تلاش کنید.' );
		}
		if ( $limits['ip_minute'] > 0 && $by_ip && (int) $by_ip->minute_count + $extra > $limits['ip_minute'] ) {
			return new WP_Error( 'ashna_rate_limit_ip_minute', 'درخواست‌های ارسالی از آی‌پی شما در یک دقیقه گذشته بیش از حد مجاز است. لطفاً یک دقیقه دیگر تلاش کنید.', array( 'remaining' => 60 ) );
		}
		if ( $limits['ip_hour'] > 0 && $by_ip && (int) $by_ip->hour_count + $extra > $limits['ip_hour'] ) {
			return new WP_Error( 'ashna_rate_limit_ip', 'تعداد درخواست‌های ارسالی از آی‌پی شما بیش از حد مجاز است. لطفاً یک ساعت دیگر تلاش کنید.' );
		}

		// Network (/24 or /64): stops attackers rotating addresses inside one range.
		if ( $limits['subnet_minute'] > 0 && '' !== $subnet ) {
			$net_count = (int) $wpdb->get_var(
				$wpdb->prepare(
					"SELECT COUNT(*) FROM {$table} WHERE ip_subnet = %s AND channel <> 'passkey' AND created_at >= %s AND created_at <= %s{$upto}",
					$subnet,
					$at( MINUTE_IN_SECONDS ),
					$soon
				)
			);
			if ( $net_count + $extra > $limits['subnet_minute'] ) {
				return new WP_Error( 'ashna_rate_limit_subnet', 'درخواست‌های زیادی از شبکه‌ی شما ارسال شده است. لطفاً چند دقیقه دیگر تلاش کنید.', array( 'remaining' => 60 ) );
			}
		}

		// Site-wide credit guard.
		if ( $limits['daily_cap'] > 0 ) {
			$today = gmdate( 'Y-m-d 00:00:00', $now );
			$sent  = (int) $wpdb->get_var(
				$wpdb->prepare(
					"SELECT COUNT(*) FROM {$table} WHERE status <> 'failed' AND channel <> 'passkey' AND created_at >= %s{$upto}",
					$today
				)
			);
			if ( $sent + $extra > $limits['daily_cap'] ) {
				self::notify_admin_once( 'daily_cap', 'سقف ارسال روزانه آشنا پر شد', sprintf( "سقف ارسال روزانه‌ی کد در سایت %s (%d کد) پر شد و ارسال کد تا پایان امروز متوقف است.\nاگر این حجم طبیعی است، سقف را در «امنیت و ضد اسپم» افزایش دهید؛ در غیر این صورت احتمالاً سایت هدف حمله پیامکی است.", home_url(), $limits['daily_cap'] ) );
				return new WP_Error( 'ashna_daily_cap', 'ارسال کد تایید موقتاً در دسترس نیست. لطفاً بعداً تلاش کنید یا با پشتیبانی سایت تماس بگیرید.' );
			}
		}

		// phpcs:enable

		return true;
	}

	/**
	 * Switch on attack mode when the whole site receives an unusual burst.
	 */
	public static function maybe_enter_attack_mode() {
		$limits = self::limits();
		if ( $limits['attack_trigger'] <= 0 || self::attack_mode_active() ) {
			return;
		}
		global $wpdb;
		$table = Ashna_Logger::table_name();
		$now   = Ashna_Helper::local_now();
		$since = gmdate( 'Y-m-d H:i:s', $now - MINUTE_IN_SECONDS );
		$soon  = gmdate( 'Y-m-d H:i:s', $now + 5 ); // Rows from before a clock change are not "this minute".
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		$count = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE channel <> 'passkey' AND created_at >= %s AND created_at <= %s", $since, $soon ) );
		if ( $count < $limits['attack_trigger'] ) {
			return;
		}

		$until = time() + $limits['attack_minutes'] * MINUTE_IN_SECONDS;
		// Autoload stays on: with `false` the option would be downgraded to a non-autoloaded row
		// (WordPress 6.6+) and every request during the attack would pay one extra options query
		// just to read this state — the opposite of what the state exists for. Value is unchanged.
		update_option(
			self::ATTACK_OPTION,
			array(
				'since' => time(),
				'until' => $until,
				'peak'  => $count,
			),
			true
		);
		self::notify_admin_once(
			'attack',
			'حالت حمله در آشنا فعال شد',
			sprintf( "در یک دقیقه %d درخواست کد به سایت %s رسید. برای %d دقیقه پاسخ‌دادن به کپچا برای همه‌ی درخواست‌ها اجباری شد.\nجزئیات در «امنیت و ضد اسپم» و لاگ کدها.", $count, home_url(), $limits['attack_minutes'] )
		);
		do_action( 'ashna_otp_attack_mode_started', $count, $until );
	}

	/**
	 * Whether attack mode is on.
	 *
	 * @return bool
	 */
	public static function attack_mode_active() {
		$state = get_option( self::ATTACK_OPTION, array() );
		return is_array( $state ) && ! empty( $state['until'] ) && (int) $state['until'] > time();
	}

	/**
	 * Attack mode state for the admin screen.
	 *
	 * @return array|null
	 */
	public static function attack_mode_state() {
		return self::attack_mode_active() ? get_option( self::ATTACK_OPTION ) : null;
	}

	/**
	 * End attack mode now.
	 *
	 * The option keeps its "not active" value instead of being deleted: it is read on every
	 * request, and an existing autoloaded option costs no query while a missing one does.
	 */
	public static function end_attack_mode() {
		update_option(
			self::ATTACK_OPTION,
			array(
				'since' => 0,
				'until' => 0,
				'peak'  => 0,
			),
			true
		);
	}

	/**
	 * Whether a captcha must be solved for a new code request.
	 *
	 * @return bool
	 */
	public static function captcha_required() {
		$type = Ashna_Helper::get_option( 'captcha_type', 'none' );
		return ( 'none' !== $type && '' !== $type ) || self::attack_mode_active();
	}

	/**
	 * Record a refusal and pass the error through.
	 *
	 * @param WP_Error $error     Error.
	 * @param string   $recipient Recipient.
	 * @param string   $ip        IP.
	 * @return WP_Error
	 */
	public static function refuse( WP_Error $error, $recipient = '', $ip = '' ) {
		self::record_block( $error->get_error_code(), $recipient, $ip );
		return $error;
	}

	/**
	 * Count refused requests per day and keep the last few for the admin screen.
	 *
	 * @param string $reason    Error code.
	 * @param string $recipient Recipient.
	 * @param string $ip        IP.
	 */
	public static function record_block( $reason, $recipient = '', $ip = '' ) {
		$today = gmdate( 'Y-m-d', Ashna_Helper::local_now() );
		$stats = get_option( self::STATS_OPTION, array() );
		if ( ! is_array( $stats ) || ! isset( $stats['day'] ) || $today !== $stats['day'] ) {
			$stats = array(
				'day'    => $today,
				'total'  => 0,
				'counts' => array(),
				'recent' => array(),
			);
		}
		$reason = sanitize_key( $reason );
		++$stats['total'];
		$stats['counts'][ $reason ] = isset( $stats['counts'][ $reason ] ) ? $stats['counts'][ $reason ] + 1 : 1;
		array_unshift(
			$stats['recent'],
			array(
				'time'      => current_time( 'mysql' ),
				'reason'    => $reason,
				'recipient' => '' !== $recipient ? Ashna_Helper::mask_identifier( $recipient ) : '',
				'ip'        => $ip,
			)
		);
		$stats['recent'] = array_slice( $stats['recent'], 0, 15 );
		update_option( self::STATS_OPTION, $stats, false );
	}

	/**
	 * Today's refusal statistics.
	 *
	 * @return array
	 */
	public static function block_stats() {
		$stats = get_option( self::STATS_OPTION, array() );
		$today = gmdate( 'Y-m-d', Ashna_Helper::local_now() );
		if ( ! is_array( $stats ) || ! isset( $stats['day'] ) || $today !== $stats['day'] ) {
			return array(
				'day'    => $today,
				'total'  => 0,
				'counts' => array(),
				'recent' => array(),
			);
		}
		return $stats;
	}

	/**
	 * E-mail the site admin, at most once per 6 hours per topic.
	 *
	 * @param string $topic   Topic key.
	 * @param string $subject Subject.
	 * @param string $message Body.
	 */
	private static function notify_admin_once( $topic, $subject, $message ) {
		$key = 'ashna_otp_notified_' . sanitize_key( $topic );
		if ( get_transient( $key ) ) {
			return;
		}
		set_transient( $key, 1, 6 * HOUR_IN_SECONDS );
		/**
		 * Whether to e-mail the admin about a protection event.
		 *
		 * @param bool   $send  Send.
		 * @param string $topic attack|daily_cap.
		 */
		if ( apply_filters( 'ashna_otp_notify_admin', true, $topic ) ) {
			wp_mail( get_option( 'admin_email' ), '[' . wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ) . '] ' . $subject, $message );
		}
	}
}


// ---- Source: includes/core/class-ashna-security.php ----
/**
 * Security, Firewall, Captcha, Rate Limiting & OTP Verification Engine
 *
 * @package Ashna
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Ashna_Security {

	/**
	 * Check if a recipient or IP is whitelisted
	 *
	 * @param string $recipient Normalized phone or email.
	 * @param string $ip        Client IP.
	 * @return bool
	 */
	public static function is_whitelisted( $recipient, $ip = '' ) {
		if ( empty( $ip ) ) {
			$ip = Ashna_Helper::get_client_ip();
		}
		$whitelist = Ashna_Helper::parse_list( Ashna_Helper::get_option( 'whitelisted_identifiers', '' ) );
		if ( empty( $whitelist ) ) {
			return false;
		}
		return in_array( $recipient, $whitelist, true ) || in_array( $ip, $whitelist, true );
	}

	/**
	 * Check if recipient or IP is blacklisted in Firewall
	 *
	 * @param string $recipient Normalized phone or email.
	 * @param string $ip        Client IP.
	 * @return true|WP_Error
	 */
	public static function check_blacklist( $recipient, $ip = '' ) {
		if ( empty( $ip ) ) {
			$ip = Ashna_Helper::get_client_ip();
		}

		// Check IP Blacklist
		$blocked_ips = Ashna_Helper::parse_list( Ashna_Helper::get_option( 'blocked_ips', '' ) );
		foreach ( $blocked_ips as $rule_ip ) {
			if ( $ip === $rule_ip || ( strpos( $rule_ip, '*' ) !== false && fnmatch( $rule_ip, $ip ) ) ) {
				return new WP_Error( 'ashna_blocked_ip', 'دسترسی آی‌پی شما توسط دیوار آتش سایت مسدود شده است.' );
			}
		}

		// Check Phone / Identifier Blacklist
		$blocked_phones = Ashna_Helper::parse_list( Ashna_Helper::get_option( 'blocked_phones', '' ) );
		foreach ( $blocked_phones as $rule ) {
			if ( $recipient === $rule || ( strpos( $rule, '*' ) !== false && fnmatch( $rule, $recipient ) ) || strpos( $recipient, $rule ) === 0 ) {
				return new WP_Error( 'ashna_blocked_recipient', 'امکان ارسال کد به این شماره/شناسه وجود ندارد (مسدود شده).' );
			}
		}

		return true;
	}

	/**
	 * Captcha the form must pass right now: the configured one, or the built-in math captcha
	 * when attack mode is on and nothing (usable) is configured.
	 *
	 * @return string none|math|arcaptcha|recaptcha_v3|turnstile
	 */
	public static function effective_captcha_type() {
		$type = (string) Ashna_Helper::get_option( 'captcha_type', 'none' );
		if ( in_array( $type, array( 'arcaptcha', 'recaptcha_v3', 'turnstile' ), true ) && '' === trim( (string) Ashna_Helper::get_option( 'captcha_secret_key', '' ) ) ) {
			$type = 'none'; // Not configured yet: behaves like no captcha.
		}
		if ( ( '' === $type || 'none' === $type ) && class_exists( 'Ashna_Rate_Limiter' ) && Ashna_Rate_Limiter::attack_mode_active() ) {
			return 'math';
		}
		return '' === $type ? 'none' : $type;
	}

	/**
	 * Whether the built-in math captcha is in use (configured or forced by attack mode).
	 *
	 * @return bool
	 */
	public static function math_captcha_active() {
		return 'math' === self::effective_captcha_type();
	}

	/**
	 * Generate a stateless HMAC Math Captcha challenge (single use, valid for one hour)
	 *
	 * @return array { question: string, token: string }
	 */
	public static function generate_math_captcha() {
		$a      = wp_rand( 11, 49 );
		$b      = wp_rand( 2, 9 );
		$answer = (string) ( $a + $b );
		$ts     = time();
		$rand   = bin2hex( random_bytes( 6 ) ); // two visitors in the same second must never share a token
		$sig    = hash_hmac( 'sha256', $answer . '|' . $ts . '|' . $rand, wp_salt( 'auth' ) );

		return array(
			'question' => sprintf( 'حاصل جمع %d + %d چند می‌شود؟', $a, $b ),
			'token'    => $ts . '.' . $rand . '.' . $sig,
		);
	}

	/**
	 * Mark a captcha token as used. Atomic: of two parallel requests with the same token,
	 * exactly one gets true.
	 *
	 * @param string $sig Token signature.
	 * @return bool True the first time.
	 */
	private static function consume_captcha_token( $sig ) {
		global $wpdb;
		$name = 'ashna_otp_cap_' . substr( preg_replace( '/[^a-f0-9]/', '', strtolower( (string) $sig ) ), 0, 40 );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$inserted = $wpdb->query( $wpdb->prepare( "INSERT IGNORE INTO {$wpdb->options} (option_name, option_value, autoload) VALUES (%s, %s, 'no')", $name, (string) ( time() + 2 * HOUR_IN_SECONDS ) ) );
		return 1 === (int) $inserted;
	}

	/**
	 * Delete used-captcha markers older than their token lifetime (daily cron).
	 */
	public static function purge_used_captcha_tokens() {
		global $wpdb;
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s AND option_value < %s", $wpdb->esc_like( 'ashna_otp_cap_' ) . '%', (string) time() ) );
	}

	/**
	 * Count a wrong/missing captcha for this IP; 10 within 10 minutes lock the IP.
	 */
	private static function captcha_strike() {
		$ip  = Ashna_Helper::get_client_ip();
		$key = 'ashna_capfail_' . md5( $ip );
		$n   = (int) get_transient( $key ) + 1;
		set_transient( $key, $n, 10 * MINUTE_IN_SECONDS );
		if ( $n >= 10 ) {
			delete_transient( $key );
			self::trigger_ip_lockout( $ip );
		}
	}

	/**
	 * Ticket that lets the same visitor (same IP) ask for a resend for the same number
	 * without solving the captcha again. Resends still obey every rate limit.
	 *
	 * @param string $recipient Normalized recipient.
	 * @return string
	 */
	public static function resend_ticket( $recipient ) {
		$ts = time();
		return $ts . '.' . hash_hmac( 'sha256', 'resend|' . $recipient . '|' . Ashna_Helper::get_client_ip() . '|' . $ts, wp_salt( 'nonce' ) );
	}

	/**
	 * Whether a resend ticket is valid for this recipient and visitor (15 minutes).
	 *
	 * @param string $ticket    Ticket.
	 * @param string $recipient Normalized recipient.
	 * @return bool
	 */
	public static function valid_resend_ticket( $ticket, $recipient ) {
		if ( ! is_string( $ticket ) || false === strpos( $ticket, '.' ) ) {
			return false;
		}
		list( $ts, $sig ) = explode( '.', $ticket, 2 );
		$ts               = (int) $ts;
		if ( $ts <= 0 || time() - $ts > 15 * MINUTE_IN_SECONDS || $ts > time() + MINUTE_IN_SECONDS ) {
			return false;
		}
		$expected = hash_hmac( 'sha256', 'resend|' . $recipient . '|' . Ashna_Helper::get_client_ip() . '|' . $ts, wp_salt( 'nonce' ) );
		return hash_equals( $expected, (string) $sig );
	}

	/**
	 * Verify Captcha (Math / Arcaptcha / reCAPTCHA v3 / Cloudflare Turnstile)
	 *
	 * @param array $post_data Submitted POST data.
	 * @return true|WP_Error
	 */
	public static function verify_captcha( $post_data ) {
		$result = self::check_captcha( $post_data );
		if ( is_wp_error( $result ) ) {
			self::captcha_strike();
		}
		return $result;
	}

	/**
	 * Captcha check without side effects on failure.
	 *
	 * @param array $post_data Submitted POST data.
	 * @return true|WP_Error
	 */
	private static function check_captcha( $post_data ) {
		$captcha_type = self::effective_captcha_type();
		if ( 'none' === $captcha_type ) {
			return true;
		}

		// 1. Internal Math Captcha
		if ( 'math' === $captcha_type ) {
			$answer = isset( $post_data['captcha_answer'] ) ? Ashna_Helper::convert_digits( sanitize_text_field( $post_data['captcha_answer'] ) ) : '';
			$token  = isset( $post_data['captcha_token'] ) ? sanitize_text_field( $post_data['captcha_token'] ) : '';

			if ( '' === $answer || empty( $token ) ) {
				return new WP_Error( 'ashna_captcha_empty', 'لطفاً به سوال امنیتی (کپچا) پاسخ دهید.' );
			}

			if ( strpos( $token, '.' ) === false ) {
				return new WP_Error( 'ashna_captcha_invalid', 'توکن امنیتی کپچا نامعتبر است.' );
			}

			$parts = explode( '.', $token );
			if ( 3 === count( $parts ) ) {
				list( $ts, $rand, $sig ) = $parts;
				$signed                  = $answer . '|' . $ts . '|' . $rand;
			} else {
				// Tokens issued before the per-token random part (cached pages, at most one hour old).
				list( $ts, $sig ) = explode( '.', $token, 2 );
				$signed           = $answer . '|' . $ts;
			}
			if ( time() - (int) $ts > HOUR_IN_SECONDS ) {
				return new WP_Error( 'ashna_captcha_expired', 'سوال امنیتی منقضی شده است. لطفاً دوباره تلاش کنید.' );
			}

			// Single use, right or wrong: a solved (or brute-forced) token cannot be replayed.
			if ( ! self::consume_captcha_token( $sig ) ) {
				return new WP_Error( 'ashna_captcha_used', 'این سوال امنیتی قبلاً استفاده شده است. لطفاً به سوال جدید پاسخ دهید.' );
			}

			$expected_sig = hash_hmac( 'sha256', $signed, wp_salt( 'auth' ) );
			if ( ! hash_equals( $expected_sig, $sig ) ) {
				return new WP_Error( 'ashna_captcha_wrong', 'پاسخ سوال امنیتی (کپچا) اشتباه است.' );
			}

			return true;
		}

		// 2. Arcaptcha (آرکپچا - arcaptcha.ir)
		$site_key   = trim( (string) Ashna_Helper::get_option( 'captcha_site_key', '' ) );
		$secret_key = trim( (string) Ashna_Helper::get_option( 'captcha_secret_key', '' ) );
		$user_token = isset( $post_data['captcha_token'] ) ? sanitize_text_field( $post_data['captcha_token'] ) : '';
		if ( empty( $user_token ) && isset( $post_data['arcaptcha-token'] ) ) {
			$user_token = sanitize_text_field( $post_data['arcaptcha-token'] );
		}

		if ( empty( $secret_key ) ) {
			return true; // Skip if admin hasn't entered secret key yet
		}

		if ( empty( $user_token ) ) {
			return new WP_Error( 'ashna_captcha_missing', 'لطفاً تیک امنیتی کپچا (من ربات نیستم) را تکمیل کنید.' );
		}

		if ( 'arcaptcha' === $captcha_type ) {
			$response = wp_remote_post(
				'https://api.arcaptcha.ir/arcaptcha/api/verify',
				array(
					'timeout' => 10,
					'headers' => array(
						'Content-Type' => 'application/json',
					),
					'body'    => wp_json_encode(
						array(
							'challenge_id' => $user_token,
							'site_key'     => $site_key,
							'secret_key'   => $secret_key,
						)
					),
				)
			);

			if ( is_wp_error( $response ) ) {
				return true;
			}

			$body = json_decode( wp_remote_retrieve_body( $response ), true );
			if ( empty( $body['success'] ) ) {
				return new WP_Error( 'ashna_arcaptcha_failed', 'تایید امنیتی آرکپچا ناموفق بود. لطفاً دوباره تلاش کنید.' );
			}

			return true;
		}

		// 3. Google reCAPTCHA v3 or Cloudflare Turnstile
		$verify_url = 'turnstile' === $captcha_type
			? 'https://challenges.cloudflare.com/turnstile/v0/siteverify'
			: 'https://www.google.com/recaptcha/api/siteverify';

		$response = wp_remote_post(
			$verify_url,
			array(
				'timeout' => 10,
				'body'    => array(
					'secret'   => $secret_key,
					'response' => $user_token,
					'remoteip' => Ashna_Helper::get_client_ip(),
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return true;
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( empty( $body['success'] ) ) {
			return new WP_Error( 'ashna_captcha_failed', 'تایید امنیتی ضد ربات ناموفق بود.' );
		}

		return true;
	}

	/**
	 * Read-only check whether a recipient/IP may request a code now (backward-compatible API;
	 * the request flow itself reserves its slot atomically with Ashna_Rate_Limiter::reserve()).
	 *
	 * @param string $recipient Normalized phone or email.
	 * @return true|WP_Error
	 */
	public static function can_request_otp( $recipient ) {
		$ip = Ashna_Helper::get_client_ip();

		$blacklist = self::check_blacklist( $recipient, $ip );
		if ( is_wp_error( $blacklist ) ) {
			return $blacklist;
		}
		if ( self::is_whitelisted( $recipient, $ip ) ) {
			return true;
		}
		$lockout_status = self::check_lockout( $recipient, $ip );
		if ( is_wp_error( $lockout_status ) ) {
			return $lockout_status;
		}
		return Ashna_Rate_Limiter::evaluate( $recipient, $ip, Ashna_IP::subnet( $ip ), 0 );
	}

	/**
	 * Calculate remaining seconds before a new OTP can be requested
	 *
	 * @param string $recipient Normalized phone or email.
	 * @return int Remaining seconds (0 if allowed now).
	 */
	public static function get_resend_remaining( $recipient ) {
		$latest = Ashna_Logger::get_latest_record( $recipient );
		if ( ! $latest || 'failed' === $latest->status ) {
			return 0;
		}

		$cooldown = absint( Ashna_Helper::get_option( 'resend_cooldown', 60 ) );
		$created  = Ashna_Helper::local_ts( $latest->created_at );
		$now      = Ashna_Helper::local_now();
		$elapsed  = $now - $created;

		if ( $elapsed < $cooldown ) {
			return max( 0, $cooldown - $elapsed );
		}

		return 0;
	}

	/**
	 * Check if recipient or IP is temporarily locked out due to brute-force attempts
	 *
	 * @param string $recipient Recipient.
	 * @param string $ip        IP address.
	 * @return true|WP_Error
	 */
	public static function check_lockout( $recipient, $ip = '' ) {
		if ( empty( $ip ) ) {
			$ip = Ashna_Helper::get_client_ip();
		}

		if ( self::is_whitelisted( $recipient, $ip ) ) {
			return true;
		}

		$recipient_key = 'ashna_lock_' . md5( $recipient );
		$ip_key        = 'ashna_lock_ip_' . md5( $ip );
		self::prime_transients( array( $recipient_key, $ip_key ) );

		$recipient_lock = get_transient( $recipient_key );
		$ip_lock        = get_transient( $ip_key );

		if ( $recipient_lock || $ip_lock ) {
			return new WP_Error(
				'ashna_locked_out',
				'به دلیل تلاش‌های ناموفق متعدد، دسترسی شما به صورت موقت مسدود شده است. لطفاً کمی بعد تلاش کنید.'
			);
		}

		return true;
	}

	/**
	 * Load several transients with one options query.
	 *
	 * WordPress 6.3+ can prime the option cache in a single round trip; on older versions (and with
	 * an external object cache, where transients are not options at all) the loop below simply
	 * does what get_transient() would have done on its own.
	 *
	 * @param string[] $keys Transient names (without the _transient_ prefix).
	 */
	private static function prime_transients( array $keys ) {
		if ( ! function_exists( 'wp_prime_option_caches' ) || wp_using_ext_object_cache() ) {
			return;
		}
		$options = array();
		foreach ( $keys as $key ) {
			$options[] = '_transient_' . $key;
			$options[] = '_transient_timeout_' . $key;
		}
		wp_prime_option_caches( $options );
	}

	/**
	 * Lock key shared by every way of naming one account (phone, e-mail, username in any letter
	 * case), so switching identifiers does not reset the failed-password counter.
	 *
	 * @param WP_User $user Account.
	 * @return string
	 */
	public static function account_lock_key( $user ) {
		return 'user:' . strtolower( $user->user_login );
	}

	/**
	 * Record a failed password attempt and lock out when a threshold is reached.
	 *
	 * Counted three ways: the identifier typed, each account it may belong to, and the client IP
	 * (one address guessing across many accounts is locked after 4× the per-account limit).
	 *
	 * @param string   $identifier   Normalized phone/email or username.
	 * @param string[] $account_keys account_lock_key() of the matching accounts.
	 */
	public static function record_failed_password_attempt( $identifier, $account_keys = array() ) {
		$max_attempts = max( 2, absint( Ashna_Helper::get_option( 'max_verify_attempts', 5 ) ) );
		$targets      = array_unique( array_merge( array( (string) $identifier ), array_map( 'strval', (array) $account_keys ) ) );

		// One query for every counter this attempt reads (they are written one by one below,
		// because each value has to survive the request).
		$keys = array();
		foreach ( $targets as $target ) {
			$keys[] = 'ashna_pw_try_' . md5( $target );
		}
		$keys[] = 'ashna_pw_try_ip_' . md5( Ashna_Helper::get_client_ip() );
		self::prime_transients( $keys );

		foreach ( $targets as $target ) {
			$key      = 'ashna_pw_try_' . md5( $target );
			$attempts = (int) get_transient( $key ) + 1;
			set_transient( $key, $attempts, 15 * MINUTE_IN_SECONDS );
			if ( $attempts >= $max_attempts ) {
				delete_transient( $key );
				self::trigger_lockout( $target );
			}
		}

		$ip = Ashna_Helper::get_client_ip();
		if ( '' === $ip || self::is_whitelisted( (string) $identifier, $ip ) ) {
			return;
		}
		$ip_key      = 'ashna_pw_try_ip_' . md5( $ip );
		$ip_attempts = (int) get_transient( $ip_key ) + 1;
		set_transient( $ip_key, $ip_attempts, 15 * MINUTE_IN_SECONDS );
		if ( $ip_attempts >= $max_attempts * 4 ) {
			delete_transient( $ip_key );
			self::trigger_ip_lockout( $ip );
		}
	}

	/**
	 * Clear failed password attempts on successful login
	 *
	 * @param string   $identifier   User identifier.
	 * @param string[] $account_keys account_lock_key() of the signed-in account.
	 */
	public static function clear_password_attempts( $identifier, $account_keys = array() ) {
		foreach ( array_merge( array( (string) $identifier ), (array) $account_keys ) as $target ) {
			delete_transient( 'ashna_pw_try_' . md5( $target ) );
		}
	}

	/**
	 * Write a lock transient, first clearing the one state where the write would be ignored.
	 *
	 * A `_transient_timeout_<key>` row can outlive its value row (any cleanup that deletes
	 * `_transient_*` rows but leaves the paired timeout rows behind). set_transient() then takes
	 * its "create" path, the freshly written lock keeps the old — already passed — timeout, and the
	 * next get_transient() deletes the lock again: the block silently never happens, which for a
	 * lockout is a hole. Reading the key first makes WordPress drop that stale pair itself
	 * (get_transient() removes an expired timeout row together with its value), so the write below
	 * always lands. Locks are written only when a visitor is actually locked out, so the extra read
	 * never touches a normal request.
	 *
	 * @param string $key     Transient name.
	 * @param int    $seconds Lock duration in seconds.
	 */
	private static function write_lock_transient( $key, $seconds ) {
		get_transient( $key ); // Deliberate read: this is what repairs the orphaned-timeout state.
		set_transient( $key, 1, $seconds );
	}

	/**
	 * Lock out a recipient and IP temporarily and register in active lockouts list
	 *
	 * @param string $recipient Recipient.
	 */
	public static function trigger_lockout( $recipient ) {
		$duration = max( 60, absint( Ashna_Helper::get_option( 'lockout_duration', 900 ) ) );
		$ip       = Ashna_Helper::get_client_ip();

		self::write_lock_transient( 'ashna_lock_' . md5( $recipient ), $duration );
		self::write_lock_transient( 'ashna_lock_ip_' . md5( $ip ), $duration );

		self::remember_lockout(
			$recipient,
			array(
				'target'     => $recipient,
				'ip'         => $ip,
				'locked_at'  => current_time( 'mysql' ),
				'expires_ts' => time() + $duration,
			)
		);
	}

	/**
	 * Add an entry to the admin's lockout list (the transients do the blocking; this list only
	 * feeds the Security tab). Kept to the newest 500 entries so an attack cannot bloat it.
	 *
	 * @param string $key   Target key.
	 * @param array  $entry Lockout details.
	 */
	private static function remember_lockout( $key, array $entry ) {
		$lockouts = get_option( 'ashna_active_lockouts', array() );
		if ( ! is_array( $lockouts ) ) {
			$lockouts = array();
		}
		unset( $lockouts[ $key ] );
		$lockouts[ $key ] = $entry;
		if ( count( $lockouts ) > 500 ) {
			$now      = time();
			$lockouts = array_filter(
				$lockouts,
				static function ( $info ) use ( $now ) {
					return isset( $info['expires_ts'] ) && $info['expires_ts'] > $now;
				}
			);
			$lockouts = array_slice( $lockouts, -500, null, true );
		}
		update_option( 'ashna_active_lockouts', $lockouts, false );
	}

	/**
	 * Lock out an IP (e.g. repeated wrong captcha answers).
	 *
	 * @param string $ip IP.
	 */
	public static function trigger_ip_lockout( $ip ) {
		$duration = max( 60, absint( Ashna_Helper::get_option( 'lockout_duration', 900 ) ) );
		self::write_lock_transient( 'ashna_lock_ip_' . md5( $ip ), $duration );

		self::remember_lockout(
			$ip,
			array(
				'target'     => $ip,
				'ip'         => $ip,
				'locked_at'  => current_time( 'mysql' ),
				'expires_ts' => time() + $duration,
			)
		);
	}

	/**
	 * Get all currently active lockouts for Admin Firewall table
	 *
	 * @return array
	 */
	public static function get_active_lockouts() {
		$lockouts = get_option( 'ashna_active_lockouts', array() );
		if ( ! is_array( $lockouts ) || empty( $lockouts ) ) {
			return array();
		}

		$now     = time();
		$active  = array();
		$changed = false;

		foreach ( $lockouts as $key => $info ) {
			if ( isset( $info['expires_ts'] ) && $info['expires_ts'] > $now ) {
				$info['remaining_sec'] = $info['expires_ts'] - $now;
				$active[ $key ]        = $info;
			} else {
				$changed = true;
			}
		}

		if ( $changed ) {
			update_option( 'ashna_active_lockouts', $active, false );
		}

		return $active;
	}

	/**
	 * Unlock a specific target and its associated IP immediately
	 *
	 * @param string $target Recipient or key.
	 * @return bool
	 */
	public static function unlock_target( $target ) {
		$lockouts = get_option( 'ashna_active_lockouts', array() );
		if ( ! is_array( $lockouts ) ) {
			$lockouts = array();
		}

		delete_transient( 'ashna_lock_' . md5( $target ) );
		delete_transient( 'ashna_pw_try_' . md5( $target ) );
		if ( isset( $lockouts[ $target ]['ip'] ) ) {
			delete_transient( 'ashna_lock_ip_' . md5( $lockouts[ $target ]['ip'] ) );
		}

		unset( $lockouts[ $target ] );
		update_option( 'ashna_active_lockouts', $lockouts, false );
		return true;
	}

	/**
	 * Verify submitted OTP code for a recipient
	 *
	 * @param string $recipient Normalized phone or email.
	 * @param string $code      Submitted OTP code.
	 * @return true|WP_Error
	 */
	public static function verify_otp( $recipient, $code ) {
		$code = Ashna_Helper::convert_digits( $code );
		$code = preg_replace( '/[^0-9]/', '', $code );

		if ( empty( $code ) ) {
			return new WP_Error( 'ashna_empty_code', 'لطفاً کد تایید را وارد کنید.' );
		}

		$lockout = self::check_lockout( $recipient );
		if ( is_wp_error( $lockout ) ) {
			return $lockout;
		}

		$record = Ashna_Logger::get_latest_record( $recipient );
		if ( ! $record ) {
			return new WP_Error( 'ashna_no_otp', 'کد فعالی برای این شماره/ایمیل یافت نشد. لطفاً مجدداً درخواست کد دهید.' );
		}

		if ( 'verified' === $record->status ) {
			return new WP_Error( 'ashna_already_used', 'این کد قبلاً استفاده شده است. لطفاً کد جدید دریافت کنید.' );
		}

		if ( 'sent' !== $record->status ) {
			return new WP_Error( 'ashna_invalid_state', 'کد تایید منقضی یا نامعتبر شده است. لطفاً مجدداً درخواست کد دهید.' );
		}

		$now        = Ashna_Helper::local_now();
		$expires_at = Ashna_Helper::local_ts( $record->expires_at );
		$expiry_sec = absint( Ashna_Helper::get_option( 'otp_expiry', 120 ) );

		// A code that would stay valid longer than the expiry setting was issued before the clock
		// went back (DST ended, or the site timezone was changed): treat it as expired too.
		if ( $now > $expires_at || $expires_at - $now > $expiry_sec + 5 ) {
			Ashna_Logger::update( $record->id, array( 'status' => 'expired' ) );
			return new WP_Error( 'ashna_expired_code', 'مهلت استفاده از این کد به پایان رسیده است. لطفاً کد جدید دریافت کنید.' );
		}

		$max_attempts = max( 1, absint( Ashna_Helper::get_option( 'max_verify_attempts', 5 ) ) );
		if ( (int) $record->attempts >= $max_attempts ) {
			Ashna_Logger::update( $record->id, array( 'status' => 'expired' ) );
			self::trigger_lockout( $recipient );
			return new WP_Error( 'ashna_max_attempts', 'تعداد تلاش‌های مجاز برای این کد به پایان رسید. لطفاً کمی بعد کد جدید دریافت کنید.' );
		}

		$is_valid = wp_check_password( $code, $record->otp_hash );

		if ( ! $is_valid ) {
			$new_attempts = (int) $record->attempts + 1;
			$update_data  = array( 'attempts' => $new_attempts );

			if ( $new_attempts >= $max_attempts ) {
				$update_data['status'] = 'expired';
				self::trigger_lockout( $recipient );
			}

			Ashna_Logger::update( $record->id, $update_data );

			$remaining_tries = max( 0, $max_attempts - $new_attempts );
			if ( 0 === $remaining_tries ) {
				return new WP_Error( 'ashna_max_attempts', 'کد وارد شده اشتباه است. به دلیل تلاش بیش از حد، کد باطل شد.' );
			}

			return new WP_Error(
				'ashna_wrong_code',
				sprintf( 'کد وارد شده صحیح نیست. (%d تلاش باقی‌مانده)', $remaining_tries )
			);
		}

		// Valid OTP! Mark record as verified
		Ashna_Logger::update(
			$record->id,
			array(
				'status'      => 'verified',
				'verified_at' => current_time( 'mysql' ),
				'otp_code'    => '****',
			)
		);

		return true;
	}
}


// ---- Source: includes/core/class-ashna-session.php ----
/**
 * WordPress-native login session shared by every Ashna sign-in path (OTP, password, passkey).
 *
 * Ashna does not keep its own session or token store (no parallel JWT that could drift
 * from WordPress). A verified sign-in becomes exactly the session wp-login.php creates:
 * auth cookies backed by WP_Session_Tokens, the current user switched in the same
 * request, `wp_login` fired and — when WooCommerce is active — the guest cart/session
 * moved to the customer the same way wc_set_customer_auth_cookie() does it. Roles,
 * capabilities, WooCommerce permissions and membership levels are therefore read from
 * the normal WordPress user, and a re-login replaces the previous session instead of
 * stacking up stale ones.
 *
 * @package Ashna
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Ashna_Session {

	/**
	 * Nonce action used by the public login form.
	 */
	const NONCE_ACTION = 'ashna_otp_nonce';

	/**
	 * Register AJAX endpoints.
	 */
	public static function init() {
		add_action( 'wp_ajax_nopriv_ashna_refresh_session', array( __CLASS__, 'ajax_refresh' ) );
		add_action( 'wp_ajax_ashna_refresh_session', array( __CLASS__, 'ajax_refresh' ) );
	}

	/**
	 * Verify the form nonce of an Ashna AJAX request.
	 *
	 * A stale nonce is normal for a login form: the page may come from a page cache, the
	 * visitor may have signed in or out in another tab, or the session may have expired.
	 * Instead of WordPress's bare "-1", answer with a machine-readable error and a fresh
	 * nonce for the *current* session so the form can retry once on its own.
	 *
	 * @param string $field Request field holding the nonce.
	 * @return bool true when the nonce is valid (a refusal ends the request instead).
	 */
	public static function verify_request( $field = 'nonce' ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- this is the nonce check.
		$nonce = isset( $_REQUEST[ $field ] ) ? sanitize_text_field( wp_unslash( $_REQUEST[ $field ] ) ) : '';
		if ( '' !== $nonce && false !== wp_verify_nonce( $nonce, self::NONCE_ACTION ) ) {
			return true;
		}

		self::send_json(
			false,
			array(
				'code'      => 'ashna_nonce_expired',
				'message'   => 'اعتبار صفحه به پایان رسیده بود و به‌روز شد. لطفاً دوباره تلاش کنید.',
				'nonce'     => wp_create_nonce( self::NONCE_ACTION ),
				'logged_in' => is_user_logged_in(),
			),
			403
		);

		// wp_send_json() ends the request, so this is only reachable in a test harness or if
		// something replaced the wp_die handler. Fail closed: every caller stops on anything
		// other than a strict true.
		return false;
	}

	/**
	 * Sign a verified user in, the WordPress way.
	 *
	 * @param WP_User $user    Verified user.
	 * @param array   $context { method: otp|password|passkey, identifier, is_new_user, authenticated }.
	 * @return true|WP_Error
	 */
	public static function login( $user, array $context = array() ) {
		$context = wp_parse_args(
			$context,
			array(
				'method'        => 'otp',
				'identifier'    => '',
				'is_new_user'   => false,
				'authenticated' => false, // true when wp_authenticate() already ran the full filter chain.
			)
		);

		if ( ! $user instanceof WP_User || ! $user->exists() ) {
			return new WP_Error( 'ashna_invalid_user', 'حساب کاربری معتبر نیست.' );
		}

		$gate = self::check_gates( $user, $context );
		if ( is_wp_error( $gate ) ) {
			return $gate;
		}

		// Replace — never stack — the session this browser already had (re-login or account switch).
		if ( is_user_logged_in() ) {
			wp_destroy_current_session();
		}
		wp_clear_auth_cookie();

		$remember = (bool) apply_filters( 'ashna_otp_remember_login', (bool) Ashna_Helper::get_option( 'session_remember', 1 ), $user, $context );

		add_action( 'set_logged_in_cookie', array( __CLASS__, 'expose_logged_in_cookie' ), 10, 1 );
		add_filter( 'auth_cookie_expiration', array( __CLASS__, 'session_length' ), 99, 3 );
		wp_set_auth_cookie( $user->ID, $remember, is_ssl() );
		remove_filter( 'auth_cookie_expiration', array( __CLASS__, 'session_length' ), 99 );
		remove_action( 'set_logged_in_cookie', array( __CLASS__, 'expose_logged_in_cookie' ), 10 );

		wp_set_current_user( $user->ID );

		// WooCommerce: move the guest cart/session to the customer now, as wc_set_customer_auth_cookie() does.
		self::migrate_woocommerce_session();

		do_action( 'wp_login', $user->user_login, $user );

		/**
		 * Fires after Ashna signed a user in (any method).
		 *
		 * @param WP_User $user    Signed-in user.
		 * @param array   $context Sign-in context.
		 */
		do_action( 'ashna_otp_logged_in', $user, $context );

		return true;
	}

	/**
	 * Pre-login checks that WordPress and other plugins expect every sign-in to pass.
	 *
	 * @param WP_User $user    User.
	 * @param array   $context Sign-in context.
	 * @return true|WP_Error
	 */
	public static function check_gates( WP_User $user, array $context = array() ) {
		if ( is_multisite() && is_user_spammy( $user ) ) {
			return new WP_Error( 'ashna_spammer', 'این حساب کاربری مسدود شده است.' );
		}

		if ( empty( $context['authenticated'] ) && Ashna_Helper::get_option( 'respect_login_gates', 1 ) ) {
			// The same pre-login check wp-login.php runs for every sign-in, so approval, ban
			// and lockout plugins keep the final word even when no password is involved.
			$checked = apply_filters( 'wp_authenticate_user', $user, '' );
			if ( is_wp_error( $checked ) ) {
				return self::readable_error( $checked );
			}
			if ( ! $checked instanceof WP_User ) {
				return new WP_Error( 'ashna_login_denied', 'ورود به این حساب امکان‌پذیر نیست.' );
			}
		}

		/**
		 * Lets integrations refuse a sign-in (membership approval, banned accounts, ...).
		 *
		 * @param true|WP_Error $allowed True to allow.
		 * @param WP_User       $user    User.
		 * @param array         $context Sign-in context.
		 */
		$allowed = apply_filters( 'ashna_otp_can_login', true, $user, $context );
		if ( is_wp_error( $allowed ) ) {
			return self::readable_error( $allowed );
		}
		if ( true !== $allowed ) {
			return new WP_Error( 'ashna_login_denied', 'ورود به این حساب امکان‌پذیر نیست.' );
		}

		return true;
	}

	/**
	 * Make the new logged-in cookie visible to the rest of this request, so nonces
	 * created after the sign-in (returned to the browser) belong to the new session.
	 *
	 * @param string $logged_in_cookie Cookie value.
	 */
	public static function expose_logged_in_cookie( $logged_in_cookie ) {
		$_COOKIE[ LOGGED_IN_COOKIE ] = $logged_in_cookie;
	}

	/**
	 * Session length for "remembered" sign-ins (filter: auth_cookie_expiration).
	 *
	 * @param int  $length   Default length in seconds.
	 * @param int  $user_id  User ID.
	 * @param bool $remember Whether the session is remembered.
	 * @return int
	 */
	public static function session_length( $length, $user_id = 0, $remember = false ) {
		$days = absint( Ashna_Helper::get_option( 'session_days', 14 ) );
		if ( $remember && $days > 0 ) {
			return min( 365, $days ) * DAY_IN_SECONDS;
		}
		return $length;
	}

	/**
	 * Move the WooCommerce guest session/cart to the signed-in customer.
	 */
	private static function migrate_woocommerce_session() {
		if ( ! function_exists( 'WC' ) ) {
			return;
		}
		$wc = WC();
		if ( is_object( $wc ) && isset( $wc->session ) && is_object( $wc->session ) && is_callable( array( $wc->session, 'init_session_cookie' ) ) ) {
			$wc->session->init_session_cookie();
		}
	}

	/**
	 * Data the browser needs after a sign-in (nonce valid for the new session).
	 *
	 * @return array
	 */
	public static function client_state() {
		return array(
			'nonce'     => wp_create_nonce( self::NONCE_ACTION ),
			'logged_in' => is_user_logged_in(),
		);
	}

	/**
	 * AJAX: hand the form a nonce (and a math captcha) for the current session.
	 * Used for pages served from a cache, restored from the back/forward cache, or after a
	 * sign-in/out in another tab. Read-only: the response cannot be read cross-site.
	 */
	public static function ajax_refresh() {
		nocache_headers();
		$data = self::client_state();
		if ( ! is_user_logged_in() && class_exists( 'Ashna_Security' ) && Ashna_Security::math_captcha_active() ) {
			// One single-use question per form on the page (inline form + popup + checkout box).
			$data['captchas'] = array( Ashna_Security::generate_math_captcha(), Ashna_Security::generate_math_captcha(), Ashna_Security::generate_math_captcha() );
			$data['captcha']  = $data['captchas'][0];
		}
		self::send_json( true, $data );
		return; // wp_send_json() ends the request: never continue past a response.
	}

	/**
	 * Where to send a user after signing in. One resolver for OTP, password and passkey.
	 *
	 * Order: a destination pinned for this kind of account (admins / per role) → the page
	 * the visitor asked for → Ashna's redirect setting; then, unless disabled, the same
	 * filters wp-login.php (`login_redirect`) and WooCommerce My Account
	 * (`woocommerce_login_redirect`, used by Dokan for its vendor dashboard) apply.
	 *
	 * @param WP_User $user      Signed-in user.
	 * @param string  $requested Redirect requested by the form/URL.
	 * @param array   $context   { is_new_user: bool, form: string (form context, e.g. member-ultimatemember) }.
	 * @return string
	 */
	public static function redirect_url( $user, $requested = '', $context = array() ) {
		$context   = wp_parse_args(
			$context,
			array(
				'is_new_user' => false,
				'form'        => '',
			)
		);
		$fallback  = home_url( '/' );
		$requested = is_string( $requested ) && '' !== trim( $requested ) ? wp_validate_redirect( trim( $requested ), '' ) : '';

		$pinned = self::pinned_redirect( $user );
		if ( '' !== $pinned ) {
			return wp_validate_redirect( (string) apply_filters( 'ashna_otp_login_redirect', $pinned, $user, $requested ), $fallback );
		}

		$redirect = '' !== $requested ? $requested : self::default_redirect();

		if ( Ashna_Helper::get_option( 'respect_plugin_redirects', 1 ) ) {
			$chosen = $requested;
			if ( '' === $requested ) {
				/**
				 * Destination an integration picks when nothing was requested (e.g. Ultimate Member's
				 * per-role "after login" setting on its login page).
				 *
				 * @param string  $redirect Current destination.
				 * @param WP_User $user     User.
				 * @param array   $context  Sign-in context.
				 */
				$filtered = (string) apply_filters( 'ashna_otp_default_redirect', $redirect, $user, $context );
				if ( $filtered !== $redirect ) {
					$redirect = $filtered;
					$chosen   = $filtered;
				}
			}

			// wp-login.php semantics: plugins (e.g. Paid Memberships Pro) pick a page when the
			// destination is still empty; a requested or integration-chosen page is passed on.
			$from_login = apply_filters( 'login_redirect', $chosen, $requested, $user );
			if ( is_string( $from_login ) && '' !== $from_login ) {
				$redirect = $from_login;
			}

			// WooCommerce semantics: sign-ups use the registration redirect (Dokan: vendor setup
			// wizard / dashboard), sign-ins the My Account login redirect (Dokan: vendor dashboard).
			if ( class_exists( 'WooCommerce' ) ) {
				if ( $context['is_new_user'] ) {
					$filtered = apply_filters( 'woocommerce_registration_redirect', $redirect );
					$redirect = is_string( $filtered ) && '' !== $filtered ? str_replace( array( '&#038;', '&amp;' ), '&', $filtered ) : $redirect;
				} else {
					$redirect = self::woocommerce_login_redirect( $redirect, $user, $requested );
				}
			}
		}

		$redirect = (string) apply_filters( 'ashna_otp_login_redirect', $redirect, $user, $requested );
		return wp_validate_redirect( $redirect, $fallback );
	}

	/**
	 * Apply `woocommerce_login_redirect` with the request context WooCommerce/Dokan expect:
	 * a requested destination is visible as $_GET['redirect_to'] (Dokan honours it).
	 *
	 * @param string  $redirect  Current destination.
	 * @param WP_User $user      User.
	 * @param string  $requested Requested destination.
	 * @return string
	 */
	private static function woocommerce_login_redirect( $redirect, $user, $requested ) {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- temporary request context only.
		$had_get = array_key_exists( 'redirect_to', $_GET );
		$old_get = $had_get ? $_GET['redirect_to'] : null; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		if ( '' !== $requested ) {
			$_GET['redirect_to'] = $requested;
		} else {
			unset( $_GET['redirect_to'] );
		}

		try {
			$filtered = apply_filters( 'woocommerce_login_redirect', $redirect, $user );
		} finally {
			if ( $had_get ) {
				$_GET['redirect_to'] = $old_get;
			} else {
				unset( $_GET['redirect_to'] );
			}
		}
		// phpcs:enable

		if ( ! is_string( $filtered ) || '' === $filtered ) {
			return $redirect;
		}
		// Some handlers return esc_url() output; turn HTML entities back into a usable URL.
		return str_replace( array( '&#038;', '&amp;' ), '&', $filtered );
	}

	/**
	 * Destination pinned by the site owner for this kind of account.
	 *
	 * @param WP_User $user User.
	 * @return string
	 */
	private static function pinned_redirect( $user ) {
		$admin_redirect = trim( (string) Ashna_Helper::get_option( 'admin_redirect_url', '' ) );
		if ( '' !== $admin_redirect && user_can( $user, 'manage_options' ) ) {
			return esc_url_raw( $admin_redirect );
		}

		/**
		 * Per-role destinations (filled by the integrations module).
		 *
		 * @param string  $url  Pinned URL or ''.
		 * @param WP_User $user User.
		 */
		$pinned = apply_filters( 'ashna_otp_pinned_redirect', '', $user );
		return is_string( $pinned ) ? trim( $pinned ) : '';
	}

	/**
	 * Destination from Ashna's "after sign-in" setting.
	 *
	 * @return string
	 */
	private static function default_redirect() {
		$behavior   = Ashna_Helper::get_option( 'redirect_behavior', 'auto' );
		$custom     = trim( (string) Ashna_Helper::get_option( 'custom_redirect_url', '' ) );
		$custom     = '' !== $custom ? $custom : trim( (string) Ashna_Helper::get_option( 'redirect_url', '' ) );
		$my_account = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : '';

		if ( 'custom' === $behavior && '' !== $custom ) {
			return esc_url_raw( $custom );
		}
		if ( 'my_account' === $behavior || 'myaccount' === $behavior ) {
			return '' !== $my_account ? $my_account : admin_url( 'profile.php' );
		}
		if ( 'home' === $behavior ) {
			return home_url( '/' );
		}

		$referer = wp_get_referer();
		if ( ( 'auto' === $behavior || 'referer' === $behavior ) && $referer && ! self::is_login_screen( $referer ) ) {
			return wp_validate_redirect( $referer, home_url( '/' ) );
		}

		return '' !== $my_account ? $my_account : home_url( '/' );
	}

	/**
	 * Whether a URL is a sign-in screen (going back there after signing in is pointless).
	 *
	 * @param string $url URL.
	 * @return bool
	 */
	private static function is_login_screen( $url ) {
		$path = (string) wp_parse_url( $url, PHP_URL_PATH );
		if ( false !== strpos( $path, 'wp-login.php' ) ) {
			return true;
		}
		$page_id = absint( Ashna_Helper::get_option( 'standalone_page_id', 0 ) );
		if ( $page_id > 0 ) {
			$login_path = (string) wp_parse_url( (string) get_permalink( $page_id ), PHP_URL_PATH );
			if ( '' !== $login_path && '/' !== $login_path && untrailingslashit( $login_path ) === untrailingslashit( $path ) ) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Plain-text error for the form (plugin messages may contain markup).
	 *
	 * @param WP_Error $error Error.
	 * @return WP_Error
	 */
	public static function readable_error( WP_Error $error ) {
		$message = trim( wp_strip_all_tags( $error->get_error_message() ) );
		$message = preg_replace( '/^(error|خطا)\s*:\s*/iu', '', $message );
		return new WP_Error( $error->get_error_code(), '' !== $message ? $message : 'ورود به این حساب امکان‌پذیر نیست.' );
	}

	/**
	 * Send a JSON response with a clean buffer.
	 *
	 * @param bool  $success Success flag.
	 * @param array $data    Payload.
	 * @param int   $status  HTTP status.
	 */
	public static function send_json( $success, $data, $status = null ) {
		if ( ob_get_length() ) {
			ob_clean();
		}
		if ( $success ) {
			wp_send_json_success( $data, $status );
		}
		wp_send_json_error( $data, $status );
		return; // wp_send_json() ends the request: never continue past a response.
	}
}


// ---- Source: includes/gateways/interface-ashna-gateway.php ----
/**
 * Gateway Interface for Ashna
 *
 * @package Ashna
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

interface Ashna_Gateway_Interface {

	/**
	 * Get gateway unique slug ID
	 *
	 * @return string
	 */
	public function get_id();

	/**
	 * Get gateway Persian title
	 *
	 * @return string
	 */
	public function get_title();

	/**
	 * Send OTP code to recipient
	 *
	 * @param string $recipient Normalized phone number or email.
	 * @param string $code      Generated OTP code.
	 * @return true|WP_Error    True on success or WP_Error with failure details.
	 */
	public function send( $recipient, $code );
}


// ---- Source: includes/gateways/abstract-ashna-gateway.php ----
/**
 * Abstract Base Gateway Class for Ashna
 *
 * @package Ashna
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

abstract class Ashna_Abstract_Gateway implements Ashna_Gateway_Interface {

	/**
	 * Transport trace of the current send(): number of HTTP calls and the last call.
	 *
	 * @var array|null
	 */
	private static $trace = null;

	/**
	 * Whether the cURL connect-timeout hook is registered.
	 *
	 * @var bool
	 */
	private static $curl_hook_added = false;

	/**
	 * Start a fresh transport trace (called before each gateway attempt).
	 */
	public static function reset_trace() {
		self::$trace = array(
			'calls'     => 0,
			'last'      => null,
			'exhausted' => '',
		);
	}

	/**
	 * Transport trace of the last attempt.
	 *
	 * @return array|null
	 */
	public static function get_trace() {
		return self::$trace;
	}

	/**
	 * Delivery channel of this gateway (sms | bale | messenger | email).
	 * Used to keep a rejected number from cascading inside the same channel.
	 *
	 * @return string
	 */
	public function get_channel() {
		return 'sms';
	}

	/**
	 * Base URL checked by the background health probe (a HEAD request; any
	 * HTTP answer means reachable). Empty: the gateway is not probed.
	 *
	 * @return string
	 */
	public function get_probe_url() {
		return '';
	}

	/**
	 * Helper to read a setting option
	 *
	 * @param string $key     Option key.
	 * @param mixed  $default Default fallback.
	 * @return mixed
	 */
	protected function get_setting( $key, $default = '' ) {
		return Ashna_Helper::get_option( $key, $default );
	}

	/**
	 * POST through the WordPress HTTP API with fast-failover time limits.
	 *
	 * The timeout comes from Ashna_Failover (short per-gateway limit, capped by
	 * the remaining dispatch budget), so a hung provider cannot stall the visitor.
	 *
	 * @param string $url  Endpoint URL.
	 * @param array  $args wp_remote_post() arguments (any 'timeout' is replaced).
	 * @return array|WP_Error
	 */
	protected function remote_post( $url, $args = array() ) {
		if ( null === self::$trace ) {
			self::reset_trace();
		}

		$limits = Ashna_Failover::http_limits();
		if ( is_wp_error( $limits ) ) {
			$data                     = $limits->get_error_data();
			self::$trace['exhausted'] = isset( $data['ashna_error_type'] ) ? $data['ashna_error_type'] : 'timeout';
			return $limits;
		}

		self::ensure_curl_hook();

		$args                          = is_array( $args ) ? $args : array();
		$args['timeout']               = $limits['timeout'];
		$args['ashna_connect_timeout'] = $limits['connect'];

		$started  = microtime( true );
		$response = wp_remote_post( $url, $args );

		++self::$trace['calls'];
		self::$trace['last'] = array(
			'host'  => (string) wp_parse_url( $url, PHP_URL_HOST ), // Host only: some URLs embed API keys.
			'ms'    => (int) round( ( microtime( true ) - $started ) * 1000 ),
			'code'  => is_wp_error( $response ) ? 0 : (int) wp_remote_retrieve_response_code( $response ),
			'error' => is_wp_error( $response ) ? $response->get_error_message() : '',
		);

		return $response;
	}

	/**
	 * Register the connect-timeout hook once.
	 */
	public static function ensure_curl_hook() {
		if ( ! self::$curl_hook_added ) {
			add_action( 'http_api_curl', array( __CLASS__, 'apply_connect_timeout' ), 10, 3 );
			self::$curl_hook_added = true;
		}
	}

	/**
	 * Limit the connect phase (DNS + TCP + TLS) of Ashna's own requests, so an
	 * unreachable provider fails within seconds. WordPress only passes the total
	 * timeout to cURL; other requests on the site are not touched.
	 *
	 * @param resource|CurlHandle $handle cURL handle.
	 * @param array               $args   Parsed wp_remote_*() arguments.
	 * @param string              $url    Request URL.
	 */
	public static function apply_connect_timeout( $handle, $args, $url ) {
		if ( empty( $args['ashna_connect_timeout'] ) || ! defined( 'CURLOPT_CONNECTTIMEOUT_MS' ) ) {
			return;
		}
		$ms = max( 500, (int) round( (float) $args['ashna_connect_timeout'] * 1000 ) );
		curl_setopt( $handle, CURLOPT_CONNECTTIMEOUT_MS, $ms ); // phpcs:ignore WordPress.WP.AlternativeFunctions.curl_curl_setopt -- Only reachable from the http_api_curl hook.
	}

	/**
	 * Send a JSON POST HTTP request
	 *
	 * @param string $url     Endpoint URL.
	 * @param array  $payload Array to JSON-encode.
	 * @param array  $headers Optional additional headers.
	 * @return array|WP_Error { code: int, body: array|null, raw: string }
	 */
	protected function post_json( $url, $payload, $headers = array() ) {
		$default_headers = array(
			'Content-Type' => 'application/json',
			'Accept'       => 'application/json',
		);

		$response = $this->remote_post(
			$url,
			array(
				'headers' => array_merge( $default_headers, $headers ),
				'body'    => wp_json_encode( $payload ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return $response;
		}

		$raw = wp_remote_retrieve_body( $response );
		return array(
			'code' => (int) wp_remote_retrieve_response_code( $response ),
			'body' => json_decode( $raw, true ),
			'raw'  => $raw,
		);
	}
}


// ---- Source: includes/gateways/class-ashna-gateway-msgway.php ----
/**
 * Rahpayam (راه‌پیام, MsgWay) Gateway: SMS through api.msgway.com
 *
 * Rahpayam delivers template messages over SMS, voice and Iranian messengers
 * (Gap, Eitaa, iGap, Bale, Rubika) behind one API. This class is the SMS
 * route; Ashna_Gateway_Msgway_Messenger is the messenger route.
 *
 * API (doc.msgway.com/swagger.json, official SDKs): POST /send with headers
 * apiKey + accept-language and { method, mobile, templateID, code, provider }.
 *
 * @package Ashna
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Ashna_Gateway_Msgway extends Ashna_Abstract_Gateway {

	/** Send endpoint. */
	const SEND_URL = 'https://api.msgway.com/send';

	/**
	 * Get gateway ID
	 *
	 * @return string
	 */
	public function get_id() {
		return 'msgway';
	}

	/**
	 * Get gateway title
	 *
	 * @return string
	 */
	public function get_title() {
		return 'راه‌پیام (MsgWay)';
	}

	/**
	 * Host checked by the background health probe.
	 *
	 * @return string
	 */
	public function get_probe_url() {
		return 'https://api.msgway.com/';
	}

	/**
	 * Send OTP as SMS through Rahpayam
	 *
	 * @param string $recipient Normalized phone number.
	 * @param string $code      OTP code.
	 * @return true|WP_Error
	 */
	public function send( $recipient, $code ) {
		return $this->request(
			'sms',
			absint( Ashna_Helper::get_option( 'msgway_sms_template_id' ) ),
			absint( Ashna_Helper::get_option( 'msgway_sms_line', 0 ) ),
			$recipient,
			$code
		);
	}

	/**
	 * Call POST /send.
	 *
	 * @param string $method      sms | messenger | smart.
	 * @param int    $template_id Approved template ID from the Rahpayam panel.
	 * @param int    $provider    Provider ID (0 = Rahpayam's default).
	 * @param string $recipient   Phone.
	 * @param string $code        OTP code (Ashna generates and verifies it).
	 * @return true|WP_Error
	 */
	protected function request( $method, $template_id, $provider, $recipient, $code ) {
		$api_key = trim( (string) Ashna_Helper::get_option( 'msgway_api_key' ) );
		if ( empty( $api_key ) || empty( $template_id ) ) {
			return new WP_Error( 'msgway_config', 'کلید API یا شناسه الگوی راه‌پیام تنظیم نشده است.' );
		}

		$payload = array(
			'method'     => $method,
			'mobile'     => Ashna_Helper::to_international_phone( $recipient, true ), // +98912xxxxxxx
			'templateID' => (int) $template_id,
			'code'       => (string) $code,
		);
		if ( $provider > 0 ) {
			$payload['provider'] = (int) $provider;
		}

		$response = $this->remote_post(
			self::SEND_URL,
			array(
				'headers' => array(
					'Content-Type'    => 'application/json',
					'accept-language' => 'fa',
					'apiKey'          => $api_key,
				),
				'body'    => wp_json_encode( $payload ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'msgway_http_error', 'خطای ارتباط با راه‌پیام: ' . $response->get_error_message() );
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( isset( $body['status'] ) && 'success' === $body['status'] && ! empty( $body['referenceID'] ) ) {
			return true;
		}

		$err = isset( $body['error']['message'] ) && '' !== (string) $body['error']['message']
			? (string) $body['error']['message']
			: 'خطا در ارسال از طریق راه‌پیام (کد HTTP: ' . (int) wp_remote_retrieve_response_code( $response ) . ')';
		return new WP_Error( 'msgway_api_error', $err );
	}
}


// ---- Source: includes/gateways/class-ashna-gateway-msgway-messenger.php ----
/**
 * Rahpayam (راه‌پیام) Messenger Gateway: Iranian messengers via api.msgway.com
 *
 * Modes:
 * - smart:  Rahpayam picks the route among the channels enabled in its panel
 *           (Gap, Eitaa, iGap, Bale, Rubika; optionally SMS) with its own failover.
 * - gap / igap: one messenger (documented provider IDs 2 and 8).
 * - custom: any other messenger, by the provider ID shown in the Rahpayam panel.
 *
 * @package Ashna
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Ashna_Gateway_Msgway_Messenger extends Ashna_Gateway_Msgway {

	/**
	 * Documented messenger provider IDs.
	 *
	 * @var array<string, int>
	 */
	const PROVIDERS = array(
		'gap'  => 2,
		'igap' => 8,
	);

	/**
	 * Get gateway ID
	 *
	 * @return string
	 */
	public function get_id() {
		return 'msgway_messenger';
	}

	/**
	 * Get gateway title
	 *
	 * @return string
	 */
	public function get_title() {
		return 'پیام‌رسان‌های ایرانی (راه‌پیام)';
	}

	/**
	 * Delivery channel.
	 *
	 * @return string
	 */
	public function get_channel() {
		return 'messenger';
	}

	/**
	 * Visitor-facing name of the route, e.g. for "the code was sent via …".
	 *
	 * @return string
	 */
	public static function route_label() {
		$mode = Ashna_Helper::get_option( 'msgway_messenger_mode', 'smart' );
		if ( 'gap' === $mode ) {
			return 'پیام‌رسان گپ';
		}
		if ( 'igap' === $mode ) {
			return 'پیام‌رسان آی‌گپ';
		}
		return 'پیام‌رسان‌های داخلی';
	}

	/**
	 * Send OTP through Iranian messengers
	 *
	 * @param string $recipient Normalized phone number.
	 * @param string $code      OTP code.
	 * @return true|WP_Error
	 */
	public function send( $recipient, $code ) {
		$mode        = Ashna_Helper::get_option( 'msgway_messenger_mode', 'smart' );
		$template_id = absint( Ashna_Helper::get_option( 'msgway_messenger_template_id' ) );

		if ( 'smart' === $mode ) {
			return $this->request( 'smart', $template_id, 0, $recipient, $code );
		}

		if ( isset( self::PROVIDERS[ $mode ] ) ) {
			$provider = self::PROVIDERS[ $mode ];
		} else {
			$provider = absint( Ashna_Helper::get_option( 'msgway_messenger_provider', 0 ) );
			if ( empty( $provider ) ) {
				return new WP_Error( 'msgway_config', 'شناسه پیام‌رسان (provider) راه‌پیام وارد نشده است.' );
			}
		}

		return $this->request( 'messenger', $template_id, $provider, $recipient, $code );
	}
}


// ---- Source: includes/gateways/class-ashna-gateway-bale.php ----
/**
 * Bale Messenger OTP Gateway (Safir v3 OTP API + Bale Bot API)
 *
 * Safir v3 (docs.bale.ai/safir): one request per code, authenticated with the
 * organisation's api-access-key; the code is delivered by Bale's official
 * verification bot with your bot's name and a copy button.
 *
 * @package Ashna
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Ashna_Gateway_Bale extends Ashna_Abstract_Gateway {

	/** Safir v3 message endpoint. */
	const SAFIR_URL = 'https://safir.bale.ai/api/v3/send_message';

	/**
	 * Get gateway ID
	 *
	 * @return string
	 */
	public function get_id() {
		return 'bale';
	}

	/**
	 * Get gateway title
	 *
	 * @return string
	 */
	public function get_title() {
		return 'پیام‌رسان بله (Bale)';
	}

	/**
	 * Delivery channel.
	 *
	 * @return string
	 */
	public function get_channel() {
		return 'bale';
	}

	/**
	 * Host checked by the background health probe.
	 *
	 * @return string
	 */
	public function get_probe_url() {
		return 'bot' === Ashna_Helper::get_option( 'bale_mode', 'safir' ) ? 'https://tapi.bale.ai/' : 'https://safir.bale.ai/';
	}

	/**
	 * Send OTP via Bale Messenger (Safir v3 or Bot API)
	 *
	 * @param string $recipient Normalized phone number.
	 * @param string $code      OTP code.
	 * @return true|WP_Error
	 */
	public function send( $recipient, $code ) {
		if ( 'bot' === Ashna_Helper::get_option( 'bale_mode', 'safir' ) ) {
			return $this->send_via_bot( $recipient, $code );
		}

		return $this->send_via_safir( $recipient, $code );
	}

	/**
	 * Send OTP using Safir v3 (single request, no token exchange).
	 *
	 * @param string $recipient Normalized phone number.
	 * @param string $code      OTP code.
	 * @return true|WP_Error
	 */
	private function send_via_safir( $recipient, $code ) {
		$api_key = trim( (string) Ashna_Helper::get_option( 'bale_api_key' ) );
		$bot_id  = absint( Ashna_Helper::get_option( 'bale_bot_id' ) );

		if ( empty( $api_key ) || empty( $bot_id ) ) {
			return new WP_Error( 'bale_safir_config', 'کلید دسترسی (api-access-key) یا شناسه عددی بازوی سفیر بله تنظیم نشده است.' );
		}

		$payload = array(
			// Idempotency key: Safir never delivers the same request_id twice.
			'request_id'   => wp_generate_uuid4(),
			'bot_id'       => $bot_id,
			'phone_number' => Ashna_Helper::to_international_phone( $recipient, false ), // 98912xxxxxxx
			'message_data' => array(
				'otp_message' => array(
					'otp' => (string) $code,
				),
			),
		);

		$response = $this->remote_post(
			self::SAFIR_URL,
			array(
				'headers' => array(
					'Content-Type'   => 'application/json',
					'api-access-key' => $api_key,
				),
				'body'    => wp_json_encode( $payload ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'bale_safir_http_error', 'خطای ارتباط با وب‌سرویس سفیر بله: ' . $response->get_error_message() );
		}

		$http_code = (int) wp_remote_retrieve_response_code( $response );
		$body      = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( $http_code >= 200 && $http_code < 300 && ! empty( $body['message_id'] ) && empty( $body['error_data'] ) ) {
			return true;
		}

		$error_msg = isset( $body['message'] ) ? (string) $body['message'] : 'خطا در ارسال کد از طریق سفیر بله (کد HTTP: ' . $http_code . ')';
		$type      = '';
		$error     = isset( $body['error_data'][0] ) ? $body['error_data'][0] : ( isset( $body['error'] ) && is_array( $body['error'] ) ? $body['error'] : null );
		if ( is_array( $error ) ) {
			if ( isset( $error['code'] ) ) {
				$type = self::safir_error_type( (int) $error['code'] );
			}
			if ( ! empty( $error['description'] ) ) {
				$error_msg = (string) $error['description'];
			}
		}

		return new WP_Error( 'bale_safir_api_error', $error_msg, $type ? array( 'ashna_error_type' => $type ) : null );
	}

	/**
	 * Failover type for documented Safir error codes (docs.bale.ai/safir).
	 *
	 * "Not a Bale user" stays a plain provider error: it falls back to SMS
	 * without sidelining Bale for everyone else.
	 *
	 * @param int $code ErrorInfo code.
	 * @return string Empty when the generic HTTP classification should apply.
	 */
	private static function safir_error_type( $code ) {
		$map = array(
			2  => 'server',  // InternalServerError.
			3  => 'server',  // RateLimitExceeded.
			4  => 'api',     // InvalidInput.
			8  => 'input',   // InvalidPhone.
			17 => 'api',     // NotBaleUser.
			20 => 'account', // PaymentRequired.
			21 => 'account', // MaximumContactLimitReached.
		);
		return isset( $map[ $code ] ) ? $map[ $code ] : '';
	}

	/**
	 * Send OTP via Bale Bot API (tapi.bale.ai)
	 *
	 * @param string $recipient Normalized phone number.
	 * @param string $code      OTP code.
	 * @return true|WP_Error
	 */
	private function send_via_bot( $recipient, $code ) {
		$bot_token = trim( (string) Ashna_Helper::get_option( 'bale_bot_token' ) );
		if ( empty( $bot_token ) ) {
			return new WP_Error( 'bale_bot_config', 'توکن ربات بله (Bot Token) در تنظیمات وارد نشده است.' );
		}

		// The bot can only message users who started it; their chat_id is stored on the profile.
		$chat_id = $this->resolve_bale_chat_id( $recipient );
		if ( empty( $chat_id ) ) {
			return new WP_Error( 'bale_no_chat_id', 'شناسه چت بله (Chat ID) برای این شماره یافت نشد.' );
		}

		$template = Ashna_Helper::get_option(
			'bale_message_template',
			"کد تایید ورود شما به {site_name}:\n*{code}*\nاین کد تا {expiry} ثانیه معتبر است."
		);

		$message = str_replace(
			array( '{code}', '{site_name}', '{expiry}' ),
			array( $code, get_bloginfo( 'name' ), Ashna_Helper::get_option( 'otp_expiry', 120 ) ),
			$template
		);

		$response = $this->remote_post(
			sprintf( 'https://tapi.bale.ai/bot%s/sendMessage', rawurlencode( $bot_token ) ),
			array(
				'headers' => array(
					'Content-Type' => 'application/json',
				),
				'body'    => wp_json_encode(
					array(
						'chat_id' => $chat_id,
						'text'    => $message,
					)
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'bale_bot_http_error', 'خطای ارتباط با ربات بله: ' . $response->get_error_message() );
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( ! empty( $body['ok'] ) ) {
			return true;
		}

		$err = isset( $body['description'] ) ? $body['description'] : 'خطا در ارسال پیام از طریق ربات بله';
		return new WP_Error( 'bale_bot_api_error', $err );
	}

	/**
	 * Resolve Bale chat_id for a phone number from user meta
	 *
	 * @param string $phone Normalized phone number.
	 * @return string
	 */
	private function resolve_bale_chat_id( $phone ) {
		$users = get_users(
			array(
				'meta_key'   => 'ashna_phone', // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_key -- single lookup when sending via the Bale bot.
				'meta_value' => $phone, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_value
				'number'     => 1,
				'fields'     => 'ID',
			)
		);

		if ( ! empty( $users ) ) {
			$chat_id = get_user_meta( $users[0], 'ashna_bale_chat_id', true );
			if ( ! empty( $chat_id ) ) {
				return $chat_id;
			}
		}

		return '';
	}
}


// ---- Source: includes/gateways/class-ashna-gateway-email.php ----
/**
 * Email OTP Gateway (WordPress wp_mail)
 *
 * @package Ashna
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Ashna_Gateway_Email extends Ashna_Abstract_Gateway {

	/**
	 * Get gateway ID
	 *
	 * @return string
	 */
	public function get_id() {
		return 'email';
	}

	/**
	 * Get gateway title
	 *
	 * @return string
	 */
	public function get_title() {
		return 'ایمیل (wp_mail)';
	}

	/**
	 * Delivery channel.
	 *
	 * @return string
	 */
	public function get_channel() {
		return 'email';
	}

	/**
	 * Send OTP via Email
	 *
	 * @param string $recipient Email address.
	 * @param string $code      OTP code.
	 * @return true|WP_Error
	 */
	public function send( $recipient, $code ) {
		if ( ! is_email( $recipient ) ) {
			return new WP_Error( 'email_invalid_recipient', 'آدرس ایمیل وارد شده معتبر نیست.' );
		}

		$site_name      = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
		$expiry_seconds = absint( Ashna_Helper::get_option( 'otp_expiry', 120 ) );
		$primary_color  = Ashna_Helper::get_option( 'primary_color', '#2563eb' );

		$raw_subject = Ashna_Helper::get_option( 'email_subject', 'کد تایید ورود به {site_name}' );
		$subject     = str_replace(
			array( '{site_name}', '{code}', '{expiry}' ),
			array( (string) $site_name, (string) $code, (string) $expiry_seconds ),
			$raw_subject
		);

		$heading   = Ashna_Helper::get_option( 'email_heading', 'کد یکبارمصرف ورود به حساب کاربری' );
		$raw_body  = Ashna_Helper::get_option( 'email_body_text', 'برای ورود به حساب کاربری خود در {site_name}، کد تایید زیر را در فرم ورود وارد نمایید:' );
		$body_text = str_replace(
			array( '{site_name}', '{code}', '{expiry}' ),
			array( (string) $site_name, (string) $code, (string) $expiry_seconds ),
			$raw_body
		);

		ob_start();
		include __DIR__ . '/../templates/email-otp.php';
		$html_message = ob_get_clean();

		$headers   = array( 'Content-Type: text/html; charset=UTF-8' );
		$from_name = trim( (string) Ashna_Helper::get_option( 'email_from_name', $site_name ) );
		$from_addr = trim( (string) Ashna_Helper::get_option( 'email_from_address', get_bloginfo( 'admin_email' ) ) );

		if ( ! empty( $from_name ) && is_email( $from_addr ) ) {
			$headers[] = sprintf( 'From: %s <%s>', $from_name, $from_addr );
		}

		$sent = wp_mail( $recipient, $subject, $html_message, $headers );

		if ( ! $sent ) {
			return new WP_Error( 'email_send_failed', 'خطا در ارسال ایمیل توسط تابع wp_mail وردپرس. لطفاً تنظیمات SMTP سرور را بررسی کنید.' );
		}

		return true;
	}
}


// ---- Source: includes/gateways/class-ashna-gateway-farazsms.php ----
/**
 * FarazSMS Gateway (Iran Payamak REST API: api.iranpayamak.com, pattern send)
 *
 * Current FarazSMS web service (docs.farazsms.com): Api-Key header, pattern
 * sends are instant and never queued, which suits OTP.
 *
 * @package Ashna
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Ashna_Gateway_Farazsms extends Ashna_Abstract_Gateway {

	/** Pattern (template) send endpoint. */
	const PATTERN_URL = 'https://api.iranpayamak.com/ws/v1/sms/pattern';

	/**
	 * Get gateway ID
	 *
	 * @return string
	 */
	public function get_id() {
		return 'farazsms';
	}

	/**
	 * Get gateway title
	 *
	 * @return string
	 */
	public function get_title() {
		return 'فراز اس‌ام‌اس (FarazSMS)';
	}

	/**
	 * Host checked by the background health probe.
	 *
	 * @return string
	 */
	public function get_probe_url() {
		return 'https://api.iranpayamak.com/';
	}

	/**
	 * Send OTP via the FarazSMS pattern web service
	 *
	 * @param string $recipient Normalized phone number.
	 * @param string $code      OTP code.
	 * @return true|WP_Error
	 */
	public function send( $recipient, $code ) {
		$api_key      = trim( (string) Ashna_Helper::get_option( 'farazsms_api_key' ) );
		$pattern_code = trim( (string) Ashna_Helper::get_option( 'farazsms_pattern_code' ) );
		$param_name   = trim( (string) Ashna_Helper::get_option( 'farazsms_param_name', 'code' ) );
		$line_number  = trim( (string) Ashna_Helper::get_option( 'farazsms_from_number', '' ) );

		if ( empty( $api_key ) || empty( $pattern_code ) ) {
			return new WP_Error( 'farazsms_config', 'کلید دسترسی (Api-Key) یا کد پترن فراز اس‌ام‌اس تنظیم نشده است.' );
		}

		$payload = array(
			'code'          => $pattern_code,
			'attributes'    => array(
				'' !== $param_name ? $param_name : 'code' => (string) $code,
			),
			'recipient'     => Ashna_Helper::normalize_phone( $recipient ),
			'number_format' => 'english',
		);
		if ( '' !== $line_number ) {
			$payload['line_number'] = $line_number;
		}

		$response = $this->remote_post(
			self::PATTERN_URL,
			array(
				'headers' => array(
					'Content-Type' => 'application/json',
					'Accept'       => 'application/json',
					'Api-Key'      => $api_key,
				),
				'body'    => wp_json_encode( $payload ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'farazsms_http_error', 'خطای ارتباط با فراز اس‌ام‌اس: ' . $response->get_error_message() );
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( isset( $body['status'] ) && 'success' === $body['status'] ) {
			return true;
		}

		$err = isset( $body['message'] ) && is_string( $body['message'] ) ? $body['message'] : 'خطا در ارسال پیامک پترن فراز اس‌ام‌اس (کد HTTP: ' . (int) wp_remote_retrieve_response_code( $response ) . ')';
		return new WP_Error( 'farazsms_api_error', $err );
	}
}


// ---- Source: includes/gateways/class-ashna-gateway-ippanel.php ----
/**
 * IPPanel SMS Gateway (Edge API v1: edge.ippanel.com)
 *
 * @package Ashna
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Ashna_Gateway_Ippanel extends Ashna_Abstract_Gateway {

	/** Edge send endpoint. */
	const SEND_URL = 'https://edge.ippanel.com/v1/api/send';

	/**
	 * Get gateway ID
	 *
	 * @return string
	 */
	public function get_id() {
		return 'ippanel';
	}

	/**
	 * Get gateway title
	 *
	 * @return string
	 */
	public function get_title() {
		return 'آی‌پی‌پنل (IPPanel)';
	}

	/**
	 * Host checked by the background health probe.
	 *
	 * @return string
	 */
	public function get_probe_url() {
		return 'https://edge.ippanel.com/';
	}

	/**
	 * Send OTP via the IPPanel Edge pattern API
	 *
	 * @param string $recipient Normalized phone number.
	 * @param string $code      OTP code.
	 * @return true|WP_Error
	 */
	public function send( $recipient, $code ) {
		$api_key      = trim( (string) Ashna_Helper::get_option( 'ippanel_api_key' ) );
		$from_number  = trim( (string) Ashna_Helper::get_option( 'ippanel_from_number', '+983000505' ) );
		$pattern_code = trim( (string) Ashna_Helper::get_option( 'ippanel_pattern_code' ) );
		$param_name   = trim( (string) Ashna_Helper::get_option( 'ippanel_param_name', 'code' ) );

		if ( empty( $api_key ) || empty( $pattern_code ) ) {
			return new WP_Error( 'ippanel_config', 'توکن دسترسی (API Key) یا کد پترن آی‌پی‌پنل تنظیم نشده است.' );
		}

		$payload = array(
			'sending_type' => 'pattern',
			'from_number'  => '' !== $from_number ? $from_number : '+983000505',
			'code'         => $pattern_code,
			'recipients'   => array( Ashna_Helper::to_international_phone( $recipient, true ) ),
			'params'       => array(
				'' !== $param_name ? $param_name : 'code' => (string) $code,
			),
		);

		$response = $this->remote_post(
			self::SEND_URL,
			array(
				'headers' => array(
					'Content-Type'  => 'application/json',
					'Authorization' => $api_key,
				),
				'body'    => wp_json_encode( $payload ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'ippanel_http_error', 'خطای ارتباط با آی‌پی‌پنل: ' . $response->get_error_message() );
		}

		$body      = json_decode( wp_remote_retrieve_body( $response ), true );
		$http_code = (int) wp_remote_retrieve_response_code( $response );

		if ( ( 200 === $http_code || 201 === $http_code ) && ! empty( $body['meta']['status'] ) ) {
			return true;
		}

		$err = isset( $body['meta']['message'] ) ? $body['meta']['message'] : 'خطا در ارسال پیامک از طریق آی‌پی‌پنل (کد HTTP: ' . $http_code . ')';
		return new WP_Error( 'ippanel_api_error', $err );
	}
}


// ---- Source: includes/gateways/class-ashna-gateway-kavenegar.php ----
/**
 * Kavenegar SMS Gateway (Verify Lookup API)
 *
 * @package Ashna
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Ashna_Gateway_Kavenegar extends Ashna_Abstract_Gateway {

	/**
	 * Get gateway ID
	 *
	 * @return string
	 */
	public function get_id() {
		return 'kavenegar';
	}

	/**
	 * Get gateway title
	 *
	 * @return string
	 */
	public function get_title() {
		return 'کاوه‌نگار (Kavenegar)';
	}

	/**
	 * Host checked by the background health probe.
	 *
	 * @return string
	 */
	public function get_probe_url() {
		return 'https://api.kavenegar.com/';
	}

	/**
	 * Send OTP via Kavenegar Verify Lookup API
	 *
	 * @param string $recipient Normalized phone number.
	 * @param string $code      OTP code.
	 * @return true|WP_Error
	 */
	public function send( $recipient, $code ) {
		$api_key  = trim( (string) Ashna_Helper::get_option( 'kavenegar_api_key' ) );
		$template = trim( (string) Ashna_Helper::get_option( 'kavenegar_template' ) );

		if ( empty( $api_key ) || empty( $template ) ) {
			return new WP_Error( 'kavenegar_config', 'کلید API یا نام الگوی اعتبارسنجی (Template) کاوه‌نگار تنظیم نشده است.' );
		}

		$url = sprintf( 'https://api.kavenegar.com/v1/%s/verify/lookup.json', rawurlencode( $api_key ) );

		$response = $this->remote_post(
			$url,
			array(
				'body'    => array(
					'receptor' => Ashna_Helper::normalize_phone( $recipient ),
					'template' => $template,
					'token'    => (string) $code,
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'kavenegar_http_error', 'خطای ارتباط با کاوه‌نگار: ' . $response->get_error_message() );
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( isset( $body['return']['status'] ) && 200 === (int) $body['return']['status'] ) {
			return true;
		}

		$error_msg = isset( $body['return']['message'] ) ? $body['return']['message'] : 'خطای نامشخص از وب‌سرویس کاوه‌نگار';
		$status    = isset( $body['return']['status'] ) ? (int) $body['return']['status'] : 0;
		$type      = self::error_type( $status );

		return new WP_Error( 'kavenegar_api_error', $error_msg, $type ? array( 'ashna_error_type' => $type ) : null );
	}

	/**
	 * Failover type for documented Kavenegar status codes.
	 *
	 * @param int $status Value of return.status.
	 * @return string Empty when the generic HTTP classification should apply.
	 */
	private static function error_type( $status ) {
		$map = array(
			411 => 'input',   // Invalid receptor.
			401 => 'account', // Account disabled.
			416 => 'account', // Server IP not allowed.
			418 => 'account', // Insufficient credit.
			501 => 'account', // Demo account: owner's number only.
			409 => 'server',  // Server busy, retry later.
			451 => 'server',  // Too many calls in a short time.
		);
		return isset( $map[ $status ] ) ? $map[ $status ] : '';
	}
}


// ---- Source: includes/gateways/class-ashna-gateway-manager.php ----
/**
 * Gateway Manager, Fast Failover Engine & Multi-Channel Dispatcher
 *
 * @package Ashna
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Ashna_Gateway_Manager {

	/**
	 * Custom registered SMS gateways
	 *
	 * @var array<string, Ashna_Gateway_Interface>
	 */
	private static $custom_gateways = array();

	/**
	 * Register a custom SMS gateway driver programmatically
	 *
	 * @param Ashna_Gateway_Interface $gateway Gateway instance.
	 */
	public static function register_gateway( Ashna_Gateway_Interface $gateway ) {
		self::$custom_gateways[ $gateway->get_id() ] = $gateway;
	}

	/**
	 * Get all available SMS gateways
	 *
	 * @return array<string, Ashna_Gateway_Interface>
	 */
	public static function get_sms_gateways() {
		$gateways = array_merge(
			array(
				'sandbox'     => new Ashna_Gateway_Sandbox(),
				'smsir'       => new Ashna_Gateway_Smsir(),
				'kavenegar'   => new Ashna_Gateway_Kavenegar(),
				'melipayamak' => new Ashna_Gateway_Melipayamak(),
				'farazsms'    => new Ashna_Gateway_Farazsms(),
				'ippanel'     => new Ashna_Gateway_Ippanel(),
				'msgway'      => new Ashna_Gateway_Msgway(),
			),
			self::$custom_gateways
		);

		return apply_filters( 'ashna_otp_sms_gateways', $gateways );
	}

	/**
	 * Get active SMS gateway instance
	 *
	 * @return Ashna_Gateway_Interface
	 */
	public static function get_active_sms_gateway() {
		$gateways  = self::get_sms_gateways();
		$active_id = Ashna_Helper::get_option( 'active_sms_gateway', 'sandbox' );

		if ( isset( $gateways[ $active_id ] ) ) {
			return $gateways[ $active_id ];
		}

		return $gateways['sandbox'];
	}

	/**
	 * Get ordered list of configured backup SMS gateway instances (up to 3 priorities)
	 *
	 * @return array<int, Ashna_Gateway_Interface>
	 */
	public static function get_backup_sms_gateways() {
		$gateways  = self::get_sms_gateways();
		$active_id = Ashna_Helper::get_option( 'active_sms_gateway', 'sandbox' );

		$b1 = Ashna_Helper::get_option( 'backup_sms_gateway_1', Ashna_Helper::get_option( 'backup_sms_gateway', 'none' ) );
		$b2 = Ashna_Helper::get_option( 'backup_sms_gateway_2', 'none' );
		$b3 = Ashna_Helper::get_option( 'backup_sms_gateway_3', 'none' );

		$candidates = array( $b1, $b2, $b3 );
		$backups    = array();
		$seen       = array( $active_id => true );

		foreach ( $candidates as $gw_id ) {
			if ( ! empty( $gw_id ) && 'none' !== $gw_id && empty( $seen[ $gw_id ] ) && isset( $gateways[ $gw_id ] ) ) {
				$backups[]      = $gateways[ $gw_id ];
				$seen[ $gw_id ] = true;
			}
		}

		return $backups;
	}

	/**
	 * Ordered SMS chain: the primary gateway followed by up to three backups.
	 *
	 * @return array<int, Ashna_Gateway_Interface>
	 */
	public static function get_sms_chain() {
		return array_merge( array( self::get_active_sms_gateway() ), self::get_backup_sms_gateways() );
	}

	/**
	 * Whether a mobile OTP can fall back to another gateway or channel.
	 *
	 * @return bool
	 */
	public static function has_fallback() {
		$strategy = Ashna_Helper::get_option( 'mobile_delivery_channel', 'sms' );
		if ( in_array( $strategy, array( 'bale_fallback_sms', 'sms_fallback_bale', 'both', 'messenger_fallback_sms' ), true ) ) {
			return true;
		}
		return ! in_array( $strategy, array( 'bale', 'messenger' ), true ) && count( self::get_backup_sms_gateways() ) > 0;
	}

	/**
	 * Delivery channel a gateway belongs to.
	 *
	 * @param Ashna_Gateway_Interface $gateway Gateway.
	 * @return string sms | bale | messenger | email
	 */
	public static function channel_of( $gateway ) {
		return method_exists( $gateway, 'get_channel' ) ? (string) $gateway->get_channel() : 'sms';
	}

	/**
	 * Gateways on the configured delivery path, for the background probe.
	 *
	 * @return array<int, Ashna_Gateway_Interface>
	 */
	public static function probe_targets() {
		$strategy = Ashna_Helper::get_option( 'mobile_delivery_channel', 'sms' );
		$targets  = array();
		if ( ! in_array( $strategy, array( 'bale', 'messenger' ), true ) ) {
			$targets = self::get_sms_chain();
		}
		if ( in_array( $strategy, array( 'bale', 'bale_fallback_sms', 'sms_fallback_bale', 'both' ), true ) ) {
			$targets[] = new Ashna_Gateway_Bale();
		}
		if ( in_array( $strategy, array( 'messenger', 'messenger_fallback_sms' ), true ) ) {
			$targets[] = new Ashna_Gateway_Msgway_Messenger();
		}

		$unique = array();
		foreach ( $targets as $gateway ) {
			if ( 'sandbox' !== $gateway->get_id() ) {
				$unique[ $gateway->get_id() ] = $gateway;
			}
		}
		return array_values( $unique );
	}

	/**
	 * First gateway a visitor's OTP goes to (used for the form's timing hints).
	 *
	 * @return Ashna_Gateway_Interface
	 */
	public static function first_mobile_gateway() {
		$strategy = Ashna_Helper::get_option( 'mobile_delivery_channel', 'sms' );
		if ( in_array( $strategy, array( 'bale', 'bale_fallback_sms' ), true ) ) {
			return new Ashna_Gateway_Bale();
		}
		if ( in_array( $strategy, array( 'messenger', 'messenger_fallback_sms' ), true ) ) {
			return new Ashna_Gateway_Msgway_Messenger();
		}
		return self::get_active_sms_gateway();
	}

	/**
	 * Try gateways in order until one delivers (the fast-failover engine).
	 *
	 * - Every attempt has a short time slot and the whole dispatch shares one
	 *   budget (Ashna_Failover), so a hung provider cannot stall the visitor.
	 * - Gateways whose circuit is open are skipped while a healthy alternative
	 *   exists, and only tried as a last resort with a short time slot.
	 * - After a cooldown, one quick trial decides whether a gateway is back.
	 *
	 * @param array<int, Ashna_Gateway_Interface> $gateways  Ordered gateways.
	 * @param string                              $recipient Recipient.
	 * @param string                              $code      OTP code.
	 * @param bool                                $force     Ignore circuit state (admin tests).
	 * @return array{result: true|WP_Error, gateway: Ashna_Gateway_Interface|null, attempted: Ashna_Gateway_Interface|null, steps: array}
	 */
	public static function send_via_chain( array $gateways, $recipient, $code, $force = false ) {
		$queue    = array();
		$deferred = array();
		$steps    = array();

		foreach ( $gateways as $gateway ) {
			$state = $force ? 'closed' : Ashna_Failover::state( $gateway->get_id() );
			if ( 'open' === $state ) {
				$deferred[] = array( $gateway, 'last_resort' );
			} else {
				$queue[] = array( $gateway, $state );
			}
		}
		$queue = array_merge( $queue, $deferred );

		$last_error = null;
		$attempted  = null;
		$tried      = array(); // Gateway IDs actually called.
		$blocked    = array(); // Channels whose recipient was rejected.

		foreach ( $queue as $position => $item ) {
			list( $gateway, $state ) = $item;
			$id                      = $gateway->get_id();
			$channel                 = self::channel_of( $gateway );

			if ( isset( $blocked[ $channel ] ) ) {
				$steps[] = array(
					'id'      => $id,
					'title'   => $gateway->get_title(),
					'outcome' => 'skip',
					'type'    => 'input',
				);
				continue;
			}

			if ( ! Ashna_Failover::has_time_for_attempt() ) {
				foreach ( array_slice( $queue, $position ) as $left ) {
					$steps[] = array(
						'id'      => $left[0]->get_id(),
						'title'   => $left[0]->get_title(),
						'outcome' => 'budget',
					);
				}
				if ( null === $last_error ) {
					$last_error = new WP_Error( 'ashna_time_exhausted', 'مهلت ارسال کد به پایان رسید؛ لطفاً دوباره تلاش کنید.' );
				}
				break;
			}

			$slot = Ashna_Failover::slot_for( $id );
			if ( 'trial' === $state ) {
				Ashna_Failover::claim_trial( $id );
				$slot = min( $slot, Ashna_Failover::TRIAL_TIMEOUT );
			} elseif ( 'last_resort' === $state ) {
				$slot = min( $slot, Ashna_Failover::TRIAL_TIMEOUT );
			}

			Ashna_Failover::start_attempt( $slot );
			Ashna_Abstract_Gateway::reset_trace();
			$started = microtime( true );
			try {
				$result = $gateway->send( $recipient, $code );
			} catch ( Throwable $e ) {
				$result = new WP_Error( 'ashna_gateway_exception', 'خطای داخلی درگاه: ' . $e->getMessage() );
			}
			$ms = (int) round( ( microtime( true ) - $started ) * 1000 );
			Ashna_Failover::end_attempt();
			$attempted    = $gateway;
			$tried[ $id ] = true;

			if ( ! is_wp_error( $result ) ) {
				Ashna_Failover::record_success( $id, $ms );
				$steps[] = array(
					'id'      => $id,
					'title'   => $gateway->get_title(),
					'outcome' => 'ok',
					'ms'      => $ms,
				);
				return array(
					'result'    => true,
					'gateway'   => $gateway,
					'attempted' => $gateway,
					'steps'     => array_merge( self::skipped_steps( $deferred, $tried ), $steps ),
				);
			}

			$trace  = $gateway instanceof Ashna_Abstract_Gateway ? Ashna_Abstract_Gateway::get_trace() : null;
			$type   = Ashna_Failover::classify( $result, $trace );
			$opened = 'budget' !== $type && Ashna_Failover::record_failure( $id, $type, $result->get_error_message(), $ms );

			$steps[] = array(
				'id'      => $id,
				'title'   => $gateway->get_title(),
				'outcome' => 'fail',
				'type'    => $type,
				'ms'      => $ms,
				'message' => $result->get_error_message(),
			);

			/**
			 * Fires after a gateway attempt fails.
			 *
			 * @param string   $id     Gateway ID.
			 * @param string   $type   Error type (see Ashna_Failover::classify()).
			 * @param WP_Error $result Gateway error.
			 * @param int      $ms     Attempt duration in milliseconds.
			 * @param bool     $opened Whether the gateway is now sidelined.
			 */
			do_action( 'ashna_otp_gateway_failure', $id, $type, $result, $ms, $opened );

			$last_error = $result;
			if ( 'input' === $type ) {
				$blocked[ $channel ] = true;
			}
		}

		return array(
			'result'    => $last_error ? $last_error : new WP_Error( 'ashna_no_gateway', 'هیچ درگاهی برای ارسال کد در دسترس نیست.' ),
			'gateway'   => null,
			'attempted' => $attempted,
			'steps'     => array_merge( self::skipped_steps( $deferred, $tried ), $steps ),
		);
	}

	/**
	 * Trace entries for sidelined gateways that were never called.
	 *
	 * @param array $deferred Deferred queue items.
	 * @param array $tried    IDs of gateways that were called.
	 * @return array
	 */
	private static function skipped_steps( $deferred, $tried ) {
		$steps = array();
		foreach ( $deferred as $item ) {
			$id = $item[0]->get_id();
			if ( empty( $tried[ $id ] ) ) {
				$steps[] = array(
					'id'      => $id,
					'title'   => $item[0]->get_title(),
					'outcome' => 'skip',
					'type'    => 'circuit',
				);
			}
		}
		return $steps;
	}

	/**
	 * Send SMS via the primary gateway with the fast failover chain.
	 *
	 * @param string $recipient         Normalized phone.
	 * @param string $code              OTP code.
	 * @param string $forced_gateway_id Optional specific gateway ID to test (bypasses the circuit breaker).
	 * @param bool   $force             Ignore circuit state (admin tests).
	 * @return array { result: true|WP_Error, gateway_id: string, message: string, steps: array }
	 */
	public static function send_sms_with_failover( $recipient, $code, $forced_gateway_id = '', $force = false ) {
		$gateways = self::get_sms_gateways();
		if ( ! empty( $forced_gateway_id ) && isset( $gateways[ $forced_gateway_id ] ) ) {
			$chain = array( $gateways[ $forced_gateway_id ] );
			$force = true;
		} else {
			$chain = self::get_sms_chain();
		}

		$run = self::send_via_chain( $chain, $recipient, $code, $force );
		$gw  = $run['gateway'] ? $run['gateway'] : ( $run['attempted'] ? $run['attempted'] : $chain[0] );

		return array(
			'result'     => $run['result'],
			'gateway_id' => $gw->get_id(),
			'message'    => self::summarize( $run, $chain ),
			'steps'      => $run['steps'],
		);
	}

	/**
	 * Short human message for a chain run.
	 *
	 * @param array $run   Result of send_via_chain().
	 * @param array $chain Gateways in configured order.
	 * @return string
	 */
	private static function summarize( $run, $chain ) {
		if ( is_wp_error( $run['result'] ) ) {
			return $run['result']->get_error_message();
		}

		$gateway  = $run['gateway'];
		$position = array_search( $gateway, $chain, true );
		if ( 'bale' === $gateway->get_id() ) {
			return 'ارسال موفق از طریق پیام‌رسان بله';
		}
		if ( 'messenger' === self::channel_of( $gateway ) ) {
			return 'ارسال موفق از طریق ' . $gateway->get_title();
		}
		if ( 0 === $position || false === $position ) {
			return 'ارسال موفق از طریق ' . $gateway->get_title();
		}

		$labels = array( 1 => 'اول', 2 => 'دوم', 3 => 'سوم' );
		$label  = isset( $labels[ $position ] ) ? $labels[ $position ] : (string) $position;
		return sprintf( 'ارسال از طریق پشتیبان %s: %s', $label, $gateway->get_title() );
	}

	/**
	 * Deliver an OTP according to the configured strategy, within the failover budget.
	 *
	 * @param string $recipient         Normalized phone or email.
	 * @param string $code              OTP code.
	 * @param string $identifier_type   'phone' or 'email'.
	 * @param string $forced_channel    Forced channel ('sms', 'bale', 'email').
	 * @param string $forced_gateway_id Forced SMS gateway ID.
	 * @return array{result: true|WP_Error, channel: string, gateway: string, message: string, steps: array}
	 */
	private static function deliver( $recipient, $code, $identifier_type, $forced_channel, $forced_gateway_id ) {
		// Admin tests always reach the requested gateway, even while it is sidelined.
		$force = '' !== (string) $forced_channel || '' !== (string) $forced_gateway_id;

		if ( 'email' === $identifier_type || 'email' === $forced_channel ) {
			$run = self::send_via_chain( array( new Ashna_Gateway_Email() ), $recipient, $code, true );
			return array(
				'result'  => $run['result'],
				'channel' => 'email',
				'gateway' => 'email',
				'message' => is_wp_error( $run['result'] ) ? $run['result']->get_error_message() : 'ارسال موفق به ایمیل',
				'steps'   => $run['steps'],
			);
		}

		$strategy = ! empty( $forced_channel ) ? $forced_channel : Ashna_Helper::get_option( 'mobile_delivery_channel', 'sms' );
		$gateways = self::get_sms_gateways();
		$sms      = ( ! empty( $forced_gateway_id ) && isset( $gateways[ $forced_gateway_id ] ) )
			? array( $gateways[ $forced_gateway_id ] )
			: self::get_sms_chain();
		$bale     = new Ashna_Gateway_Bale();

		if ( 'both' === $strategy ) {
			return self::deliver_both( $sms, $bale, $recipient, $code, $force );
		}

		$messenger = new Ashna_Gateway_Msgway_Messenger();

		switch ( $strategy ) {
			case 'bale':
				$chain = array( $bale );
				break;
			case 'bale_fallback_sms':
				$chain = array_merge( array( $bale ), $sms );
				break;
			case 'sms_fallback_bale':
				$chain = array_merge( $sms, array( $bale ) );
				break;
			case 'messenger':
				$chain = array( $messenger );
				break;
			case 'messenger_fallback_sms':
				$chain = array_merge( array( $messenger ), $sms );
				break;
			case 'sms':
			default:
				$chain = $sms;
				break;
		}

		$run     = self::send_via_chain( $chain, $recipient, $code, $force );
		$gateway = $run['gateway'] ? $run['gateway'] : ( $run['attempted'] ? $run['attempted'] : $chain[0] );
		$channel = self::channel_of( $gateway );
		$first   = self::channel_of( $chain[0] );

		if ( is_wp_error( $run['result'] ) ) {
			$message = $run['result']->get_error_message();
		} elseif ( 'bale' === $channel ) {
			$message = 'bale' === $first ? 'ارسال موفق از طریق پیام‌رسان بله' : 'ارسال از طریق بله پس از عدم موفقیت پیامک';
		} elseif ( 'messenger' === $channel ) {
			$message = 'ارسال موفق از طریق ' . $gateway->get_title();
		} elseif ( 'sms' !== $first ) {
			$message = sprintf(
				'ارسال از طریق پیامک با %s، پس از عدم موفقیت %s',
				$gateway->get_title(),
				'bale' === $first ? 'بله' : 'پیام‌رسان‌های ایرانی'
			);
		} else {
			$message = self::summarize( $run, $sms );
		}

		return array(
			'result'  => $run['result'],
			'channel' => $channel,
			'gateway' => $gateway->get_id(),
			'message' => $message,
			'steps'   => $run['steps'],
		);
	}

	/**
	 * "Both" strategy: SMS chain and Bale. Succeeds when either delivers.
	 *
	 * @param array                   $sms       SMS chain.
	 * @param Ashna_Gateway_Interface $bale      Bale gateway.
	 * @param string                  $recipient Recipient.
	 * @param string                  $code      OTP code.
	 * @param bool                    $force     Ignore circuit state.
	 * @return array
	 */
	private static function deliver_both( $sms, $bale, $recipient, $code, $force ) {
		$sms_run = self::send_via_chain( $sms, $recipient, $code, $force );
		$sms_ok  = ! is_wp_error( $sms_run['result'] );

		// SMS already delivered: a sidelined Bale is skipped instead of delaying the visitor.
		if ( $sms_ok && ! $force && 'open' === Ashna_Failover::state( $bale->get_id() ) ) {
			$bale_run = array(
				'result' => new WP_Error( 'ashna_skipped', 'skipped' ),
				'steps'  => array(
					array(
						'id'      => $bale->get_id(),
						'title'   => $bale->get_title(),
						'outcome' => 'skip',
						'type'    => 'circuit',
					),
				),
			);
		} else {
			$bale_run = self::send_via_chain( array( $bale ), $recipient, $code, $force );
		}
		$bale_ok = ! is_wp_error( $bale_run['result'] );

		$sms_gw = $sms_run['gateway'] ? $sms_run['gateway'] : ( $sms_run['attempted'] ? $sms_run['attempted'] : $sms[0] );
		$steps  = array_merge( $sms_run['steps'], $bale_run['steps'] );

		if ( $sms_ok && $bale_ok ) {
			return array(
				'result'  => true,
				'channel' => 'sms+bale',
				'gateway' => $sms_gw->get_id() . '+bale',
				'message' => 'ارسال همزمان پیامک و بله',
				'steps'   => $steps,
			);
		}
		if ( $sms_ok || $bale_ok ) {
			return array(
				'result'  => true,
				'channel' => $sms_ok ? 'sms' : 'bale',
				'gateway' => $sms_ok ? $sms_gw->get_id() : 'bale',
				'message' => $sms_ok ? self::summarize( $sms_run, $sms ) : 'ارسال موفق از طریق پیام‌رسان بله',
				'steps'   => $steps,
			);
		}
		return array(
			'result'  => $sms_run['result'],
			'channel' => 'sms+bale',
			'gateway' => $sms_gw->get_id() . '+bale',
			'message' => $sms_run['result']->get_error_message(),
			'steps'   => $steps,
		);
	}

	/**
	 * Dispatch OTP code to recipient and log result
	 *
	 * @param string $recipient         Normalized phone or email.
	 * @param string $identifier_type   'phone' or 'email'.
	 * @param string $forced_channel    Optional forced channel ('sms', 'bale', 'email').
	 * @param string $forced_gateway_id Optional forced SMS gateway ID for testing.
	 * @param int    $reservation_id    Log row reserved by Ashna_Rate_Limiter::reserve() (0 = none, e.g. admin tests).
	 * @return array|WP_Error { code, channel, gateway, log_id, response, elapsed_ms, trace }
	 */
	public static function dispatch_otp( $recipient, $identifier_type = 'phone', $forced_channel = '', $forced_gateway_id = '', $reservation_id = 0 ) {
		$length   = absint( Ashna_Helper::get_option( 'otp_length', 5 ) );
		$code     = Ashna_Helper::generate_otp_code( $length );
		$otp_hash = wp_hash_password( $code );

		$started = microtime( true );
		Ashna_Failover::begin();
		try {
			$outcome = self::deliver( $recipient, $code, $identifier_type, (string) $forced_channel, (string) $forced_gateway_id );
		} finally {
			Ashna_Failover::end();
		}
		$elapsed_ms = (int) round( ( microtime( true ) - $started ) * 1000 );

		$send_result  = $outcome['result'];
		$is_error     = is_wp_error( $send_result );
		$response_msg = $is_error ? $send_result->get_error_message() : $outcome['message'];
		$trace        = Ashna_Failover::describe( $outcome['steps'] );

		$log_data = array(
			'recipient'        => $recipient,
			'channel'          => $outcome['channel'],
			'gateway'          => $outcome['gateway'],
			// Only the hash is needed to verify; the readable code is kept for the test gateway only.
			'otp_code'         => 'sandbox' === $outcome['gateway'] ? $code : str_repeat( '•', strlen( $code ) ),
			'otp_hash'         => $otp_hash,
			'status'           => $is_error ? 'failed' : 'sent',
			'response_message' => '' !== $trace ? $response_msg . ' | مسیر: ' . $trace : $response_msg,
		);
		if ( $reservation_id > 0 ) {
			Ashna_Logger::complete( $reservation_id, $log_data );
			$log_id = (int) $reservation_id;
		} else {
			$log_id = Ashna_Logger::insert( $log_data );
		}

		if ( $is_error ) {
			return $send_result;
		}

		do_action( 'ashna_otp_sent', $recipient, $code, $outcome['channel'], $outcome['gateway'], $log_id );

		return array(
			'code'       => $code,
			'channel'    => $outcome['channel'],
			'gateway'    => $outcome['gateway'],
			'log_id'     => $log_id,
			'response'   => $response_msg,
			'elapsed_ms' => $elapsed_ms,
			'trace'      => $trace,
		);
	}
}


// ---- Source: includes/gateways/class-ashna-gateway-melipayamak.php ----
/**
 * Melipayamak SMS Gateway (Console API: shared service line / pattern)
 *
 * Primary: console.melipayamak.com API key (the key travels in the URL, no
 * password is sent). Settings that only have the old username/password still
 * work through the legacy REST endpoint.
 *
 * @package Ashna
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Ashna_Gateway_Melipayamak extends Ashna_Abstract_Gateway {

	/**
	 * Get gateway ID
	 *
	 * @return string
	 */
	public function get_id() {
		return 'melipayamak';
	}

	/**
	 * Get gateway title
	 *
	 * @return string
	 */
	public function get_title() {
		return 'ملی‌پیامک (Melipayamak)';
	}

	/**
	 * Host checked by the background health probe.
	 *
	 * @return string
	 */
	public function get_probe_url() {
		return '' !== trim( (string) Ashna_Helper::get_option( 'melipayamak_api_key' ) ) ? 'https://console.melipayamak.com/' : 'https://rest.payamak-panel.com/';
	}

	/**
	 * Send OTP via Melipayamak (console API, or legacy REST for old settings)
	 *
	 * @param string $recipient Normalized phone number.
	 * @param string $code      OTP code.
	 * @return true|WP_Error
	 */
	public function send( $recipient, $code ) {
		$api_key = trim( (string) Ashna_Helper::get_option( 'melipayamak_api_key' ) );
		$body_id = absint( Ashna_Helper::get_option( 'melipayamak_body_id' ) );

		if ( empty( $body_id ) ) {
			return new WP_Error( 'melipayamak_config', 'کد متن خدماتی یا پترن (bodyId) ملی‌پیامک تنظیم نشده است.' );
		}

		if ( '' !== $api_key ) {
			return $this->send_via_console( $api_key, $body_id, $recipient, $code );
		}

		$username = trim( (string) Ashna_Helper::get_option( 'melipayamak_username' ) );
		$password = trim( (string) Ashna_Helper::get_option( 'melipayamak_password' ) );
		if ( '' !== $username && '' !== $password ) {
			return $this->send_via_legacy_rest( $username, $password, $body_id, $recipient, $code );
		}

		return new WP_Error( 'melipayamak_config', 'کلید API کنسول ملی‌پیامک تنظیم نشده است.' );
	}

	/**
	 * Console API: POST /api/send/shared/{key} with { bodyId, to, args }.
	 *
	 * @param string $api_key   Console API key.
	 * @param int    $body_id   Approved pattern ID.
	 * @param string $recipient Phone.
	 * @param string $code      OTP code.
	 * @return true|WP_Error
	 */
	private function send_via_console( $api_key, $body_id, $recipient, $code ) {
		$response = $this->remote_post(
			'https://console.melipayamak.com/api/send/shared/' . rawurlencode( $api_key ),
			array(
				'headers' => array(
					'Content-Type' => 'application/json',
					'Accept'       => 'application/json',
				),
				'body'    => wp_json_encode(
					array(
						'bodyId' => $body_id,
						'to'     => Ashna_Helper::normalize_phone( $recipient ),
						'args'   => array( (string) $code ),
					)
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'melipayamak_http_error', 'خطای ارتباط با ملی‌پیامک: ' . $response->get_error_message() );
		}

		$body   = json_decode( wp_remote_retrieve_body( $response ), true );
		$rec_id = isset( $body['recId'] ) ? $body['recId'] : 0;
		if ( is_numeric( $rec_id ) && (float) $rec_id > 0 ) {
			return true;
		}

		$err = isset( $body['status'] ) && is_string( $body['status'] ) && '' !== $body['status']
			? $body['status']
			: 'خطای وب‌سرویس ملی‌پیامک (کد HTTP: ' . (int) wp_remote_retrieve_response_code( $response ) . ')';
		return new WP_Error( 'melipayamak_api_error', $err );
	}

	/**
	 * Legacy REST (rest.payamak-panel.com BaseServiceNumber) for old settings.
	 *
	 * @param string $username  Panel username.
	 * @param string $password  Panel password or API key.
	 * @param int    $body_id   Approved pattern ID.
	 * @param string $recipient Phone.
	 * @param string $code      OTP code.
	 * @return true|WP_Error
	 */
	private function send_via_legacy_rest( $username, $password, $body_id, $recipient, $code ) {
		$response = $this->remote_post(
			'https://rest.payamak-panel.com/api/SendSMS/BaseServiceNumber',
			array(
				'headers' => array(
					'Content-Type' => 'application/json',
				),
				'body'    => wp_json_encode(
					array(
						'username' => $username,
						'password' => $password,
						'text'     => (string) $code,
						'to'       => Ashna_Helper::normalize_phone( $recipient ),
						'bodyId'   => $body_id,
					)
				),
			)
		);

		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'melipayamak_http_error', 'خطای ارتباط با ملی‌پیامک: ' . $response->get_error_message() );
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( isset( $body['RetStatus'] ) && 1 === (int) $body['RetStatus'] ) {
			return true;
		}

		$error_msg = isset( $body['StrRetStatus'] ) ? $body['StrRetStatus'] : 'خطای وب‌سرویس ملی‌پیامک (کد: ' . ( isset( $body['Value'] ) ? $body['Value'] : 'نامشخص' ) . ')';
		return new WP_Error( 'melipayamak_api_error', $error_msg );
	}
}


// ---- Source: includes/gateways/class-ashna-gateway-sandbox.php ----
/**
 * Sandbox / Test Gateway (For local testing without SMS credits)
 *
 * @package Ashna
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Ashna_Gateway_Sandbox extends Ashna_Abstract_Gateway {

	/**
	 * Get gateway ID
	 *
	 * @return string
	 */
	public function get_id() {
		return 'sandbox';
	}

	/**
	 * Get gateway title
	 *
	 * @return string
	 */
	public function get_title() {
		return 'حالت تست / آزمایشی (ثبت در لاگ)';
	}

	/**
	 * Simulate sending OTP
	 *
	 * @param string $recipient Recipient phone.
	 * @param string $code      OTP code.
	 * @return true|WP_Error
	 */
	public function send( $recipient, $code ) {
		return true;
	}
}


// ---- Source: includes/gateways/class-ashna-gateway-smsir.php ----
/**
 * SMS.ir Gateway (REST API v1 - Verify / UltraFastSend)
 *
 * @package Ashna
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Ashna_Gateway_Smsir extends Ashna_Abstract_Gateway {

	/**
	 * Get gateway ID
	 *
	 * @return string
	 */
	public function get_id() {
		return 'smsir';
	}

	/**
	 * Get gateway title
	 *
	 * @return string
	 */
	public function get_title() {
		return 'اس‌ام‌اس دات آی‌آر (SMS.ir)';
	}

	/**
	 * Host checked by the background health probe.
	 *
	 * @return string
	 */
	public function get_probe_url() {
		return 'https://api.sms.ir/';
	}

	/**
	 * Send OTP via SMS.ir Verify API v1
	 *
	 * @param string $recipient Normalized phone number.
	 * @param string $code      OTP code.
	 * @return true|WP_Error
	 */
	public function send( $recipient, $code ) {
		$api_key     = trim( (string) Ashna_Helper::get_option( 'smsir_api_key' ) );
		$template_id = absint( Ashna_Helper::get_option( 'smsir_template_id' ) );
		$param_name  = trim( (string) Ashna_Helper::get_option( 'smsir_param_name', 'CODE' ) );

		if ( empty( $api_key ) || empty( $template_id ) ) {
			return new WP_Error( 'smsir_config', 'کلید وب‌سرویس (API Key) یا شناسه قالب (Template ID) درگاه SMS.ir تنظیم نشده است.' );
		}

		if ( empty( $param_name ) ) {
			$param_name = 'CODE';
		}

		$payload = array(
			'mobile'     => Ashna_Helper::normalize_phone( $recipient ),
			'templateId' => $template_id,
			'parameters' => array(
				array(
					'name'  => $param_name,
					'value' => (string) $code,
				),
			),
		);

		$response = $this->remote_post(
			'https://api.sms.ir/v1/send/verify',
			array(
				'headers' => array(
					'Content-Type' => 'application/json',
					'Accept'       => 'application/json',
					'x-api-key'    => $api_key,
				),
				'body'    => wp_json_encode( $payload ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'smsir_http_error', 'خطای ارتباط با SMS.ir: ' . $response->get_error_message() );
		}

		$body = json_decode( wp_remote_retrieve_body( $response ), true );
		$code_http = wp_remote_retrieve_response_code( $response );

		if ( 200 === $code_http && isset( $body['status'] ) && 1 === (int) $body['status'] ) {
			return true;
		}

		$error_msg = isset( $body['message'] ) ? $body['message'] : 'خطای نامشخص از وب‌سرویس SMS.ir (کد HTTP: ' . $code_http . ')';
		return new WP_Error( 'smsir_api_error', $error_msg );
	}
}


// ---- Source: includes/gateways/class-ashna-failover.php ----
/**
 * Fast Failover Policy: per-call timeouts, a total time budget, a circuit
 * breaker that sidelines failing gateways, error classification and health stats.
 *
 * Why: a gateway that hangs used to block the visitor for 15 seconds per HTTP
 * call (up to a minute across the chain). Now the first visitor waits at most
 * one short timeout, and later visitors skip the failing gateway entirely.
 *
 * @package Ashna
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class Ashna_Failover {

	/** Option holding per-gateway health (not autoloaded). */
	const OPTION = 'ashna_otp_gateway_health';

	/** Longest cooldown after repeated failures, in seconds. */
	const MAX_COOLDOWN = 1800;

	/** Time limit for the trial call after a cooldown, and for last-resort calls. */
	const TRIAL_TIMEOUT = 3.0;

	/** Limit for the connect phase (DNS + TCP + TLS) of each call. */
	const CONNECT_TIMEOUT = 3.0;

	/** A new gateway attempt needs at least this much of the budget left. */
	const MIN_ATTEMPT = 1.0;

	/** Learned time slot: successes needed before a gateway's own speed is used. */
	const ADAPTIVE_MIN_SAMPLES = 5;

	/** Learned time slot: multiple of the gateway's average response time. */
	const ADAPTIVE_FACTOR = 4;

	/** Learned time slot never drops below this (seconds). */
	const ADAPTIVE_FLOOR = 2.0;

	/** WP-Cron hook of the background health probe. */
	const PROBE_HOOK = 'ashna_otp_gateway_probe';

	/** Probe interval in seconds. */
	const PROBE_INTERVAL = 300;

	/**
	 * Error types that mean the gateway itself is down or unusable. Only these
	 * sideline a gateway; recipient-specific errors (e.g. "no Bale account")
	 * must never take a healthy gateway out of service for everyone.
	 *
	 * @var string[]
	 */
	const OUTAGE_TYPES = array( 'timeout', 'connect', 'network', 'server', 'auth', 'account' );

	/**
	 * Absolute microtime() deadline of the dispatch in progress.
	 *
	 * @var float|null
	 */
	private static $deadline = null;

	/**
	 * Absolute microtime() deadline of the gateway attempt in progress.
	 *
	 * @var float|null
	 */
	private static $attempt_deadline = null;

	/**
	 * Per-request copy of the stored health data.
	 *
	 * @var array|null
	 */
	private static $health = null;

	/* ---------------------------------------------------------------------
	 * Settings
	 * ------------------------------------------------------------------- */

	/**
	 * Maximum seconds to wait for one gateway (setting, 2–15).
	 *
	 * @return float
	 */
	public static function gateway_timeout() {
		$seconds = (float) Ashna_Helper::get_option( 'gateway_timeout', 5 );
		return max( 2.0, min( 15.0, $seconds > 0 ? $seconds : 5.0 ) );
	}

	/**
	 * Base cooldown for a failing gateway, in seconds (setting in minutes, 1–60).
	 *
	 * @return int
	 */
	public static function cooldown() {
		$minutes = absint( Ashna_Helper::get_option( 'gateway_cooldown', 5 ) );
		return max( 1, min( 60, $minutes > 0 ? $minutes : 5 ) ) * 60;
	}

	/**
	 * Total seconds one OTP dispatch may spend across the whole chain.
	 *
	 * @return float
	 */
	public static function total_budget() {
		$budget = max( 8.0, min( 20.0, self::gateway_timeout() * 3 ) );

		/**
		 * Filters the total time budget (seconds) for delivering one OTP.
		 *
		 * @param float $budget Default: 3 × gateway timeout, clamped to 8–20 seconds.
		 */
		return max( 2.0, (float) apply_filters( 'ashna_otp_failover_budget', $budget ) );
	}

	/**
	 * Whether gateways get a time slot learned from their own response times.
	 *
	 * @return bool
	 */
	public static function adaptive_enabled() {
		return (bool) Ashna_Helper::get_option( 'gateway_adaptive', 1 );
	}

	/**
	 * Time slot for one attempt on a gateway.
	 *
	 * A provider that usually answers in 0.4s does not need 5 seconds: after
	 * ADAPTIVE_MIN_SAMPLES successes the slot is 4x its average response time,
	 * at least 2 seconds and never more than the configured maximum.
	 *
	 * @param string $id Gateway ID.
	 * @return float Seconds.
	 */
	public static function slot_for( $id ) {
		$cap = self::gateway_timeout();
		if ( ! self::adaptive_enabled() ) {
			return $cap;
		}
		$row = self::get( $id );
		if ( (int) $row['ok'] < self::ADAPTIVE_MIN_SAMPLES || (int) $row['avg_ms'] <= 0 ) {
			return $cap;
		}
		return max( self::ADAPTIVE_FLOOR, min( $cap, self::ADAPTIVE_FACTOR * (int) $row['avg_ms'] / 1000 ) );
	}

	/* ---------------------------------------------------------------------
	 * Time budget for the running dispatch
	 * ------------------------------------------------------------------- */

	/**
	 * Start the time budget of one OTP dispatch.
	 */
	public static function begin() {
		self::$deadline         = microtime( true ) + self::total_budget();
		self::$attempt_deadline = null;
	}

	/**
	 * Clear the dispatch budget.
	 */
	public static function end() {
		self::$deadline         = null;
		self::$attempt_deadline = null;
	}

	/**
	 * Seconds left in the dispatch budget, or null outside a dispatch.
	 *
	 * @return float|null
	 */
	public static function remaining() {
		return null === self::$deadline ? null : self::$deadline - microtime( true );
	}

	/**
	 * Whether there is enough budget left to start another gateway.
	 *
	 * @return bool
	 */
	public static function has_time_for_attempt() {
		$remaining = self::remaining();
		return null === $remaining || $remaining >= self::MIN_ATTEMPT;
	}

	/**
	 * Give the next gateway attempt its own time slot. All HTTP calls the
	 * gateway makes (e.g. Bale: token + send + retry) share this slot.
	 *
	 * @param float $seconds Attempt time limit.
	 */
	public static function start_attempt( $seconds ) {
		$seconds   = (float) $seconds;
		$remaining = self::remaining();
		if ( null !== $remaining ) {
			$seconds = min( $seconds, $remaining );
		}
		self::$attempt_deadline = microtime( true ) + max( 0.5, $seconds );
	}

	/**
	 * Close the attempt time slot.
	 */
	public static function end_attempt() {
		self::$attempt_deadline = null;
	}

	/**
	 * Timeouts for the next HTTP call made by a gateway.
	 *
	 * @return array{timeout: float, connect: float}|WP_Error WP_Error when no time is left.
	 */
	public static function http_limits() {
		$now   = microtime( true );
		$limit = null !== self::$attempt_deadline ? self::$attempt_deadline - $now : self::gateway_timeout();
		$type  = 'timeout';

		if ( null !== self::$deadline && self::$deadline - $now < $limit ) {
			$limit = self::$deadline - $now;
			$type  = 'budget';
		}

		if ( $limit < 0.25 ) {
			return new WP_Error(
				'ashna_time_exhausted',
				'budget' === $type ? 'مهلت ارسال کد به پایان رسید.' : 'درگاه در مهلت تعیین‌شده پاسخ نداد.',
				array( 'ashna_error_type' => $type )
			);
		}

		$limit = max( 0.5, $limit );
		return array(
			'timeout' => round( $limit, 2 ),
			'connect' => round( min( self::CONNECT_TIMEOUT, $limit ), 2 ),
		);
	}

	/* ---------------------------------------------------------------------
	 * Circuit breaker & health stats
	 * ------------------------------------------------------------------- */

	/**
	 * Empty health record.
	 *
	 * @return array
	 */
	private static function blank() {
		return array(
			'open_until' => 0,  // Unix time; > 0 while the gateway is sidelined.
			'opens'      => 0,  // Consecutive openings (cooldown backoff exponent).
			'streak'     => 0,  // Consecutive failed attempts.
			'ok'         => 0,
			'fail'       => 0,
			'last_ok'    => 0,
			'last_fail'  => 0,
			'last_ms'    => 0,
			'avg_ms'     => 0,
			'last_type'  => '',
			'last_error' => '',
			'by_probe'   => false, // Circuit opened by the background probe.
			'last_probe' => 0,
			'probe_ok'   => null,
			'probe_ms'   => 0,
		);
	}

	/**
	 * All stored health records.
	 *
	 * @return array<string, array>
	 */
	private static function load() {
		if ( null === self::$health ) {
			$stored       = get_option( self::OPTION, array() );
			self::$health = is_array( $stored ) ? $stored : array();
		}
		return self::$health;
	}

	/**
	 * Store one gateway record.
	 *
	 * @param string $id  Gateway ID.
	 * @param array  $row Health record.
	 */
	private static function put( $id, $row ) {
		self::load();
		self::$health[ $id ] = $row;
		update_option( self::OPTION, self::$health, false );
	}

	/**
	 * Health record of one gateway.
	 *
	 * @param string $id Gateway ID.
	 * @return array
	 */
	public static function get( $id ) {
		$all = self::load();
		return isset( $all[ $id ] ) && is_array( $all[ $id ] ) ? array_merge( self::blank(), $all[ $id ] ) : self::blank();
	}

	/**
	 * Circuit state: 'closed' (normal), 'open' (skip) or 'trial' (cooldown over; one quick try).
	 *
	 * @param string $id Gateway ID.
	 * @return string
	 */
	public static function state( $id ) {
		$row = self::get( $id );
		if ( empty( $row['open_until'] ) ) {
			return 'closed';
		}
		return (int) $row['open_until'] > time() ? 'open' : 'trial';
	}

	/**
	 * Reserve the trial call so concurrent visitors keep skipping the gateway meanwhile.
	 *
	 * @param string $id Gateway ID.
	 */
	public static function claim_trial( $id ) {
		$row               = self::get( $id );
		$row['open_until'] = time() + (int) ceil( self::TRIAL_TIMEOUT ) + 10;
		self::put( $id, $row );
	}

	/**
	 * Record a successful delivery: closes the circuit.
	 *
	 * @param string $id Gateway ID.
	 * @param int    $ms Duration in milliseconds.
	 */
	public static function record_success( $id, $ms ) {
		$row               = self::get( $id );
		$ms                = max( 0, (int) $ms );
		$row['open_until'] = 0;
		$row['opens']      = 0;
		$row['streak']     = 0;
		$row['by_probe']   = false;
		$row['ok']         = (int) $row['ok'] + 1;
		$row['last_ok']    = time();
		$row['last_ms']    = $ms;
		$row['avg_ms']     = (int) $row['avg_ms'] > 0 ? (int) round( $row['avg_ms'] * 0.7 + $ms * 0.3 ) : $ms;
		self::put( $id, $row );
	}

	/**
	 * Record a failed attempt; opens the circuit for outage-type errors.
	 *
	 * @param string $id      Gateway ID.
	 * @param string $type    Error type from classify().
	 * @param string $message Error message.
	 * @param int    $ms       Duration in milliseconds.
	 * @param bool   $by_probe Failure seen by the background probe, not a visitor.
	 * @return bool Whether the circuit is open now.
	 */
	public static function record_failure( $id, $type, $message, $ms, $by_probe = false ) {
		$row               = self::get( $id );
		$row['streak']     = (int) $row['streak'] + 1;
		$row['fail']       = (int) $row['fail'] + 1;
		$row['last_fail']  = time();
		$row['last_ms']    = max( 0, (int) $ms );
		$row['last_type']  = (string) $type;
		$row['last_error'] = self::shorten( $message );

		$opened = false;
		if ( self::opens_circuit( $type ) ) {
			$row['opens']      = min( 10, (int) $row['opens'] + 1 );
			$cooldown          = min( self::cooldown() * pow( 2, $row['opens'] - 1 ), max( self::cooldown(), self::MAX_COOLDOWN ) );
			$row['open_until'] = time() + (int) $cooldown;
			$row['by_probe']   = (bool) $by_probe;
			$opened            = true;
		}

		self::put( $id, $row );
		return $opened || ( ! empty( $row['open_until'] ) && (int) $row['open_until'] > time() );
	}

	/**
	 * Whether a failure should sideline the gateway (outage-type errors only).
	 *
	 * @param string $type Error type.
	 * @return bool
	 */
	public static function opens_circuit( $type ) {
		return in_array( $type, self::OUTAGE_TYPES, true );
	}

	/**
	 * Close every circuit (e.g. after the admin changes gateway settings). Stats are kept.
	 */
	public static function reset_circuits() {
		self::load();
		if ( empty( self::$health ) ) {
			return;
		}
		foreach ( self::$health as $id => $row ) {
			if ( is_array( $row ) ) {
				$row['open_until']   = 0;
				$row['opens']        = 0;
				$row['streak']       = 0;
				$row['by_probe']     = false;
				self::$health[ $id ] = $row;
			}
		}
		update_option( self::OPTION, self::$health, false );
	}

	/**
	 * Forget all health data.
	 */
	public static function reset_all() {
		self::$health = array();
		delete_option( self::OPTION );
	}

	/* ---------------------------------------------------------------------
	 * Background health probe (WP-Cron)
	 * ------------------------------------------------------------------- */

	/**
	 * Add the 5-minute schedule used by the probe.
	 *
	 * @param array $schedules WP-Cron schedules.
	 * @return array
	 */
	public static function register_cron_schedule( $schedules ) {
		$schedules['ashna_five_minutes'] = array(
			'interval' => self::PROBE_INTERVAL,
			'display'  => 'هر ۵ دقیقه (آشنا)',
		);
		return $schedules;
	}

	/**
	 * Schedule the probe if it is not scheduled yet.
	 */
	public static function ensure_probe_scheduled() {
		if ( function_exists( 'wp_next_scheduled' ) && ! wp_next_scheduled( self::PROBE_HOOK ) ) {
			wp_schedule_event( time() + 60, 'ashna_five_minutes', self::PROBE_HOOK );
		}
	}

	/**
	 * Remove the probe schedule.
	 */
	public static function unschedule_probe() {
		$timestamp = wp_next_scheduled( self::PROBE_HOOK );
		if ( $timestamp ) {
			wp_unschedule_event( $timestamp, self::PROBE_HOOK );
		}
	}

	/**
	 * Check every gateway on the delivery path (WP-Cron, every 5 minutes).
	 *
	 * Runs in WordPress's background cron request, never in a visitor's
	 * request. A gateway whose host does not answer is sidelined before any
	 * visitor reaches it, so even the first visitor of an outage waits 0s.
	 *
	 * @return array<string, string> Gateway ID => ok | skipped | error type.
	 */
	public static function run_probe() {
		$results = array();
		if ( ! Ashna_Helper::get_option( 'gateway_probe', 1 ) ) {
			return $results;
		}
		foreach ( Ashna_Gateway_Manager::probe_targets() as $gateway ) {
			$results[ $gateway->get_id() ] = self::probe( $gateway );
		}
		return $results;
	}

	/**
	 * Probe one gateway with a HEAD request to its API host. Any HTTP answer
	 * below 500 means reachable; nothing is sent and no credit is used.
	 *
	 * @param Ashna_Gateway_Interface $gateway Gateway.
	 * @return string ok | skipped | error type.
	 */
	public static function probe( $gateway ) {
		$url = method_exists( $gateway, 'get_probe_url' ) ? (string) $gateway->get_probe_url() : '';
		if ( '' === $url ) {
			return 'skipped';
		}

		Ashna_Abstract_Gateway::ensure_curl_hook();
		$id       = $gateway->get_id();
		$started  = microtime( true );
		$response = wp_remote_head(
			$url,
			array(
				'timeout'               => self::TRIAL_TIMEOUT,
				'redirection'           => 0,
				'ashna_connect_timeout' => 2.0,
			)
		);
		$ms = (int) round( ( microtime( true ) - $started ) * 1000 );

		$type    = '';
		$message = '';
		if ( is_wp_error( $response ) ) {
			$type    = self::classify_transport_message( $response->get_error_message(), 'network' );
			$message = $response->get_error_message();
		} elseif ( (int) wp_remote_retrieve_response_code( $response ) >= 500 ) {
			$type    = 'server';
			$message = 'HTTP ' . (int) wp_remote_retrieve_response_code( $response );
		}

		$row               = self::get( $id );
		$row['last_probe'] = time();
		$row['probe_ms']   = $ms;
		$row['probe_ok']   = '' === $type;

		if ( '' === $type ) {
			// Reachable again: a circuit the probe opened is tried right away.
			if ( ! empty( $row['by_probe'] ) && (int) $row['open_until'] > time() ) {
				$row['open_until'] = time();
			}
			self::put( $id, $row );
			return 'ok';
		}

		self::put( $id, $row );
		if ( 'closed' === self::state( $id ) ) {
			self::record_failure( $id, $type, 'بررسی خودکار: ' . $message, $ms, true );
		}
		return $type;
	}

	/* ---------------------------------------------------------------------
	 * Error classification
	 * ------------------------------------------------------------------- */

	/**
	 * Classify a gateway error.
	 *
	 * Types: timeout, connect, network, server, auth, account (outages: the
	 * gateway is sidelined), api (provider rejected this request), config
	 * (missing settings, nothing was sent), input (the number itself was
	 * rejected: other gateways of the same channel are not tried), budget.
	 *
	 * Every type except input moves on to the next gateway.
	 *
	 * Gateways may declare the type explicitly with
	 * `new WP_Error( $code, $message, array( 'ashna_error_type' => 'input' ) )`.
	 *
	 * @param WP_Error   $error Gateway error.
	 * @param array|null $trace Transport trace of Ashna_Abstract_Gateway, or null for custom gateways.
	 * @return string
	 */
	public static function classify( $error, $trace ) {
		$data = $error->get_error_data();
		if ( is_array( $data ) && ! empty( $data['ashna_error_type'] ) ) {
			return sanitize_key( $data['ashna_error_type'] );
		}

		if ( is_array( $trace ) && ! empty( $trace['exhausted'] ) ) {
			return 'budget' === $trace['exhausted'] ? 'budget' : 'timeout';
		}

		$last = is_array( $trace ) && ! empty( $trace['last'] ) ? $trace['last'] : null;
		if ( null === $last ) {
			// Built-in gateway that made no HTTP call: settings are missing.
			// Custom gateway without a trace: infer from the message.
			return is_array( $trace ) ? 'config' : self::classify_transport_message( $error->get_error_message(), 'api' );
		}

		if ( '' !== (string) $last['error'] ) {
			return self::classify_transport_message( $last['error'], 'network' );
		}

		$status = (int) $last['code'];
		if ( $status >= 500 || 429 === $status || 408 === $status ) {
			return 'server';
		}
		if ( 401 === $status || 403 === $status ) {
			return 'auth';
		}
		return 'api';
	}

	/**
	 * Classify a transport (cURL / streams) error message.
	 *
	 * @param string $message  Error message.
	 * @param string $fallback Type when nothing matches.
	 * @return string
	 */
	private static function classify_transport_message( $message, $fallback ) {
		$text = strtolower( (string) $message );

		if ( preg_match( '/curl error (\d+)/', $text, $match ) ) {
			$curl = (int) $match[1];
			if ( 28 === $curl ) {
				return 'timeout';
			}
			if ( in_array( $curl, array( 5, 6, 7, 35, 52, 55, 56, 60, 77 ), true ) ) {
				return 'connect';
			}
			return 'network';
		}

		foreach ( array( 'timed out', 'timeout' ) as $needle ) {
			if ( false !== strpos( $text, $needle ) ) {
				return 'timeout';
			}
		}
		foreach ( array( 'could not resolve', 'resolve host', 'failed to connect', 'connection refused', "couldn't connect", 'network is unreachable', 'no route to host', 'connection reset' ) as $needle ) {
			if ( false !== strpos( $text, $needle ) ) {
				return 'connect';
			}
		}
		return $fallback;
	}

	/* ---------------------------------------------------------------------
	 * Human-readable output
	 * ------------------------------------------------------------------- */

	/**
	 * Persian label for an error type.
	 *
	 * @param string $type Error type.
	 * @return string
	 */
	public static function type_label( $type ) {
		$labels = array(
			'timeout' => 'پاسخ نداد (اتمام مهلت)',
			'connect' => 'در دسترس نبود',
			'network' => 'خطای شبکه',
			'server'  => 'خطای سرور درگاه',
			'auth'    => 'کلید یا دسترسی نامعتبر',
			'account' => 'مشکل حساب درگاه (اعتبار یا محدودیت)',
			'api'     => 'درخواست را رد کرد',
			'config'  => 'تنظیمات ناقص',
			'input'   => 'شماره را نپذیرفت',
			'budget'  => 'مهلت کل ارسال تمام شد',
		);
		return isset( $labels[ $type ] ) ? $labels[ $type ] : 'خطا';
	}

	/**
	 * Persian relative time ("۵ دقیقه پیش"-style, Latin digits like the rest of the panel).
	 * Not tied to the site language, so English-locale sites do not get mixed text.
	 *
	 * @param int $timestamp Unix time.
	 * @return string
	 */
	public static function ago( $timestamp ) {
		$diff = max( 0, time() - (int) $timestamp );
		if ( $diff < 60 ) {
			return 'چند ثانیه پیش';
		}
		if ( $diff < 3600 ) {
			return sprintf( '%d دقیقه پیش', (int) floor( $diff / 60 ) );
		}
		if ( $diff < 86400 ) {
			return sprintf( '%d ساعت پیش', (int) floor( $diff / 3600 ) );
		}
		return sprintf( '%d روز پیش', (int) floor( $diff / 86400 ) );
	}

	/**
	 * One-line trace of a delivery, e.g. for the logs.
	 *
	 * @param array $steps Steps recorded by Ashna_Gateway_Manager::send_via_chain().
	 * @return string
	 */
	public static function describe( array $steps ) {
		$parts = array();
		foreach ( $steps as $step ) {
			$title = isset( $step['title'] ) ? $step['title'] : $step['id'];
			$secs  = isset( $step['ms'] ) ? sprintf( '%.1fs', $step['ms'] / 1000 ) : '';

			switch ( $step['outcome'] ) {
				case 'ok':
					$parts[] = sprintf( '%s: موفق (%s)', $title, $secs );
					break;
				case 'skip':
					$parts[] = 'input' === ( isset( $step['type'] ) ? $step['type'] : '' )
						? sprintf( '%s: امتحان نشد، چون شماره رد شده بود', $title )
						: sprintf( '%s: رد شد، چون موقتاً کنار گذاشته شده', $title );
					break;
				case 'budget':
					$parts[] = sprintf( '%s: امتحان نشد (مهلت کل تمام شد)', $title );
					break;
				default:
					$detail = in_array( $step['type'], array( 'api', 'config', 'input' ), true ) && ! empty( $step['message'] )
						? ' – ' . self::shorten( $step['message'], 90 )
						: '';
					$parts[] = sprintf( '%s: %s (%s)%s', $title, self::type_label( $step['type'] ), $secs, $detail );
			}
		}
		// Numbered steps joined with «؛»: glyphs every Persian font has (arrows are often missing).
		$digits = array( '۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹' );
		foreach ( $parts as $i => $part ) {
			$parts[ $i ] = str_replace( array_map( 'strval', range( 0, 9 ) ), $digits, (string) ( $i + 1 ) ) . ') ' . $part;
		}
		return implode( '؛ ', $parts );
	}

	/**
	 * Shorten an error message for storage and display.
	 *
	 * @param string $message Message.
	 * @param int    $length  Max characters.
	 * @return string
	 */
	private static function shorten( $message, $length = 160 ) {
		$message = wp_strip_all_tags( (string) $message );
		$message = trim( (string) preg_replace( '/\s+/u', ' ', $message ) );
		return wp_html_excerpt( $message, $length, '…' );
	}
}


// ---- Source: includes/services/class-ashna-auth.php ----
/**
 * Authentication, Unified Login/Registration, Password Fallback & AJAX Handlers
 *
 * @package Ashna
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.Security.NonceVerification.Missing -- every AJAX handler below calls Ashna_Session::verify_request() first.
class Ashna_Auth {

	/**
	 * Option holding whether Digits phone keys can exist in this database ('yes'/'no').
	 *
	 * Written once by Ashna_Activator::ensure_digits_meta_flag() (autoloaded, so reading it is
	 * free) and never downgraded.
	 */
	const DIGITS_META_OPTION = 'ashna_otp_digits_meta';

	/**
	 * Singleton instance
	 *
	 * @var Ashna_Auth|null
	 */
	private static $instance = null;

	/**
	 * Get instance
	 *
	 * @return Ashna_Auth
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor
	 */
	private function __construct() {
		add_action( 'wp_ajax_nopriv_ashna_request_otp', array( $this, 'ajax_request_otp' ) );
		add_action( 'wp_ajax_ashna_request_otp', array( $this, 'ajax_request_otp' ) );

		add_action( 'wp_ajax_nopriv_ashna_verify_otp', array( $this, 'ajax_verify_otp' ) );
		add_action( 'wp_ajax_ashna_verify_otp', array( $this, 'ajax_verify_otp' ) );

		add_action( 'wp_ajax_nopriv_ashna_password_login', array( $this, 'ajax_password_login' ) );
		add_action( 'wp_ajax_ashna_password_login', array( $this, 'ajax_password_login' ) );
	}

	/**
	 * Send clean JSON error response
	 *
	 * @param array $data Error payload.
	 */
	private function send_error( $data ) {
		if ( ob_get_length() ) {
			ob_clean();
		}
		wp_send_json_error( $data );
		return; // wp_send_json() ends the request: never continue past a response.
	}

	/**
	 * Send clean JSON success response
	 *
	 * @param array $data Success payload.
	 */
	private function send_success( $data ) {
		if ( ob_get_length() ) {
			ob_clean();
		}
		wp_send_json_success( $data );
	}

	/**
	 * Handle AJAX Request OTP
	 *
	 * Order matters for SMS-bombing protection: cheap checks first (nonce, honeypot, captcha),
	 * then the account lookup, then an atomic reservation of the send slot (per-minute/hour/day
	 * limits per number, IP and network, daily credit guard) and only then the gateway call.
	 */
	public function ajax_request_otp() {
		if ( true !== Ashna_Session::verify_request() ) {
			return;
		}

		$raw_identifier = isset( $_POST['identifier'] ) ? sanitize_text_field( wp_unslash( $_POST['identifier'] ) ) : '';
		$parsed         = Ashna_Helper::parse_identifier( $raw_identifier );
		$type           = $parsed['type'];
		$identifier     = $parsed['normalized'];
		$ip             = Ashna_Helper::get_client_ip();

		// Honeypot: a field people never see. Bots that fill every input get a normal-looking
		// answer, but nothing is sent and nothing is stored.
		if ( ! empty( $_POST['ashna_website'] ) ) {
			Ashna_Rate_Limiter::record_block( 'ashna_honeypot', 'invalid' !== $type ? $identifier : '', $ip );
			$this->send_success(
				array(
					'message'       => 'کد تایید ارسال شد.',
					'identifier'    => $identifier,
					'masked'        => Ashna_Helper::mask_identifier( $identifier ),
					'type'          => $type,
					'channel'       => 'sms',
					'cooldown'      => absint( Ashna_Helper::get_option( 'resend_cooldown', 60 ) ),
					'expiry'        => absint( Ashna_Helper::get_option( 'otp_expiry', 120 ) ),
					'otp_length'    => absint( Ashna_Helper::get_option( 'otp_length', 5 ) ),
					'is_new_user'   => false,
					'require_name'  => 'disabled',
					'require_email' => 'disabled',
				)
			);
		}

		if ( empty( $raw_identifier ) ) {
			$this->send_error( array( 'message' => 'لطفاً شماره موبایل یا ایمیل خود را وارد کنید.' ) );
			return; // wp_send_json() ends the request: never continue past a response.
		}

		// Captcha: the configured one, or the math captcha while attack mode is on. A resend
		// ticket from this visitor's previous successful request for the same number replaces it.
		$resend_ticket = isset( $_POST['resend_token'] ) ? sanitize_text_field( wp_unslash( $_POST['resend_token'] ) ) : '';
		$has_ticket    = 'invalid' !== $type && Ashna_Security::valid_resend_ticket( $resend_ticket, $identifier );
		if ( Ashna_Rate_Limiter::captcha_required() && ! $has_ticket ) {
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			$captcha_ok = Ashna_Security::verify_captcha( wp_unslash( $_POST ) );
			if ( is_wp_error( $captcha_ok ) ) {
				Ashna_Rate_Limiter::record_block( $captcha_ok->get_error_code(), 'invalid' !== $type ? $identifier : '', $ip );
				$this->send_error(
					array(
						'message'     => $captcha_ok->get_error_message(),
						'code'        => $captcha_ok->get_error_code(),
						'new_captcha' => self::next_math_captcha(),
					)
				);
				return; // wp_send_json() ends the request: never continue past a response.
			}
		}

		$login_mode = Ashna_Helper::get_option( 'login_mode', 'phone_and_email' );

		if ( 'invalid' === $type ) {
			if ( 'phone_only' === $login_mode ) {
				$message = 'شماره موبایل وارد شده معتبر نیست. (مثال: 09123456789)';
			} elseif ( 'email_only' === $login_mode ) {
				$message = 'آدرس ایمیل وارد شده معتبر نیست.';
			} else {
				$message = 'لطفاً یک شماره موبایل معتبر (مثل 09123456789) یا آدرس ایمیل صحیح وارد کنید.';
			}
			$this->send_error( array( 'message' => $message, 'new_captcha' => self::next_math_captcha() ) );
			return; // wp_send_json() ends the request: never continue past a response.
		}

		if ( 'phone_only' === $login_mode && 'phone' !== $type ) {
			$this->send_error( array( 'message' => 'ورود فقط با شماره موبایل امکان‌پذیر است.', 'new_captcha' => self::next_math_captcha() ) );
			return; // wp_send_json() ends the request: never continue past a response.
		}

		if ( 'email_only' === $login_mode && 'email' !== $type ) {
			$this->send_error( array( 'message' => 'ورود فقط با آدرس ایمیل امکان‌پذیر است.', 'new_captcha' => self::next_math_captcha() ) );
			return; // wp_send_json() ends the request: never continue past a response.
		}

		$account = self::resolve_account( $identifier, $type );
		if ( $account['error'] ) {
			$this->send_error(
				array(
					'message'     => $account['error']->get_error_message(),
					'code'        => $account['error']->get_error_code(),
					'new_captcha' => self::next_math_captcha(),
				)
			);
			return; // wp_send_json() ends the request: never continue past a response.
		}
		$existing_user = $account['user'];
		$auto_register = (bool) Ashna_Helper::get_option( 'auto_register', 1 );

		if ( ! $existing_user && ! $auto_register ) {
			$this->send_error( array( 'message' => 'حساب کاربری با این مشخصات یافت نشد.', 'new_captcha' => self::next_math_captcha() ) );
			return; // wp_send_json() ends the request: never continue past a response.
		}

		$reservation = Ashna_Rate_Limiter::reserve( $identifier, $ip );
		if ( is_wp_error( $reservation ) ) {
			$data = $reservation->get_error_data();
			$this->send_error(
				array(
					'message'     => $reservation->get_error_message(),
					'code'        => $reservation->get_error_code(),
					'remaining'   => isset( $data['remaining'] ) ? (int) $data['remaining'] : 0,
					'new_captcha' => self::next_math_captcha(),
				)
			);
			return; // wp_send_json() ends the request: never continue past a response.
		}

		$dispatch = Ashna_Gateway_Manager::dispatch_otp( $identifier, $type, '', '', $reservation );
		if ( is_wp_error( $dispatch ) ) {
			// The provider's reason ("credit too low", "invalid API key", "check SMTP" ...) is kept in
			// the logs; visitors get a plain message, administrators and debug mode see the detail.
			$show_detail = current_user_can( 'manage_options' ) || Ashna_Helper::get_option( 'show_debug_code_in_toast', 0 );
			$this->send_error(
				array(
					'message'     => $show_detail
						? 'خطا در ارسال کد تایید: ' . $dispatch->get_error_message()
						: ( 'email' === $type
							? 'ارسال ایمیل کد تایید در حال حاضر ممکن نشد. لطفاً چند دقیقه دیگر دوباره تلاش کنید.'
							: 'ارسال کد تایید در حال حاضر ممکن نشد. لطفاً چند دقیقه دیگر دوباره تلاش کنید.' ),
					'code'        => 'ashna_send_failed',
					'new_captcha' => self::next_math_captcha(),
				)
			);
			return; // wp_send_json() ends the request: never continue past a response.
		}

		$channel_labels = array(
			'sms'       => 'پیامک',
			'bale'      => 'پیام‌رسان بله',
			'sms+bale'  => 'پیامک و پیام‌رسان بله',
			'email'     => 'ایمیل',
			'messenger' => Ashna_Gateway_Msgway_Messenger::route_label(),
		);
		$channel_label  = isset( $channel_labels[ $dispatch['channel'] ] ) ? $channel_labels[ $dispatch['channel'] ] : 'پیامک';

		$is_new_user   = empty( $existing_user );
		$require_name  = $is_new_user ? Ashna_Helper::get_option( 'require_name_on_register', 'optional' ) : 'disabled';
		$require_email = ( $is_new_user && 'phone' === $type ) ? Ashna_Helper::get_option( 'require_email_on_register', 'disabled' ) : 'disabled';

		$response_data = array(
			'message'       => sprintf( 'کد تایید از طریق %s به %s ارسال شد.', $channel_label, Ashna_Helper::mask_identifier( $identifier ) ),
			'identifier'    => $identifier,
			'masked'        => Ashna_Helper::mask_identifier( $identifier ),
			'type'          => $type,
			'channel'       => $dispatch['channel'],
			'cooldown'      => absint( Ashna_Helper::get_option( 'resend_cooldown', 60 ) ),
			'expiry'        => absint( Ashna_Helper::get_option( 'otp_expiry', 120 ) ),
			'otp_length'    => absint( Ashna_Helper::get_option( 'otp_length', 5 ) ),
			'is_new_user'   => $is_new_user,
			'require_name'  => $require_name,
			'require_email' => $require_email,
		);

		if ( 'sandbox' === $dispatch['gateway'] && Ashna_Helper::get_option( 'show_debug_code_in_toast', 0 ) ) {
			$response_data['debug_code'] = $dispatch['code'];
		}

		// Resends of this number from this visitor skip the captcha (limits still apply).
		$response_data['resend_token'] = Ashna_Security::resend_ticket( $identifier );
		$response_data['new_captcha']  = self::next_math_captcha();

		$this->send_success( $response_data );
	}

	/**
	 * A fresh math captcha when it is in use (single-use tokens must be replaced after every request).
	 *
	 * @return array|null
	 */
	private static function next_math_captcha() {
		return Ashna_Security::math_captcha_active() ? Ashna_Security::generate_math_captcha() : null;
	}

	/**
	 * Handle AJAX Verify OTP & Unified Login / Auto-Register
	 */
	public function ajax_verify_otp() {
		if ( true !== Ashna_Session::verify_request() ) {
			return;
		}

		$raw_identifier = isset( $_POST['identifier'] ) ? sanitize_text_field( wp_unslash( $_POST['identifier'] ) ) : '';
		$raw_code       = isset( $_POST['code'] ) ? sanitize_text_field( wp_unslash( $_POST['code'] ) ) : '';
		$redirect_to    = isset( $_POST['redirect_to'] ) ? esc_url_raw( Ashna_Helper::as_string( wp_unslash( $_POST['redirect_to'] ) ) ) : '';
		$full_name      = isset( $_POST['full_name'] ) ? sanitize_text_field( wp_unslash( $_POST['full_name'] ) ) : '';
		$extra_email    = isset( $_POST['user_email'] ) ? sanitize_email( Ashna_Helper::as_string( wp_unslash( $_POST['user_email'] ) ) ) : '';
		$form_context   = isset( $_POST['context'] ) ? sanitize_key( Ashna_Helper::as_string( wp_unslash( $_POST['context'] ) ) ) : '';

		$parsed     = Ashna_Helper::parse_identifier( $raw_identifier );
		$type       = $parsed['type'];
		$identifier = $parsed['normalized'];

		if ( 'invalid' === $type ) {
			$this->send_error( array( 'message' => 'شناسه کاربری نامعتبر است.' ) );
			return; // wp_send_json() ends the request: never continue past a response.
		}

		$account = self::resolve_account( $identifier, $type );
		if ( $account['error'] ) {
			$this->send_error(
				array(
					'message' => $account['error']->get_error_message(),
					'code'    => $account['error']->get_error_code(),
				)
			);
			return; // wp_send_json() ends the request: never continue past a response.
		}
		$user        = $account['user'];
		$is_new_user = false;

		/**
		 * Extra sign-up data from the form (e.g. Dokan vendor fields). Only used for new accounts.
		 *
		 * @param array  $extra      Data passed to register_user().
		 * @param array  $post       Raw request (unslashed).
		 * @param string $identifier Normalized phone/email.
		 * @param string $type       phone|email.
		 */
		// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- integrations sanitize their own fields.
		$registration = (array) apply_filters( 'ashna_otp_registration_data', array( 'full_name' => $full_name, 'user_email' => $extra_email ), wp_unslash( $_POST ), $identifier, $type );

		if ( ! $user ) {
			if ( ! Ashna_Helper::get_option( 'auto_register', 1 ) ) {
				$this->send_error( array( 'message' => 'ثبت‌نام خودکار غیرفعال است.' ) );
				return; // wp_send_json() ends the request: never continue past a response.
			}

			$name_mode  = Ashna_Helper::get_option( 'require_name_on_register', 'optional' );
			$email_mode = Ashna_Helper::get_option( 'require_email_on_register', 'disabled' );

			if ( 'required' === $name_mode && empty( $registration['full_name'] ) ) {
				$this->send_error( array( 'message' => 'لطفاً نام و نام خانوادگی خود را وارد کنید.' ) );
				return; // wp_send_json() ends the request: never continue past a response.
			}

			if ( 'phone' === $type && 'required' === $email_mode && ( empty( $extra_email ) || ! is_email( $extra_email ) ) ) {
				$this->send_error( array( 'message' => 'لطفاً یک آدرس ایمیل معتبر وارد کنید.' ) );
				return; // wp_send_json() ends the request: never continue past a response.
			}
		}

		if ( ! $user ) {
			/**
			 * Validate sign-up data BEFORE the code is checked, so a mistake does not burn the code.
			 *
			 * @param null|WP_Error $error        Error to stop the sign-up.
			 * @param array         $registration Sign-up data.
			 * @param string        $identifier   Normalized phone/email.
			 * @param string        $type         phone|email.
			 */
			$registration_error = apply_filters( 'ashna_otp_registration_errors', null, $registration, $identifier, $type );
			if ( is_wp_error( $registration_error ) ) {
				$this->send_error(
					array(
						'message' => $registration_error->get_error_message(),
						'code'    => $registration_error->get_error_code(),
						'field'   => (string) $registration_error->get_error_data(),
					)
				);
				return; // wp_send_json() ends the request: never continue past a response.
			}
		}

		$verified = Ashna_Security::verify_otp( $identifier, $raw_code );
		if ( is_wp_error( $verified ) ) {
			$this->send_error(
				array(
					'message' => $verified->get_error_message(),
					'code'    => $verified->get_error_code(),
				)
			);
			return; // wp_send_json() ends the request: never continue past a response.
		}

		if ( ! $user ) {
			$user = self::register_user( $identifier, $type, $registration );
			if ( is_wp_error( $user ) ) {
				$this->send_error( array( 'message' => $user->get_error_message() ) );
				return; // wp_send_json() ends the request: never continue past a response.
			}
			$is_new_user = true;
		} else {
			if ( 'phone' === $type ) {
				self::sync_user_phone_meta( $user->ID, $identifier );
			}
		}

		$logged_in = Ashna_Session::login(
			$user,
			array(
				'method'      => 'otp',
				'identifier'  => $identifier,
				'is_new_user' => $is_new_user,
				'form'        => $form_context,
			)
		);
		if ( is_wp_error( $logged_in ) ) {
			$this->send_error(
				array(
					'message' => $logged_in->get_error_message(),
					'code'    => $logged_in->get_error_code(),
				)
			);
			return; // wp_send_json() ends the request: never continue past a response.
		}
		do_action( 'ashna_otp_user_authenticated', $user, $identifier, $type, $is_new_user );

		$this->send_success(
			self::login_response(
				$user,
				$redirect_to,
				$is_new_user ? 'ثبت‌نام و ورود شما با موفقیت انجام شد! در حال انتقال...' : 'ورود با موفقیت انجام شد! در حال انتقال...',
				array( 'is_new_user' => $is_new_user ),
				array(
					'is_new_user' => $is_new_user,
					'form'        => $form_context,
				)
			)
		);
	}

	/**
	 * Success payload shared by every sign-in path.
	 *
	 * The nonce belongs to the new session, so follow-up requests on the same page (for
	 * example registering a passkey right after the OTP step) are accepted.
	 *
	 * @param WP_User $user        Signed-in user.
	 * @param string  $redirect_to Requested redirect.
	 * @param string  $message     Message.
	 * @param array   $extra       Extra fields.
	 * @param array   $context     Redirect context { is_new_user, form }.
	 * @return array
	 */
	public static function login_response( $user, $redirect_to, $message, $extra = array(), $context = array() ) {
		$redirect = Ashna_Session::redirect_url( $user, $redirect_to, $context );
		$state    = Ashna_Session::client_state();

		$payload = array_merge(
			array(
				'message'     => $message,
				'redirect_to' => $redirect,
				'redirect'    => $redirect,
				'user_id'     => $user->ID,
				'nonce'       => $state['nonce'],
				'logged_in'   => $state['logged_in'],
			),
			$extra
		);

		/**
		 * Filters the sign-in response (e.g. to add a token for a headless front end).
		 *
		 * @param array   $payload Response data.
		 * @param WP_User $user    Signed-in user.
		 */
		return apply_filters( 'ashna_otp_login_response', $payload, $user );
	}

	/**
	 * Handle AJAX Password Login Fallback (with Brute-Force Protection)
	 */
	public function ajax_password_login() {
		if ( true !== Ashna_Session::verify_request() ) {
			return;
		}

		$form_context = isset( $_POST['context'] ) ? sanitize_key( Ashna_Helper::as_string( wp_unslash( $_POST['context'] ) ) ) : '';
		// With password sign-in switched off, the wp-login.php takeover still lets staff accounts use
		// their password (they cannot use an unverified phone, and the classic form is gone), so an
		// administrator is never locked out. Customers stay code-only.
		$password_enabled = (bool) Ashna_Helper::get_option( 'allow_password_login', 0 );
		$staff_only       = ! $password_enabled && 'wp-login' === $form_context && self::login_takeover_active();
		if ( ! $password_enabled && ! $staff_only ) {
			$this->send_error( array( 'message' => 'ورود با رمز عبور غیرفعال است.' ) );
			return; // wp_send_json() ends the request: never continue past a response.
		}

		$raw_identifier = isset( $_POST['identifier'] ) ? sanitize_text_field( wp_unslash( $_POST['identifier'] ) ) : '';
		// Not unslashed on purpose: WordPress hashes and checks passwords exactly as posted (slashed)
		// in wp-login.php, profile edits, password resets and WooCommerce, so "p'ss" is stored as the
		// hash of "p\'ss". Unslashing here would lock out everyone with ' " or \ in their password.
		$password = isset( $_POST['password'] ) && is_string( $_POST['password'] ) ? $_POST['password'] : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized,WordPress.Security.ValidatedSanitizedInput.MissingUnslash
		$redirect_to    = isset( $_POST['redirect_to'] ) ? esc_url_raw( Ashna_Helper::as_string( wp_unslash( $_POST['redirect_to'] ) ) ) : '';

		if ( empty( $raw_identifier ) || empty( $password ) ) {
			$this->send_error( array( 'message' => 'لطفاً شناسه کاربری و رمز عبور را وارد کنید.' ) );
			return; // wp_send_json() ends the request: never continue past a response.
		}

		$parsed     = Ashna_Helper::parse_identifier( $raw_identifier );
		$identifier = 'invalid' !== $parsed['type'] ? $parsed['normalized'] : $raw_identifier;

		$lockout = Ashna_Security::check_lockout( $identifier );
		if ( is_wp_error( $lockout ) ) {
			$this->send_error( array( 'message' => $lockout->get_error_message() ) );
			return; // wp_send_json() ends the request: never continue past a response.
		}

		// Locate the account, then let WordPress authenticate it through the full `authenticate`
		// filter chain (2FA, login limiters, membership approval ...) exactly like wp-login.php.
		// Accounts locked by earlier failures (under any of their identifiers) are skipped.
		$candidates   = array();
		$account_keys = array();
		$locked_error = null;
		foreach ( self::password_candidates( $identifier, $parsed['type'] ) as $candidate ) {
			if ( $staff_only && ! self::is_staff_account( $candidate ) ) {
				continue;
			}
			$account_key = Ashna_Security::account_lock_key( $candidate );
			$locked      = Ashna_Security::check_lockout( $account_key );
			if ( is_wp_error( $locked ) ) {
				$locked_error = $locked;
				continue;
			}
			$candidates[]   = $candidate;
			$account_keys[] = $account_key;
		}
		if ( empty( $candidates ) && $locked_error ) {
			$this->send_error( array( 'message' => $locked_error->get_error_message() ) );
			return; // wp_send_json() ends the request: never continue past a response.
		}

		$user = null;
		foreach ( $candidates as $candidate ) {
			if ( wp_check_password( $password, $candidate->user_pass, $candidate->ID ) ) {
				$user = $candidate;
				break;
			}
		}

		$generic = $staff_only
			? 'اطلاعات ورود صحیح نیست. ورود با رمز عبور در این صفحه فقط برای مدیران سایت است؛ مشتریان لطفاً با کد یکبارمصرف وارد شوند.'
			: 'نام کاربری/شماره یا رمز عبور اشتباه است.';
		if ( ! $user ) {
			Ashna_Security::record_failed_password_attempt( $identifier, $account_keys );
			do_action( 'wp_login_failed', $raw_identifier, new WP_Error( 'incorrect_password', $generic ) );
			$this->send_error( array( 'message' => $generic ) );
			return; // wp_send_json() ends the request: never continue past a response.
		}

		$authenticated = wp_authenticate( $user->user_login, $password );
		if ( is_wp_error( $authenticated ) ) {
			$credential_errors = array( 'incorrect_password', 'invalid_username', 'invalid_email', 'empty_password', 'empty_username' );
			if ( in_array( $authenticated->get_error_code(), $credential_errors, true ) ) {
				Ashna_Security::record_failed_password_attempt( $identifier, array( Ashna_Security::account_lock_key( $user ) ) );
				$this->send_error( array( 'message' => $generic ) );
				return; // wp_send_json() ends the request: never continue past a response.
			}
			$readable = Ashna_Session::readable_error( $authenticated );
			$this->send_error(
				array(
					'message' => $readable->get_error_message(),
					'code'    => $readable->get_error_code(),
				)
			);
			return; // wp_send_json() ends the request: never continue past a response.
		}

		Ashna_Security::clear_password_attempts( $identifier, array( Ashna_Security::account_lock_key( $authenticated ) ) );

		$logged_in = Ashna_Session::login(
			$authenticated,
			array(
				'method'        => 'password',
				'identifier'    => $identifier,
				'authenticated' => true,
				'form'          => $form_context,
			)
		);
		if ( is_wp_error( $logged_in ) ) {
			$this->send_error(
				array(
					'message' => $logged_in->get_error_message(),
					'code'    => $logged_in->get_error_code(),
				)
			);
			return; // wp_send_json() ends the request: never continue past a response.
		}

		$this->send_success( self::login_response( $authenticated, $redirect_to, 'ورود با موفقیت انجام شد! در حال انتقال...', array(), array( 'form' => $form_context ) ) );
	}

	/**
	 * Accounts a password sign-in may belong to (a phone can match more than one account).
	 *
	 * @param string $identifier Normalized phone/email or raw username.
	 * @param string $type       phone|email|invalid.
	 * @return WP_User[]
	 */
	private static function password_candidates( $identifier, $type ) {
		if ( 'email' === $type ) {
			$user = get_user_by( 'email', $identifier );
			if ( ! $user ) {
				$user = get_user_by( 'login', $identifier );
			}
			return $user ? array( $user ) : array();
		}
		if ( 'phone' !== $type ) {
			$user = get_user_by( 'login', $identifier );
			return $user ? array( $user ) : array();
		}

		$ids = array();
		foreach ( self::verified_phone_lookups( $identifier ) as $meta_query ) {
			$ids = array_merge( $ids, self::user_ids_by_meta( $meta_query, 5 ) );
		}
		$ids = array_merge( $ids, self::unverified_phone_candidates( $identifier ) );

		$ids = array_slice( array_values( array_unique( array_map( 'absint', $ids ) ) ), 0, 5 );
		if ( ! empty( $ids ) ) {
			if ( function_exists( 'cache_users' ) ) {
				cache_users( $ids );
			}
			if ( function_exists( 'update_meta_cache' ) ) {
				update_meta_cache( 'user', $ids );
			}
		}

		$users = array();
		foreach ( $ids as $id ) {
			$user = get_user_by( 'id', $id );
			if ( $user ) {
				$users[] = $user;
			}
		}
		return $users;
	}

	/**
	 * Find an existing WordPress user by normalized phone or email (backward-compatible API).
	 * Supports users registered via Ashna, Digits, WooCommerce, MihanPanel, or standard WP login.
	 *
	 * @param string $identifier Normalized phone (09XXXXXXXXX) or email.
	 * @param string $type       'phone' or 'email'.
	 * @return WP_User|false False when no account — or no single safe account — matches.
	 */
	public static function find_user( $identifier, $type = 'phone' ) {
		$account = self::resolve_account( $identifier, $type );
		return $account['user'] ? $account['user'] : false;
	}

	/**
	 * Resolve the account that owns a phone/email, without guessing.
	 *
	 * 1. Phones verified by an OTP sign-in (Ashna, then Digits) are trusted.
	 * 2. Unverified profile data (WooCommerce billing phone, legacy "mobile" field, phone-like
	 *    usernames) is used only for ordinary accounts that have no other verified phone.
	 *    Staff accounts (admins, shop managers, editors ...) are never opened through
	 *    unverified data: one mistyped billing phone must not hand out admin access.
	 * 3. When more than one account matches, nobody is signed in and nothing is created.
	 *
	 * @param string $identifier Normalized phone or email.
	 * @param string $type       'phone' or 'email'.
	 * @return array { user: WP_User|null, error: WP_Error|null }
	 */
	public static function resolve_account( $identifier, $type = 'phone' ) {
		$none = array(
			'user'  => null,
			'error' => null,
		);

		if ( 'email' === $type ) {
			$user = get_user_by( 'email', $identifier );
			return $user ? array( 'user' => $user, 'error' => null ) : $none;
		}
		if ( 'phone' !== $type || '' === (string) $identifier ) {
			return $none;
		}

		// 1. Verified phones.
		foreach ( self::verified_phone_lookups( $identifier ) as $meta_query ) {
			$ids = self::user_ids_by_meta( $meta_query, 2 );
			if ( 1 === count( $ids ) ) {
				$user = get_user_by( 'id', $ids[0] );
				if ( $user ) {
					return array( 'user' => $user, 'error' => null );
				}
			} elseif ( count( $ids ) > 1 ) {
				return array( 'user' => null, 'error' => self::ambiguous_error() );
			}
		}

		// 2. Unverified profile data.
		/**
		 * Extra candidate user IDs for a phone (integrations, custom profile fields).
		 *
		 * @param int[]  $ids        Candidate IDs.
		 * @param string $identifier Normalized phone (09XXXXXXXXX).
		 */
		$ids = apply_filters( 'ashna_otp_phone_candidates', self::unverified_phone_candidates( $identifier ), $identifier );
		$ids = array_values( array_unique( array_filter( array_map( 'absint', (array) $ids ) ) ) );

		// One query for the user rows and one for all their meta, instead of a query per user
		// and up to three per meta key further down (is_staff_account/has_other_verified_phone).
		if ( ! empty( $ids ) ) {
			if ( function_exists( 'cache_users' ) ) {
				cache_users( $ids );
			}
			if ( function_exists( 'update_meta_cache' ) ) {
				update_meta_cache( 'user', $ids );
			}
		}

		$eligible  = array();
		$staff_hit = false;
		foreach ( $ids as $id ) {
			$user = get_user_by( 'id', $id );
			if ( ! $user ) {
				continue;
			}
			if ( self::is_staff_account( $user ) ) {
				$staff_hit = true;
				continue;
			}
			if ( self::has_other_verified_phone( $user->ID, $identifier ) ) {
				continue;
			}
			$eligible[] = $user;
		}

		if ( 1 === count( $eligible ) ) {
			return array( 'user' => $eligible[0], 'error' => null );
		}
		if ( count( $eligible ) > 1 ) {
			return array( 'user' => null, 'error' => self::ambiguous_error() );
		}
		if ( $staff_hit ) {
			return array(
				'user'  => null,
				'error' => new WP_Error( 'ashna_staff_phone_unverified', 'ورود با کد یکبارمصرف برای این شماره فعال نیست. لطفاً با رمز عبور وارد شوید یا با پشتیبانی سایت تماس بگیرید.' ),
			);
		}

		return $none;
	}

	/**
	 * Whether Ashna currently replaces wp-login.php (setting on, no recovery constant).
	 *
	 * @return bool
	 */
	public static function login_takeover_active() {
		if ( defined( 'ASHNA_DISABLE_LOGIN_TAKEOVER' ) && ASHNA_DISABLE_LOGIN_TAKEOVER ) {
			return false;
		}
		return (bool) Ashna_Helper::get_option( 'wp_login_integration', 0 );
	}

	/**
	 * Whether an account has staff capabilities (never opened through unverified phone data).
	 *
	 * @param WP_User $user User.
	 * @return bool
	 */
	public static function is_staff_account( $user ) {
		$is_staff = false;
		foreach ( array( 'manage_options', 'edit_users', 'promote_users', 'activate_plugins', 'manage_woocommerce', 'edit_others_posts' ) as $cap ) {
			if ( user_can( $user, $cap ) ) {
				$is_staff = true;
				break;
			}
		}
		return (bool) apply_filters( 'ashna_otp_is_staff_account', $is_staff, $user );
	}

	/**
	 * Meta queries for phones verified by an OTP sign-in (Ashna first, then Digits).
	 *
	 * @param string $identifier Normalized phone.
	 * @return array[]
	 */
	private static function verified_phone_lookups( $identifier ) {
		$lookups = array(
			array(
				array(
					'key'   => 'ashna_phone',
					'value' => $identifier,
				),
			),
		);

		// Digits keeps the phone under its own keys; on a site that never used Digits those rows
		// cannot exist, so the meta query (and the whole new-phone lookup behind it) is skipped.
		if ( ! self::digits_meta_reachable() ) {
			return $lookups;
		}

		$intl_plus = Ashna_Helper::to_international_phone( $identifier, true );
		$intl_raw  = Ashna_Helper::to_international_phone( $identifier, false );
		$no_zero   = ltrim( $identifier, '0' );

		$lookups[] = array(
			'relation' => 'OR',
			array(
				'key'     => 'digits_phone',
				'value'   => array( $intl_plus, $intl_raw, $identifier, $no_zero ),
				'compare' => 'IN',
			),
			array(
				'key'     => 'digits_phone_no',
				'value'   => array( $no_zero, $identifier ),
				'compare' => 'IN',
			),
		);

		return $lookups;
	}

	/**
	 * Whether the Digits phone keys may exist in this database.
	 *
	 * True while Digits is active, and afterwards true for any site where the one-time
	 * activation check (Ashna_Activator::ensure_digits_meta_flag()) found Digits rows — so an
	 * account whose phone only lives in Digits meta is never lost. While the flag is unknown
	 * (an install that has not run the check yet) the keys are treated as present, which is
	 * exactly the pre-change behaviour.
	 *
	 * @return bool
	 */
	private static function digits_meta_reachable() {
		if ( class_exists( 'Digits' ) ) {
			if ( 'yes' !== get_option( self::DIGITS_META_OPTION ) ) {
				// Digits is here now: remember it, so the keys stay reachable if it is removed.
				update_option( self::DIGITS_META_OPTION, 'yes', true );
			}
			return true;
		}

		$flag = get_option( self::DIGITS_META_OPTION, null );
		return null === $flag || 'yes' === $flag;
	}

	/**
	 * User IDs for several candidate logins in ONE query.
	 *
	 * Same matching as a get_user_by( 'login', … ) loop (the candidate is sanitized the same way
	 * and the user object caches are filled the same way), but a new phone number costs one query
	 * instead of one per candidate — and the result order follows the candidate order, as before.
	 *
	 * @param string[] $candidate_logins Candidate logins, most likely first.
	 * @return int[]
	 */
	private static function user_ids_by_logins( array $candidate_logins ) {
		global $wpdb;

		$logins = array();
		foreach ( array_unique( $candidate_logins ) as $candidate_login ) {
			$sanitized = sanitize_user( (string) $candidate_login );
			if ( '' !== $sanitized ) {
				$logins[ $sanitized ] = true;
			}
		}
		if ( empty( $logins ) ) {
			return array();
		}

		$placeholders = implode( ', ', array_fill( 0, count( $logins ), '%s' ) );
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared, WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$wpdb->users} WHERE user_login IN ( {$placeholders} )",
				array_keys( $logins )
			)
		);

		$by_login = array();
		foreach ( (array) $rows as $row ) {
			if ( function_exists( 'update_user_caches' ) ) {
				update_user_caches( $row );
			}
			$by_login[ (string) $row->user_login ] = (int) $row->ID;
		}

		$ids = array();
		foreach ( array_unique( $candidate_logins ) as $candidate_login ) {
			$sanitized = sanitize_user( (string) $candidate_login );
			if ( '' !== $sanitized && isset( $by_login[ $sanitized ] ) ) {
				$ids[] = $by_login[ $sanitized ];
			}
		}

		return $ids;
	}

	/**
	 * Candidate IDs from unverified profile data.
	 *
	 * @param string $identifier Normalized phone.
	 * @return int[]
	 */
	private static function unverified_phone_candidates( $identifier ) {
		$intl_plus = Ashna_Helper::to_international_phone( $identifier, true );
		$intl_raw  = Ashna_Helper::to_international_phone( $identifier, false );
		$no_zero   = ltrim( $identifier, '0' );

		$ids = self::user_ids_by_meta(
			array(
				'relation' => 'OR',
				array(
					'key'     => 'billing_phone',
					'value'   => array( $identifier, $intl_plus, $intl_raw, $no_zero ),
					'compare' => 'IN',
				),
				array(
					'key'     => 'mobile',
					'value'   => array( $identifier, $intl_plus, $no_zero ),
					'compare' => 'IN',
				),
			),
			5
		);

		$login_candidates = array( $identifier, $intl_raw, $intl_plus, $no_zero, 'u_' . $identifier );
		$custom_prefix    = sanitize_key( Ashna_Helper::get_option( 'username_prefix', '' ) );
		if ( ! empty( $custom_prefix ) ) {
			$login_candidates[] = $custom_prefix . $identifier;
		}
		$ids = array_merge( $ids, self::user_ids_by_logins( $login_candidates ) );

		return array_values( array_unique( $ids ) );
	}

	/**
	 * Whether the account already has a different verified phone.
	 *
	 * @param int    $user_id    User ID.
	 * @param string $identifier Normalized phone.
	 * @return bool
	 */
	private static function has_other_verified_phone( $user_id, $identifier ) {
		$verified = (string) get_user_meta( $user_id, 'ashna_phone', true );
		if ( '' !== $verified ) {
			return Ashna_Helper::normalize_phone( $verified ) !== $identifier;
		}
		$digits = (string) get_user_meta( $user_id, 'digits_phone', true );
		if ( '' !== $digits ) {
			return Ashna_Helper::normalize_phone( $digits ) !== $identifier;
		}
		return false;
	}

	/**
	 * User IDs matching a meta query.
	 *
	 * @param array $meta_query Meta query.
	 * @param int   $limit      Max IDs.
	 * @return int[]
	 */
	private static function user_ids_by_meta( $meta_query, $limit = 2 ) {
		$ids = get_users(
			array(
				'meta_query'  => $meta_query, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
				'number'      => $limit,
				'fields'      => 'ID',
				'count_total' => false,
			)
		);
		return array_values( array_map( 'absint', (array) $ids ) );
	}

	/**
	 * Error for a phone shared by several accounts.
	 *
	 * @return WP_Error
	 */
	private static function ambiguous_error() {
		return new WP_Error( 'ashna_ambiguous_account', 'این شماره به بیش از یک حساب کاربری متصل است. لطفاً با ایمیل یا رمز عبور وارد شوید یا با پشتیبانی سایت تماس بگیرید.' );
	}

	/**
	 * Synchronize user phone number across Ashna, WooCommerce, and Digits meta keys
	 * Ensures 100% forward & backward compatibility even if plugins are switched in the future
	 *
	 * @param int    $user_id    WordPress User ID.
	 * @param string $identifier Normalized phone (09XXXXXXXXX).
	 */
	public static function sync_user_phone_meta( $user_id, $identifier ) {
		// 1. Ashna native meta
		update_user_meta( $user_id, 'ashna_phone', $identifier );

		// 2. WooCommerce native billing_phone
		if ( ! get_user_meta( $user_id, 'billing_phone', true ) ) {
			update_user_meta( $user_id, 'billing_phone', $identifier );
		}

		// 3. Digits native meta keys (for seamless cross-plugin compatibility). Skipped on sites
		// where those keys can never be read back (no Digits, none in the database) — that is six
		// meta reads/writes less per registration, with no account finding phones any differently.
		if ( ! self::digits_meta_reachable() ) {
			return;
		}

		$intl_plus = Ashna_Helper::to_international_phone( $identifier, true ); // +989123456789
		$no_zero   = ltrim( $identifier, '0' );                                 // 9123456789

		if ( ! get_user_meta( $user_id, 'digits_phone', true ) ) {
			update_user_meta( $user_id, 'digits_phone', $intl_plus );
		}
		if ( ! get_user_meta( $user_id, 'digits_phone_no', true ) ) {
			update_user_meta( $user_id, 'digits_phone_no', $no_zero );
		}
		if ( ! get_user_meta( $user_id, 'digt_countrycode', true ) ) {
			update_user_meta( $user_id, 'digt_countrycode', '+98' );
		}
	}

	/**
	 * Automatically register a new user from verified phone or email
	 *
	 * @param string $identifier Normalized phone or email.
	 * @param string $type       'phone' or 'email'.
	 * @param array  $extra      Extra profile fields (full_name, user_email).
	 * @return WP_User|WP_Error
	 */
	public static function register_user( $identifier, $type = 'phone', $extra = array() ) {
		/**
		 * Fires before Ashna creates an account (integrations prepare their own sign-up here).
		 *
		 * @param string $identifier Normalized phone/email.
		 * @param string $type       phone|email.
		 * @param array  $extra      Sign-up data.
		 */
		do_action( 'ashna_otp_before_register_user', $identifier, $type, $extra );
		try {
			$result = self::create_account( $identifier, $type, $extra );
		} finally {
			/**
			 * Fires after the account creation attempt, also when it failed.
			 *
			 * @param WP_User|WP_Error $result     New user or error.
			 * @param string           $identifier Normalized phone/email.
			 * @param string           $type       phone|email.
			 * @param array            $extra      Sign-up data.
			 */
			do_action( 'ashna_otp_after_register_user', isset( $result ) ? $result : new WP_Error( 'ashna_register_failed', '' ), $identifier, $type, $extra );
		}
		return $result;
	}

	/**
	 * Create the account (see register_user()).
	 *
	 * @param string $identifier Normalized phone or email.
	 * @param string $type       'phone' or 'email'.
	 * @param array  $extra      Extra profile fields.
	 * @return WP_User|WP_Error
	 */
	private static function create_account( $identifier, $type, $extra ) {
		$prefix = sanitize_key( Ashna_Helper::get_option( 'username_prefix', '' ) );

		if ( 'email' === $type ) {
			$email_local = explode( '@', $identifier )[0];
			$base_login  = sanitize_user( $email_local, true );
			if ( empty( $base_login ) ) {
				$base_login = ( ! empty( $prefix ) ? $prefix : 'user_' ) . wp_rand( 10000, 99999 );
			}
			$user_login = $base_login;
			$suffix     = 1;
			while ( username_exists( $user_login ) ) {
				$user_login = $base_login . '_' . $suffix;
				++$suffix;
			}
			$user_email = $identifier;
		} else {
			$user_login = ! empty( $prefix ) ? ( $prefix . $identifier ) : $identifier;
			if ( username_exists( $user_login ) ) {
				$user_login = $identifier . '_' . wp_rand( 100, 999 );
			}
			$user_email = ! empty( $extra['user_email'] ) && is_email( $extra['user_email'] ) && ! email_exists( $extra['user_email'] )
				? $extra['user_email']
				: '';
		}

		$desired_role = self::safe_registration_role( Ashna_Helper::get_option( 'default_user_role', 'customer' ) );

		$full_name    = ! empty( $extra['full_name'] ) ? trim( $extra['full_name'] ) : '';
		$first_name   = '';
		$last_name    = '';
		$display_name = 'phone' === $type ? $identifier : explode( '@', $identifier )[0];

		if ( ! empty( $full_name ) ) {
			$display_name = $full_name;
			$name_parts   = preg_split( '/\s+/', $full_name, 2 );
			$first_name   = $name_parts[0];
			$last_name    = isset( $name_parts[1] ) ? $name_parts[1] : '';
		}

		$userdata = array(
			'user_login'   => $user_login,
			'user_pass'    => wp_generate_password( 24, true, true ),
			'user_email'   => $user_email,
			'first_name'   => $first_name,
			'last_name'    => $last_name,
			'display_name' => $display_name,
			'role'         => $desired_role,
		);

		$woocommerce = class_exists( 'WooCommerce' );
		if ( $woocommerce ) {
			// Same customer pipeline as WooCommerce's own registration (wc_create_new_customer()).
			$userdata         = (array) apply_filters( 'woocommerce_new_customer_data', $userdata );
			$userdata['role'] = self::safe_registration_role( isset( $userdata['role'] ) ? $userdata['role'] : $desired_role );
		}

		// wp_insert_user() unslashes every field it stores (it expects request-style input), so slash
		// once; otherwise a backslash typed in a name silently disappears.
		$user_id = wp_insert_user( wp_slash( $userdata ) );
		if ( is_wp_error( $user_id ) ) {
			return $user_id;
		}

		if ( 'phone' === $type ) {
			self::sync_user_phone_meta( $user_id, $identifier );
		}

		if ( ! empty( $first_name ) ) {
			update_user_meta( $user_id, 'billing_first_name', wp_slash( $first_name ) );
		}
		if ( ! empty( $last_name ) ) {
			update_user_meta( $user_id, 'billing_last_name', wp_slash( $last_name ) );
		}

		update_user_meta( $user_id, 'ashna_registered_via_otp', 1 );

		if ( $woocommerce ) {
			// Lets WooCommerce (new-account e-mail) and its extensions treat the account as a customer sign-up.
			do_action( 'woocommerce_created_customer', $user_id, $userdata, true );
		}

		do_action( 'ashna_otp_user_registered', $user_id, $identifier, $type, $extra );

		return get_user_by( 'id', $user_id );
	}

	/**
	 * Role for accounts created by Ashna. Roles with staff capabilities are refused even if
	 * selected by mistake (or injected through a settings import).
	 *
	 * @param string $role Requested role.
	 * @return string
	 */
	public static function safe_registration_role( $role ) {
		$roles = wp_roles();
		$role  = sanitize_key( (string) $role );
		if ( 'customer' === $role && ! $roles->is_role( 'customer' ) ) {
			$role = sanitize_key( (string) get_option( 'default_role', 'subscriber' ) );
		}

		$role = (string) apply_filters( 'ashna_otp_registration_role', $role );

		$dangerous = array( 'manage_options', 'edit_users', 'create_users', 'promote_users', 'delete_users', 'activate_plugins', 'install_plugins', 'edit_plugins', 'edit_theme_options', 'manage_woocommerce', 'edit_others_posts', 'unfiltered_html', 'manage_network' );
		$role_obj  = $roles->get_role( $role );
		$is_safe   = (bool) $role_obj;
		if ( $role_obj ) {
			foreach ( $dangerous as $cap ) {
				if ( $role_obj->has_cap( $cap ) ) {
					$is_safe = false;
					break;
				}
			}
		}

		if ( $is_safe ) {
			return $role;
		}
		return $roles->is_role( 'customer' ) ? 'customer' : 'subscriber';
	}
}
// phpcs:enable WordPress.Security.NonceVerification.Missing


// ---- Source: includes/services/class-ashna-frontend.php ----
/**
 * Frontend Shortcodes, Assets, Global Modal & Full wp-login.php Replacement
 *
 * @package Ashna
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Ashna_Frontend {

	/**
	 * Singleton instance
	 *
	 * @var Ashna_Frontend|null
	 */
	private static $instance = null;

	/**
	 * Track if inline custom CSS was already attached
	 *
	 * @var bool
	 */
	private static $inline_css_added = false;

	/**
	 * Get instance
	 *
	 * @return Ashna_Frontend
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor
	 */
	private function __construct() {
		add_shortcode( 'ashna_otp_login', array( $this, 'shortcode_login_form' ) );
		add_shortcode( 'ashna_otp_form', array( $this, 'shortcode_login_form' ) );
		add_shortcode( 'ashna_otp_button', array( $this, 'shortcode_modal_button' ) );

		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );
		add_action( 'wp_footer', array( $this, 'render_global_modal' ) );
		add_action( 'template_redirect', array( $this, 'maybe_render_standalone_page' ), 1 );

		// Recovery: define( 'ASHNA_DISABLE_LOGIN_TAKEOVER', true ); in wp-config.php restores the classic page.
		if ( Ashna_Auth::login_takeover_active() ) {
			add_action( 'login_init', array( $this, 'intercept_wp_login_page' ), 1 );
		}
	}

	/**
	 * Enqueue frontend CSS and JS with smart conditional loading
	 *
	 * @param bool $force Force enqueueing guest-only scripts (e.g. inside Elementor editor).
	 */
	public function enqueue_assets( $force = false ) {
		// Vazirmatn and Estedad ship with the plugin (no CDN: jsDelivr is slow or filtered for many
		// Iranian visitors, and a blocked stylesheet in <head> delays the whole page).
		wp_enqueue_style(
			'ashna-fonts',
			ASHNA_OTP_URL . 'assets/css/fonts.css',
			array(),
			ASHNA_OTP_VERSION
		);

		$css_ver = ASHNA_OTP_VERSION . '.' . ( file_exists( ASHNA_OTP_PATH . 'assets/css/frontend.css' ) ? filemtime( ASHNA_OTP_PATH . 'assets/css/frontend.css' ) : '1' );
		$js_ver  = ASHNA_OTP_VERSION . '.' . ( file_exists( ASHNA_OTP_PATH . 'assets/js/frontend.js' ) ? filemtime( ASHNA_OTP_PATH . 'assets/js/frontend.js' ) : '1' );

		wp_enqueue_style(
			'ashna-otp-frontend',
			ASHNA_OTP_URL . 'assets/css/frontend.css',
			array( 'ashna-fonts' ),
			$css_ver
		);

		if ( ! self::$inline_css_added ) {
			$custom_css = trim( (string) Ashna_Helper::get_option( 'custom_css', '' ) );
			if ( ! empty( $custom_css ) ) {
				wp_add_inline_style( 'ashna-otp-frontend', wp_strip_all_tags( $custom_css ) );
			}
			self::$inline_css_added = true;
		}

		// Performance Optimization: Skip heavy 3rd-party Captcha SDKs & OTP JS for already logged-in users unless forced
		if ( is_user_logged_in() && ! $force ) {
			return;
		}

		$captcha_type = Ashna_Helper::get_option( 'captcha_type', 'none' );
		$site_key     = trim( (string) Ashna_Helper::get_option( 'captcha_site_key', '' ) );

		if ( ! is_user_logged_in() ) {
			if ( 'arcaptcha' === $captcha_type && ! empty( $site_key ) ) {
				wp_enqueue_script( 'ashna-arcaptcha', 'https://widget.arcaptcha.ir/1/api.js', array(), null, true ); // phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion
			} elseif ( 'turnstile' === $captcha_type && ! empty( $site_key ) ) {
				wp_enqueue_script( 'ashna-turnstile', 'https://challenges.cloudflare.com/turnstile/v0/api.js', array(), null, true ); // phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion
			} elseif ( 'recaptcha_v3' === $captcha_type && ! empty( $site_key ) ) {
				wp_enqueue_script( 'ashna-recaptcha', 'https://www.google.com/recaptcha/api.js?render=' . rawurlencode( $site_key ), array(), null, true ); // phpcs:ignore WordPress.WP.EnqueuedResourceParameters.MissingVersion
			}
		}

		wp_enqueue_script(
			'ashna-otp-frontend',
			ASHNA_OTP_URL . 'assets/js/frontend.js',
			array( 'jquery' ),
			$js_ver,
			true
		);

		// The failover hint is only read by the script when a backup path exists (frontend.js), so a
		// site with one gateway never has to load the circuit-breaker state on a page view.
		$has_fallback = Ashna_Gateway_Manager::has_fallback();
		$hint_ms      = 0;
		if ( $has_fallback ) {
			$hint_ms = (int) ( Ashna_Failover::slot_for( Ashna_Gateway_Manager::first_mobile_gateway()->get_id() ) * 1000 ) + 300;
		}

		wp_localize_script(
			'ashna-otp-frontend',
			'ashnaOtpParams',
			array(
				'ajaxUrl'        => admin_url( 'admin-ajax.php' ),
				'nonce'          => wp_create_nonce( Ashna_Session::NONCE_ACTION ),
				// Session freshness: pages may come from a cache or the back/forward cache.
				'loggedIn'       => is_user_logged_in(),
				'renderedAt'     => time(),
				'otpLength'      => absint( Ashna_Helper::get_option( 'otp_length', 5 ) ),
				'captchaType'    => $captcha_type,
				'captchaSiteKey' => $site_key,
				// Fast-failover UX: progressive status while the code is on its way.
				'slowHintMs'     => 2500,
				'failoverHintMs' => $hint_ms,
				'sendTimeoutMs'  => (int) ( ( Ashna_Failover::total_budget() + 10 ) * 1000 ),
				'hasFallback'    => $has_fallback,
				'i18n'           => array(
					'networkError'    => 'خطا در برقراری ارتباط با سرور. لطفاً اتصال اینترنت خود را بررسی کنید.',
					'sending'         => 'در حال ارسال...',
					'verifying'       => 'در حال بررسی...',
					'slowSending'     => 'در حال ارسال کد… چند لحظه صبر کنید.',
					'failoverSending' => 'مسیر اصلی دیر پاسخ داد؛ در حال ارسال از مسیر پشتیبان…',
					'sendTimeout'     => 'ارسال کد بیش از حد معمول طول کشید. لطفاً چند لحظه بعد دوباره تلاش کنید.',
				),
			)
		);
	}

	/**
	 * Render dedicated Standalone Full-Page Canvas when visiting the configured standalone_page_id
	 */
	public function maybe_render_standalone_page() {
		$standalone_page_id = absint( Ashna_Helper::get_option( 'standalone_page_id', 0 ) );
		if ( $standalone_page_id <= 0 || ! is_page( $standalone_page_id ) ) {
			return;
		}

		// Allow Elementor editor or page builders to edit if needed
		if ( isset( $_GET['elementor-preview'] ) || is_customize_preview() ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}

		if ( is_user_logged_in() ) {
			$account_url = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : home_url( '/' );
			wp_safe_redirect( $account_url );
			exit;
		}

		$redirect_to = isset( $_REQUEST['redirect_to'] ) ? esc_url_raw( Ashna_Helper::as_string( wp_unslash( $_REQUEST['redirect_to'] ) ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$this->render_standalone_canvas( $redirect_to, 'standalone-page' );
	}

	/**
	 * Completely replace default wp-login.php form when wp_login_integration is active
	 */
	public function intercept_wp_login_page() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$action = isset( $_REQUEST['action'] ) ? sanitize_key( Ashna_Helper::as_string( wp_unslash( $_REQUEST['action'] ) ) ) : 'login';

		$passthrough_actions = array( 'logout', 'lostpassword', 'retrievepassword', 'resetpass', 'rp', 'postpass', 'confirmaction', 'confirm_admin_email' );
		if ( in_array( $action, $passthrough_actions, true ) || isset( $_REQUEST['interim-login'] ) ) {
			return;
		}

		if ( is_user_logged_in() ) {
			$redirect_to = isset( $_REQUEST['redirect_to'] ) ? esc_url_raw( Ashna_Helper::as_string( wp_unslash( $_REQUEST['redirect_to'] ) ) ) : admin_url();
			wp_safe_redirect( $redirect_to );
			exit;
		}

		$redirect_to = isset( $_REQUEST['redirect_to'] ) ? esc_url_raw( Ashna_Helper::as_string( wp_unslash( $_REQUEST['redirect_to'] ) ) ) : '';
		// phpcs:enable

		$this->render_standalone_canvas( $redirect_to, 'wp-login' );
	}

	/**
	 * Output Full-Page Standalone Canvas HTML without theme header/footer
	 *
	 * @param string $redirect_to Redirect URL after login.
	 * @param string $context     Context identifier.
	 */
	private function render_standalone_canvas( $redirect_to = '', $context = 'wp-login' ) {
		$this->enqueue_assets( true );

		$primary_color   = Ashna_Helper::get_option( 'primary_color', '#2563eb' );
		$secondary_color = Ashna_Helper::get_option( 'secondary_color', '#4f46e5' );
		$card_position   = Ashna_Helper::get_option( 'card_position', 'center' );
		$bg_style        = Ashna_Helper::get_option( 'canvas_bg_style', 'mesh_light' );
		$bg_color        = Ashna_Helper::get_option( 'canvas_bg_color', '#f1f5f9' );
		$bg_image        = trim( (string) Ashna_Helper::get_option( 'canvas_bg_image', '' ) );
		$bg_pattern      = Ashna_Helper::get_option( 'bg_pattern', 'none' );
		$show_back_link  = (bool) Ashna_Helper::get_option( 'canvas_show_back_link', 1 );

		if ( 'mesh_dark' === $bg_style ) {
			$base_bg        = 'radial-gradient(circle at top right, #1e1b4b 0%, #0f172a 58%, #020617 100%)';
			$back_link_dark = true;
		} elseif ( 'brand_gradient' === $bg_style ) {
			$base_bg        = sprintf( 'radial-gradient(circle at top right, %1$s28 0%%, #f8fafc 58%%, %2$s1a 100%%)', esc_attr( $primary_color ), esc_attr( $secondary_color ) );
			$back_link_dark = false;
		} elseif ( 'custom_image' === $bg_style && ! empty( $bg_image ) ) {
			$base_bg        = sprintf( 'linear-gradient(rgba(15, 23, 42, 0.45), rgba(15, 23, 42, 0.45)), url(%s) center/cover no-repeat fixed', esc_url( $bg_image ) );
			$back_link_dark = true;
		} elseif ( 'solid' === $bg_style ) {
			$base_bg        = esc_attr( $bg_color );
			$back_link_dark = false;
		} else {
			$base_bg        = sprintf( 'radial-gradient(circle at top right, #e0e7ff 0%%, #f8fafc 55%%, %s 100%%)', esc_attr( $bg_color ) );
			$back_link_dark = false;
		}

		$pattern_layer = '';
		$pattern_size  = '';
		if ( 'dots' === $bg_pattern ) {
			$pattern_layer = 'radial-gradient(rgba(99, 102, 241, 0.22) 1.3px, transparent 1.3px), ';
			$pattern_size  = 'background-size: 20px 20px, auto;';
		} elseif ( 'grid' === $bg_pattern ) {
			$pattern_layer = 'linear-gradient(to right, rgba(148, 163, 184, 0.16) 1px, transparent 1px), linear-gradient(to bottom, rgba(148, 163, 184, 0.16) 1px, transparent 1px), ';
			$pattern_size  = 'background-size: 26px 26px, 26px 26px, auto;';
		} elseif ( 'waves' === $bg_pattern ) {
			$pattern_layer = 'repeating-radial-gradient(circle at 0 0, transparent 0, rgba(99, 102, 241, 0.065) 14px, transparent 28px), ';
		} elseif ( 'geometric' === $bg_pattern ) {
			$pattern_layer = 'linear-gradient(30deg, rgba(99, 102, 241, 0.075) 12%, transparent 12.5%, transparent 87%, rgba(99, 102, 241, 0.075) 87.5%), ';
			$pattern_size  = 'background-size: 32px 56px, auto;';
		}

		$canvas_bg_css = sprintf( 'background: %s%s; %s', $pattern_layer, $base_bg, $pattern_size );

		$align_items = 'center';
		if ( 'right' === $card_position ) {
			$align_items = 'flex-start';
		} elseif ( 'left' === $card_position ) {
			$align_items = 'flex-end';
		}

		status_header( 200 );
		nocache_headers();
		?>
		<!DOCTYPE html>
		<html <?php language_attributes(); ?> dir="rtl">
		<head>
			<meta charset="<?php bloginfo( 'charset' ); ?>">
			<meta name="viewport" content="width=device-width, initial-scale=1.0">
			<title><?php echo esc_html( get_bloginfo( 'name' ) . ' — ورود / ثبت‌نام' ); ?></title>
			<?php wp_print_styles( array( 'ashna-fonts', 'ashna-otp-frontend' ) ); ?>
			<style>
				body.ashna-standalone-login {
					margin: 0;
					padding: 32px 5vw;
					min-height: 100vh;
					display: flex;
					flex-direction: column;
					align-items: <?php echo esc_attr( $align_items ); ?>;
					justify-content: center;
					<?php echo $canvas_bg_css; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					font-family: 'Vazirmatn', Tahoma, sans-serif;
					direction: rtl;
					box-sizing: border-box;
				}
				.ashna-standalone-login .ashna-otp-wrapper {
					width: 100%;
					margin: 0;
				}
				.ashna-back-to-site {
					margin-top: 22px;
					text-align: center;
				}
				.ashna-back-to-site a {
					display: inline-flex;
					align-items: center;
					gap: 6px;
					padding: 8px 16px;
					border-radius: 99px;
					background: <?php echo $back_link_dark ? 'rgba(255,255,255,0.12)' : 'rgba(255,255,255,0.75)'; ?>;
					backdrop-filter: blur(8px);
					color: <?php echo $back_link_dark ? '#f8fafc' : '#475569'; ?>;
					text-decoration: none;
					font-size: 13px;
					font-weight: 600;
					border: 1px solid <?php echo $back_link_dark ? 'rgba(255,255,255,0.18)' : 'rgba(148,163,184,0.28)'; ?>;
					transition: all 0.2s ease;
				}
				.ashna-back-to-site a:hover {
					transform: translateY(-1px);
					background: <?php echo $back_link_dark ? 'rgba(255,255,255,0.2)' : '#ffffff'; ?>;
				}
			</style>
		</head>
		<body class="ashna-standalone-login">
			<?php
			$form_html = self::get_login_form_html(
				array(
					'redirect' => $redirect_to,
					'context'  => $context,
				)
			);
			echo $form_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- escaped inside templates/login-form.php.
			?>
			<?php if ( $show_back_link ) : ?>
				<div class="ashna-back-to-site">
					<a href="<?php echo esc_url( home_url( '/' ) ); ?>">&rarr; بازگشت به <?php echo esc_html( get_bloginfo( 'name' ) ); ?></a>
				</div>
			<?php endif; ?>
			<?php wp_print_scripts( array( 'jquery', 'ashna-arcaptcha', 'ashna-turnstile', 'ashna-recaptcha', 'ashna-otp-frontend' ) ); ?>
		</body>
		</html>
		<?php
		exit;
	}

	/**
	 * Render login form template (can be overridden in theme/ashna/login-form.php)
	 *
	 * @param array $args Template arguments.
	 * @return string
	 */
	public static function get_login_form_html( $args = array() ) {
		$defaults = array(
			'title'              => Ashna_Helper::get_option( 'form_title', 'ورود / ثبت‌نام' ),
			'subtitle'           => Ashna_Helper::get_option( 'form_subtitle', 'برای ادامه، شماره موبایل یا ایمیل خود را وارد کنید.' ),
			'button_text'        => '',
			'verify_button_text' => '',
			'redirect'           => '',
			'primary_color'      => '',
			'card_bg_color'      => '',
			'text_color'         => '',
			'digit_box_style'    => '',
			'border_radius'      => null,
			'max_width'          => null,
			'form_layout'        => '',
			'card_position'      => '',
			'context'            => 'shortcode',
			'vendor_mode'        => '',
		);
		$args     = wp_parse_args( $args, $defaults );

		ob_start();
		$theme_template = locate_template( 'ashna/login-form.php' );
		if ( $theme_template ) {
			include plugin_dir_path( $theme_template ) . basename( $theme_template );
		} else {
			include __DIR__ . '/../templates/login-form.php';
		}
		return ob_get_clean();
	}

	/**
	 * Shortcode: [ashna_otp_login]
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string
	 */
	public function shortcode_login_form( $atts ) {
		$atts = shortcode_atts(
			array(
				'title'          => '',
				'subtitle'       => '',
				'button_text'    => '',
				'redirect'       => '',
				'primary_color'  => '',
				'layout'         => '',
				'position'       => '',
				'show_if_logged' => 'no',
				'vendor'         => '', // "yes": dedicated Dokan vendor sign-up form
			),
			$atts,
			'ashna_otp_login'
		);

		if ( is_user_logged_in() && 'yes' !== $atts['show_if_logged'] ) {
			$user         = wp_get_current_user();
			$account_link = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : admin_url( 'profile.php' );
			$logout_link  = wp_logout_url( home_url( '/' ) );

			return sprintf(
				'<div class="ashna-otp-wrapper" dir="rtl"><div class="ashna-otp-card ashna-logged-in-box"><p>سلام <strong>%s</strong>، شما وارد حساب کاربری خود شده‌اید.</p><div class="ashna-logged-actions"><a href="%s" class="ashna-btn ashna-btn-primary">حساب کاربری</a><a href="%s" class="ashna-btn ashna-btn-outline">خروج</a></div></div></div>',
				esc_html( $user->display_name ),
				esc_url( $account_link ),
				esc_url( $logout_link )
			);
		}

		$this->enqueue_assets( true );

		return self::get_login_form_html(
			array(
				'title'         => $atts['title'],
				'subtitle'      => $atts['subtitle'],
				'button_text'   => $atts['button_text'],
				'redirect'      => $atts['redirect'],
				'primary_color' => $atts['primary_color'],
				'form_layout'   => $atts['layout'],
				'card_position' => $atts['position'],
				'context'       => 'yes' === $atts['vendor'] ? 'vendor-signup' : 'shortcode',
				'vendor_mode'   => 'yes' === $atts['vendor'] ? 'only' : '',
			)
		);
	}

	/**
	 * Shortcode: [ashna_otp_button text="ورود / ثبت‌نام"]
	 *
	 * @param array $atts Shortcode attributes.
	 * @return string
	 */
	public function shortcode_modal_button( $atts ) {
		$atts = shortcode_atts(
			array(
				'text'           => 'ورود / ثبت‌نام',
				'logged_in_text' => 'حساب کاربری',
				'class'          => '',
			),
			$atts,
			'ashna_otp_button'
		);

		$primary_color = Ashna_Helper::get_option( 'primary_color', '#2563eb' );

		if ( is_user_logged_in() ) {
			$account_url = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : admin_url( 'profile.php' );
			return sprintf(
				'<a href="%s" class="ashna-trigger-btn %s" style="--ashna-primary:%s;">%s</a>',
				esc_url( $account_url ),
				esc_attr( $atts['class'] ),
				esc_attr( $primary_color ),
				esc_html( $atts['logged_in_text'] )
			);
		}

		$this->enqueue_assets( true );

		return sprintf(
			'<button type="button" class="ashna-trigger-btn ashna-open-modal %s" style="--ashna-primary:%s;">%s</button>',
			esc_attr( $atts['class'] ),
			esc_attr( $primary_color ),
			esc_html( $atts['text'] )
		);
	}

	/**
	 * Render global modal popup / slide-over drawer in footer for guests
	 */
	public function render_global_modal() {
		if ( is_user_logged_in() || ! Ashna_Helper::get_option( 'enable_global_modal', 1 ) ) {
			return;
		}

		$modal_style  = Ashna_Helper::get_option( 'modal_style', 'center' );
		$mobile_sheet = (bool) Ashna_Helper::get_option( 'modal_mobile_sheet', 1 );
		$modal_cls    = 'ashna-modal-overlay ashna-modal-style-' . sanitize_html_class( $modal_style );
		if ( $mobile_sheet ) {
			$modal_cls .= ' ashna-modal-mobile-sheet';
		}
		?>
		<div id="ashna-otp-modal" class="<?php echo esc_attr( $modal_cls ); ?>" aria-hidden="true" style="display:none;">
			<div class="ashna-modal-dialog" role="dialog" aria-modal="true">
				<div class="ashna-modal-sheet-handle" aria-hidden="true"></div>
				<button type="button" class="ashna-modal-close" aria-label="بستن">&times;</button>
				<?php
				// phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				echo self::get_login_form_html( array( 'context' => 'modal' ) );
				?>
			</div>
		</div>
		<?php
	}
}


// ---- Source: includes/services/class-ashna-sso.php ----
/**
 * Social sign-in (OpenID Connect) for Google and Telegram.
 *
 * Design: docs/sso-design-FA.md. Two rules drive everything here:
 *   1. An account is only ever linked to a social identity after the provider proves the
 *      identity (a verified e-mail claim, a verified phone claim, or the opaque `sub` that was
 *      already bound to that account). A typed-in value never links anything.
 *   2. Every sign-in goes through Ashna_Session::login(), so the session, the 2FA/ban gates and
 *      the WooCommerce/Dokan redirects behave exactly like the OTP path.
 *
 * @package Ashna
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Ashna_SSO {

	/**
	 * Query flag that starts and finishes the flow.
	 */
	const ROUTE = 'ashna_sso';

	/**
	 * Cookie that binds a callback to the browser that started it (login-CSRF protection).
	 */
	const BIND_COOKIE = 'ashna_sso_bind';

	/**
	 * How long a started sign-in stays valid, in seconds.
	 */
	const STATE_TTL = 600;

	/**
	 * Path (relative to the site root) the providers return to.
	 *
	 * It carries no query string on purpose: Google rejects a redirect URI that has one, and
	 * Telegram requires the exact value to be registered. Each provider gets its own leaf
	 * (`/google/`, `/telegram/`) so the settings screen can show one unmistakable address per
	 * console, and so a callback sent to the wrong provider is refused instead of silently
	 * resolved from the state. The bare path stays valid for sites that registered it before.
	 */
	const CALLBACK_PATH = 'ashna-sso/callback';

	/**
	 * Wire the routes and the admin-ajax endpoints.
	 */
	public static function init() {
		add_action( 'init', array( __CLASS__, 'handle_route' ), 1 );
		add_action( 'wp_ajax_ashna_sso_phone_start', array( __CLASS__, 'ajax_phone_start' ) );
		add_action( 'wp_ajax_ashna_sso_phone_verify', array( __CLASS__, 'ajax_phone_verify' ) );
		add_action( 'wp_ajax_ashna_sso_phone_dismiss', array( __CLASS__, 'ajax_phone_dismiss' ) );
		add_action( 'wp_footer', array( __CLASS__, 'render_phone_prompt' ), 5 );
	}

	/**
	 * Table that maps a provider identity to a WordPress user.
	 *
	 * @return string
	 */
	public static function table_name() {
		global $wpdb;
		return $wpdb->prefix . 'ashna_sso_identities';
	}

	/**
	 * Supported providers.
	 *
	 * @return array<string, array<string, mixed>>
	 */
	public static function providers() {
		return array(
			'google'   => array(
				'label'    => 'گوگل',
				'icon'     => 'google',
				'discovery' => 'https://accounts.google.com/.well-known/openid-configuration',
				'issuer'   => 'https://accounts.google.com',
				'scopes'   => 'openid email profile',
				'email'    => true,
				'phone'    => false,
			),
			'telegram' => array(
				'label'    => 'تلگرام',
				'icon'     => 'telegram',
				'discovery' => 'https://oauth.telegram.org/.well-known/openid-configuration',
				'issuer'   => 'https://oauth.telegram.org',
				'scopes'   => 'openid profile phone',
				'email'    => false,
				'phone'    => true,
			),
		);
	}

	/**
	 * Settings key holding one value of a provider.
	 *
	 * @param string $provider Provider id.
	 * @param string $field    enabled|client_id|client_secret.
	 * @return string
	 */
	private static function setting_key( $provider, $field ) {
		return 'sso_' . $provider . '_' . $field;
	}

	/**
	 * A single provider setting.
	 *
	 * @param string $provider Provider id.
	 * @param string $field    enabled|client_id|client_secret.
	 * @param mixed  $default  Fallback.
	 * @return mixed
	 */
	public static function setting( $provider, $field, $default = '' ) {
		return Ashna_Helper::get_option( self::setting_key( $provider, $field ), $default );
	}

	/**
	 * Is the provider switched on and fully configured?
	 *
	 * @param string $provider Provider id.
	 * @return bool
	 */
	public static function is_ready( $provider ) {
		$providers = self::providers();
		if ( ! isset( $providers[ $provider ] ) ) {
			return false;
		}
		if ( ! Ashna_Helper::get_option( self::setting_key( $provider, 'enabled' ), 0 ) ) {
			return false;
		}
		$id     = trim( (string) self::setting( $provider, 'client_id' ) );
		$secret = (string) self::setting( $provider, 'client_secret' );

		return '' !== $id && '' !== $secret;
	}

	/**
	 * Shape problems that would make a saved credential pair fail at the provider.
	 *
	 * Empty means "nothing obviously wrong"; the provider stays the authority on the pair.
	 * Messages are shown under the matching field, so they name the field and the fix.
	 *
	 * @param string      $provider Provider id.
	 * @param string|null $client_id Client id to check (defaults to the saved one).
	 * @param string|null $client_secret Secret to check (defaults to the saved one).
	 * @return array<string, string> Field => message.
	 */
	public static function credential_warnings( $provider, $client_id = null, $client_secret = null ) {
		$providers = self::providers();
		$warnings  = array();
		if ( ! isset( $providers[ $provider ] ) ) {
			return array( 'client_id' => 'ارائه‌دهنده ناشناخته است.' );
		}

		if ( null === $client_id ) {
			$client_id = (string) self::setting( $provider, 'client_id' );
		}
		if ( null === $client_secret ) {
			$client_secret = (string) self::setting( $provider, 'client_secret' );
		}
		$client_id     = trim( (string) $client_id );
		$client_secret = trim( (string) $client_secret );

		if ( '' === $client_id ) {
			$warnings['client_id'] = 'Client ID را از پنل ارائه‌دهنده کپی کنید.';
		} elseif ( 'google' === $provider ) {
			if ( false === stripos( $client_id, '.apps.googleusercontent.com' ) ) {
				$warnings['client_id'] = 'Client ID گوگل با یک عدد و سپس «-…apps.googleusercontent.com» تمام می‌شود؛ این مقدار شبیه شناسهٔ گوگل نیست.';
			}
		} elseif ( ! preg_match( '/^[0-9]{5,20}$/', $client_id ) ) {
			$warnings['client_id'] = 'Client ID تلگرام همان شناسهٔ عددی بات است (مثلاً 8819388185)؛ حرف یا علامت ندارد.';
		}

		if ( '' === $client_secret ) {
			$warnings['client_secret'] = 'Client Secret را وارد کنید؛ بدون آن تبادل کد انجام نمی‌شود.';
		} elseif ( 'telegram' === $provider && preg_match( '/^[0-9]{5,20}:[A-Za-z0-9_-]{20,}$/', $client_secret ) ) {
			$warnings['client_secret'] = 'این مقدار توکن بات است، نه Client Secret. توکن بات در BotFather → API Token است و فقط برای ارسال پیام به کار می‌رود؛ Secret را از Bot Settings → Web Login بردارید.';
		}

		return $warnings;
	}

	/**
	 * Coarse state used by the settings screen.
	 *
	 * @param string $provider Provider id.
	 * @return string off|incomplete|check|ready
	 */
	public static function provider_state( $provider ) {
		if ( ! Ashna_Helper::get_option( self::setting_key( $provider, 'enabled' ), 0 ) ) {
			return 'off';
		}
		if ( ! self::is_ready( $provider ) ) {
			return 'incomplete';
		}
		return self::credential_warnings( $provider ) ? 'check' : 'ready';
	}

	/**
	 * Live configuration check for the settings screen (no secret ever leaves the site).
	 *
	 * @param string $provider Provider id.
	 * @return array|WP_Error {provider, state, checks: array<{key,label,status,text}>, redirect_uri}
	 */
	public static function check_connection( $provider ) {
		$providers = self::providers();
		if ( ! isset( $providers[ $provider ] ) ) {
			return new WP_Error( 'ashna_sso_unknown', 'ارائه‌دهنده ناشناخته است.' );
		}

		$client_id     = trim( (string) self::setting( $provider, 'client_id' ) );
		$client_secret = (string) self::setting( $provider, 'client_secret' );
		$warnings      = self::credential_warnings( $provider, $client_id, $client_secret );
		$checks        = array();

		$checks[] = array(
			'key'    => 'client_id',
			'label'  => 'قالب Client ID',
			'status' => isset( $warnings['client_id'] ) ? 'error' : 'ok',
			'text'   => isset( $warnings['client_id'] ) ? $warnings['client_id'] : 'قالب شناسه درست است.',
		);
		$checks[] = array(
			'key'    => 'client_secret',
			'label'  => 'Client Secret',
			'status' => isset( $warnings['client_secret'] ) ? 'error' : 'ok',
			'text'   => isset( $warnings['client_secret'] ) ? $warnings['client_secret'] : 'Secret ذخیره شده است.',
		);

		$document = self::http_get( $providers[ $provider ]['discovery'], 12 );
		if ( is_wp_error( $document ) || ! is_array( $document ) ) {
			$checks[] = array(
				'key'    => 'discovery',
				'label'  => 'ارتباط با سرور ' . $providers[ $provider ]['label'],
				'status' => 'error',
				'text'   => 'پاسخ نداد. اتصال خروجی هاست را بررسی کنید (firewall یا DNS).',
			);
		} else {
			$missing = array();
			foreach ( array( 'issuer', 'authorization_endpoint', 'token_endpoint', 'jwks_uri' ) as $field ) {
				if ( empty( $document[ $field ] ) ) {
					$missing[] = $field;
				}
			}
			if ( $missing ) {
				$checks[] = array(
					'key'    => 'discovery',
					'label'  => 'نسخهٔ OIDC ارائه‌دهنده',
					'status' => 'error',
					'text'   => 'سند کشف ناقص است: ' . implode( '، ', $missing ),
				);
			} else {
				$issuer_ok = untrailingslashit( (string) $document['issuer'] ) === untrailingslashit( $providers[ $provider ]['issuer'] );
				$checks[]  = array(
					'key'    => 'discovery',
					'label'  => 'ارتباط با سرور ' . $providers[ $provider ]['label'],
					'status' => $issuer_ok ? 'ok' : 'warn',
					'text'   => $issuer_ok
						? 'پاسخ گرفت و نشانی‌ها خوانده شد.'
						: 'پاسخ آمد، اما Issuer با مقدار مورد انتظار یکی نیست: ' . (string) $document['issuer'],
				);
			}
		}

		if ( ! is_ssl() && 0 !== strpos( (string) home_url(), 'https://' ) ) {
			$host     = (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST );
			$is_local = in_array( $host, array( 'localhost', '127.0.0.1', '::1' ), true ) || substr( $host, -6 ) === '.local';
			if ( ! $is_local ) {
				$checks[] = array(
					'key'    => 'https',
					'label'  => 'HTTPS',
					'status' => 'warn',
					'text'   => 'دامنهٔ سایت HTTPS نیست؛ گوگل و تلگرام برای دامنهٔ واقعی آدرس https می‌خواهند.',
				);
			}
		}

		$state = 'ready';
		foreach ( $checks as $check ) {
			if ( 'error' === $check['status'] ) {
				$state = 'incomplete';
				break;
			}
			if ( 'warn' === $check['status'] ) {
				$state = 'check';
			}
		}

		return array(
			'provider'    => $provider,
			'state'       => $state,
			'checks'      => $checks,
			'redirect_uri' => self::redirect_uri( $provider ),
		);
	}

	/**
	 * Providers a visitor can actually use right now.
	 *
	 * @return array<string, array<string, mixed>>
	 */
	public static function enabled_providers() {
		$out = array();
		foreach ( self::providers() as $id => $provider ) {
			if ( self::is_ready( $id ) ) {
				$out[ $id ] = $provider;
			}
		}
		return $out;
	}

	/**
	 * The callback URL to register at the provider (also shown in the settings screen).
	 *
	 * @param string $provider Provider id. Empty keeps the legacy shared address.
	 * @return string
	 */
	public static function redirect_uri( $provider = '' ) {
		$providers = self::providers();
		$leaf      = isset( $providers[ $provider ] ) ? '/' . $provider : '';
		return home_url( '/' . self::CALLBACK_PATH . $leaf . '/' );
	}

	/**
	 * Which provider a callback request belongs to.
	 *
	 * Checked before WordPress resolves the query, so the flow works with any permalink
	 * structure and never reaches the 404 template.
	 *
	 * @return string|null Provider id, '' for the legacy shared path, null when not a callback.
	 */
	private static function callback_provider() {
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
		if ( '' === $uri || false === strpos( $uri, 'ashna-sso' ) ) {
			return null;
		}

		$path = (string) wp_parse_url( $uri, PHP_URL_PATH );
		$home = (string) wp_parse_url( home_url( '/' ), PHP_URL_PATH );
		$path = '/' . trim( $path, '/' );
		$home = '/' . trim( $home, '/' );

		if ( '/' !== $home ) {
			if ( 0 !== strpos( $path, $home ) ) {
				return null;
			}
			$path = substr( $path, strlen( $home ) );
		}

		$path = '/' . trim( $path, '/' );
		$base = '/' . self::CALLBACK_PATH;
		if ( $path === $base ) {
			return '';
		}
		if ( 0 !== strpos( $path, $base . '/' ) ) {
			return null;
		}

		$leaf      = trim( substr( $path, strlen( $base ) ), '/' );
		$providers = self::providers();
		return isset( $providers[ $leaf ] ) ? $leaf : null;
	}

	/**
	 * Is this request the provider returning to the callback path?
	 *
	 * @return bool
	 */
	private static function is_callback_request() {
		return null !== self::callback_provider();
	}

	/**
	 * Which provider a state belongs to, without consuming the state.
	 *
	 * @param string $state State from the query string.
	 * @return string Provider id, or '' when the state is unknown.
	 */
	public static function provider_for_state( $state ) {
		$state = preg_replace( '/[^a-f0-9]/', '', (string) $state );
		if ( '' === $state || 64 !== strlen( $state ) ) {
			return '';
		}
		$stored = get_transient( self::state_key( $state ) );
		return ( is_array( $stored ) && ! empty( $stored['provider'] ) ) ? (string) $stored['provider'] : '';
	}

	/**
	 * Where a login button points. Cheap on purpose: no HTTP, no database write. The state is
	 * created on the `start` request only.
	 *
	 * @param string $provider    Provider id.
	 * @param string $redirect_to Destination after a successful sign-in.
	 * @return string
	 */
	public static function start_url( $provider, $redirect_to = '' ) {
		$args = array(
			self::ROUTE => 'start',
			'provider'  => $provider,
		);
		if ( '' !== $redirect_to ) {
			$args['redirect_to'] = $redirect_to;
		}
		return add_query_arg( $args, home_url( '/' ) );
	}

	/**
	 * Human message for an error code (never leaks provider internals).
	 *
	 * @param string $code Error code.
	 * @return string
	 */
	public static function message_for( $code ) {
		$messages = array(
			'ashna_sso_disabled'    => 'این روش ورود در حال حاضر فعال نیست.',
			'ashna_sso_not_ready'   => 'ورود با این سرویس هنوز در تنظیمات کامل نشده است.',
			'ashna_sso_state'       => 'زمان ورود به پایان رسید یا نشست مرورگر عوض شد. لطفاً دوباره تلاش کنید.',
			'ashna_sso_browser'     => 'این ورود از مرورگر دیگری آغاز شده بود. لطفاً از همان مرورگر ادامه دهید.',
			'ashna_sso_denied'      => 'ورود در صفحهٔ سرویس لغو شد.',
			'ashna_sso_redirect'    => 'آدرس بازگشتی ثبت‌شده در پنل ارائه‌دهنده با آدرس سایت یکی نیست. آدرس دقیق را از تنظیمات «ورود با گوگل و تلگرام» کپی و در همان پنل جایگزین کنید.',
			'ashna_sso_client'      => 'شناسه یا کلید محرمانهٔ این سرویس پذیرفته نشد. Client ID و Client Secret را دوباره از پنل بردارید و ذخیره کنید.',
			'ashna_sso_network'     => 'ارتباط با سرویس ورود برقرار نشد. چند لحظه بعد دوباره تلاش کنید.',
			'ashna_sso_token'       => 'پاسخ سرویس ورود معتبر نبود. لطفاً دوباره تلاش کنید.',
			'ashna_sso_email'       => 'سرویس ورود ایمیلی برنگرداند که قابل استفاده باشد.',
			'ashna_sso_unverified'  => 'ایمیل حساب شما در سرویس ورود تأیید نشده است؛ برای امنیت، ورود انجام نشد.',
			'ashna_sso_phone_taken' => 'این شماره روی حساب دیگری ثبت شده است. اول با همان شماره و کد پیامکی وارد شوید؛ از دفعهٔ بعد، ورود با تلگرام به همان حساب وصل می‌شود.',
			'ashna_sso_staff'       => 'حساب‌های مدیریتی فقط با رمز عبور وارد می‌شوند.',
			'ashna_sso_blocked'     => 'ورود این حساب در حال حاضر مجاز نیست.',
			'ashna_sso_rate'        => 'تلاش‌های ورود بیش از حد بود. چند دقیقه بعد دوباره امتحان کنید.',
			'ashna_sso_registration' => 'ساخت حساب جدید در این سایت غیرفعال است. با همان حساب قبلی وارد شوید.',
			'ashna_sso_unknown'     => 'ورود با این سرویس انجام نشد. لطفاً دوباره تلاش کنید.',
		);

		return isset( $messages[ $code ] ) ? $messages[ $code ] : 'ورود با این سرویس انجام نشد.';
	}

	/**
	 * The error currently being displayed (from the query string), already validated.
	 *
	 * @return string Empty when there is none.
	 */
	public static function current_error() {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- read-only display of a known code.
		$code = isset( $_GET['ashna_sso_error'] ) ? sanitize_key( wp_unslash( $_GET['ashna_sso_error'] ) ) : '';
		if ( '' === $code || 0 !== strpos( $code, 'ashna_sso_' ) ) {
			return '';
		}
		return self::message_for( $code );
	}

	/**
	 * Route `?ashna_sso=start|callback`.
	 */
	public static function handle_route() {
		// A provider redirect must never be served from a page cache, and neither must the
		// request that creates the single-use state.
		$callback_provider = self::callback_provider();
		if ( null !== $callback_provider ) {
			self::disable_cache();
			self::callback( $callback_provider );
			return;
		}

		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- the OAuth state parameter is the nonce of this route.
		if ( ! isset( $_GET[ self::ROUTE ] ) ) {
			return;
		}
		$step     = sanitize_key( wp_unslash( $_GET[ self::ROUTE ] ) );
		$provider = isset( $_GET['provider'] ) ? sanitize_key( wp_unslash( $_GET['provider'] ) ) : '';
		// phpcs:enable

		if ( 'start' === $step ) {
			self::disable_cache();
			self::start( $provider );
			return;
		}
		if ( 'callback' === $step ) {
			self::disable_cache();
			self::callback( $provider );
		}
	}

	/**
	 * Ask WordPress, the browser and page caches not to store this response.
	 */
	private static function disable_cache() {
		nocache_headers();
		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true );
		}
	}

	/**
	 * Begin a sign-in: create state + PKCE + nonce, then hand over to the provider.
	 *
	 * @param string $provider Provider id.
	 */
	private static function start( $provider ) {
		// phpcs:ignore WordPress.Security.NonceVerification.Recommended -- destination of a login button, validated in begin().
		$redirect_to = isset( $_GET['redirect_to'] ) ? esc_url_raw( wp_unslash( $_GET['redirect_to'] ) ) : '';

		$begun = self::begin( $provider, $redirect_to );
		if ( is_wp_error( $begun ) ) {
			self::fail( $begun->get_error_code(), '' );
		}

		wp_redirect( $begun['authorization_url'] ); // phpcs:ignore WordPress.Security.SafeRedirect.wp_redirect_wp_redirect -- fixed, validated provider endpoint.
		exit;
	}

	/**
	 * Create the state, PKCE verifier and nonce for a provider, and store them.
	 *
	 * Split out from the route so the whole flow can be exercised without an HTTP redirect.
	 *
	 * @param string $provider    Provider id.
	 * @param string $redirect_to Requested destination (already raw, validated here).
	 * @return array|WP_Error { authorization_url, state, verifier, nonce, bind }
	 */
	public static function begin( $provider, $redirect_to = '' ) {
		$providers = self::providers();
		if ( ! isset( $providers[ $provider ] ) || ! Ashna_Helper::get_option( self::setting_key( $provider, 'enabled' ), 0 ) ) {
			return new WP_Error( 'ashna_sso_disabled' );
		}
		if ( ! self::is_ready( $provider ) ) {
			return new WP_Error( 'ashna_sso_not_ready' );
		}

		$endpoints = self::endpoints( $provider );
		if ( is_wp_error( $endpoints ) ) {
			return new WP_Error( 'ashna_sso_network' );
		}

		$redirect_to = $redirect_to ? wp_validate_redirect( $redirect_to, '' ) : '';

		$state    = bin2hex( random_bytes( 32 ) );
		$verifier = self::random_string( 64 );
		$nonce    = self::random_string( 32 );
		$bind     = self::bind_value( $state );

		set_transient(
			self::state_key( $state ),
			array(
				'provider' => $provider,
				'verifier' => $verifier,
				'nonce'    => $nonce,
				'redirect' => $redirect_to,
				'created'  => time(),
			),
			self::STATE_TTL
		);

		self::set_bind_cookie( $bind );

		$extra_params = ( 'google' === $provider ) ? array( 'prompt' => 'select_account' ) : array();

		$authorization_url = add_query_arg(
			$extra_params + array(
				'client_id'             => trim( (string) self::setting( $provider, 'client_id' ) ),
				'redirect_uri'          => self::redirect_uri( $provider ),
				'response_type'         => 'code',
				'scope'                 => $providers[ $provider ]['scopes'],
				'state'                 => $state,
				'nonce'                 => $nonce,
				'code_challenge'        => self::base64url( hash( 'sha256', $verifier, true ) ),
				'code_challenge_method' => 'S256',
			),
			$endpoints['authorization_endpoint']
		);

		return array(
			'authorization_url' => $authorization_url,
			'state'             => $state,
			'verifier'          => $verifier,
			'nonce'             => $nonce,
			'bind'              => $bind,
		);
	}

	/**
	 * Finish a sign-in: validate state, exchange the code, verify the ID token, resolve the user.
	 *
	 * @param string $provider Provider id.
	 */
	private static function callback( $provider ) {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- state is verified inside complete().
		$state = isset( $_GET['state'] ) ? (string) wp_unslash( $_GET['state'] ) : '';
		$code  = isset( $_GET['code'] ) ? sanitize_text_field( wp_unslash( $_GET['code'] ) ) : '';
		$error = isset( $_GET['error'] ) ? sanitize_key( wp_unslash( $_GET['error'] ) ) : '';
		// phpcs:enable
		$bind = isset( $_COOKIE[ self::BIND_COOKIE ] ) ? (string) $_COOKIE[ self::BIND_COOKIE ] : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- compared with hash_equals().

		if ( '' === $provider ) {
			$provider = self::provider_for_state( $state );
			if ( '' === $provider ) {
				// Unknown or expired state: that is an expired sign-in, not a configuration problem.
				self::fail( 'ashna_sso_state', '' );
			}
		}

		if ( '' !== $error ) {
			// A misconfigured console is the most common failure; naming it saves a support ticket.
			$map = array(
				'redirect_uri_mismatch' => 'ashna_sso_redirect',
				'invalid_client'       => 'ashna_sso_client',
				'access_denied'        => 'ashna_sso_denied',
			);
			self::fail( isset( $map[ $error ] ) ? $map[ $error ] : 'ashna_sso_denied', '' );
		}

		$result = self::complete( $provider, $state, $code, $bind );
		if ( is_wp_error( $result ) ) {
			self::fail( $result->get_error_code(), (string) $result->get_error_data() );
		}

		$user   = $result['user'];
		$is_new = ! empty( $result['is_new'] );

		$logged_in = Ashna_Session::login(
			$user,
			array(
				'method'      => 'sso',
				'identifier'  => $result['identifier'],
				'is_new_user' => $is_new,
				'form'        => 'sso',
			)
		);
		if ( is_wp_error( $logged_in ) ) {
			self::fail( 'ashna_sso_blocked', (string) $result['redirect'] );
		}

		do_action( 'ashna_sso_login', $user, $provider, $is_new, $result['claims'] );

		$destination = Ashna_Session::redirect_url( $user, (string) $result['redirect'], array( 'is_new_user' => $is_new, 'form' => 'sso' ) );
		wp_safe_redirect( $destination );
		exit;
	}

	/**
	 * The whole callback as one testable step (no redirect, no exit).
	 *
	 * @param string $provider Provider id.
	 * @param string $state    State from the query string.
	 * @param string $code     Authorization code.
	 * @param string $bind     Binding cookie value.
	 * @return array|WP_Error { user, is_new, redirect, claims, identifier }
	 */
	public static function complete( $provider, $state, $code, $bind ) {
		$providers = self::providers();
		if ( ! isset( $providers[ $provider ] ) || ! self::is_ready( $provider ) ) {
			return new WP_Error( 'ashna_sso_disabled' );
		}

		// The callback is a public endpoint; keep it from becoming a probing or flooding tool.
		if ( ! self::allow_callback() ) {
			return new WP_Error( 'ashna_sso_rate' );
		}

		$state = preg_replace( '/[^a-f0-9]/', '', (string) $state );
		if ( '' === $state || strlen( $state ) !== 64 || '' === (string) $code ) {
			return new WP_Error( 'ashna_sso_state' );
		}

		$stored = get_transient( self::state_key( $state ) );
		delete_transient( self::state_key( $state ) ); // Single use, whatever happens next.
		self::set_bind_cookie( '', -1 );

		if ( ! is_array( $stored ) || empty( $stored['provider'] ) || $stored['provider'] !== $provider ) {
			return new WP_Error( 'ashna_sso_state' );
		}
		if ( empty( $stored['created'] ) || ( time() - (int) $stored['created'] ) > self::STATE_TTL ) {
			return new WP_Error( 'ashna_sso_state' );
		}

		$redirect_to = isset( $stored['redirect'] ) ? (string) $stored['redirect'] : '';

		// The callback must arrive in the same browser that started the flow.
		if ( '' === (string) $bind || ! hash_equals( self::bind_value( $state ), (string) $bind ) ) {
			return new WP_Error( 'ashna_sso_browser', '', $redirect_to );
		}

		$endpoints = self::endpoints( $provider );
		if ( is_wp_error( $endpoints ) ) {
			return new WP_Error( 'ashna_sso_network', '', $redirect_to );
		}

		$tokens = self::exchange_code( $provider, $code, (string) $stored['verifier'], $endpoints );
		if ( is_wp_error( $tokens ) ) {
			return new WP_Error( $tokens->get_error_code(), '', $redirect_to );
		}

		$id_token = isset( $tokens['id_token'] ) ? (string) $tokens['id_token'] : '';
		if ( '' === $id_token ) {
			return new WP_Error( 'ashna_sso_token', '', $redirect_to );
		}

		$claims = self::verify_id_token( $provider, $id_token, (string) $stored['nonce'], $endpoints );
		if ( is_wp_error( $claims ) ) {
			return new WP_Error( 'ashna_sso_token', '', $redirect_to );
		}

		$resolved = self::resolve_user( $provider, $claims );
		if ( is_wp_error( $resolved ) ) {
			return new WP_Error( $resolved->get_error_code(), '', $redirect_to );
		}

		return array(
			'user'       => $resolved['user'],
			'is_new'     => ! empty( $resolved['is_new'] ),
			'redirect'   => $redirect_to,
			'claims'     => $claims,
			'identifier' => $provider . ':' . (string) $claims['sub'],
		);
	}

	/**
	 * Redirect back to the site with a short error code, never with provider details.
	 *
	 * @param string $code        Error code.
	 * @param string $redirect_to Where to return (already validated when it came from the state).
	 */
	private static function fail( $code, $redirect_to = '' ) {
		// Only ever return to this site: the referer of a callback is the provider's own page.
		$target = $redirect_to ? wp_validate_redirect( $redirect_to, '' ) : '';
		$target = $target ? $target : home_url( '/' );
		$target = remove_query_arg( array( 'ashna_sso', 'code', 'state', 'provider', 'error' ), $target );
		$target = add_query_arg( array( 'ashna_sso_error' => $code ), $target );

		wp_safe_redirect( $target );
		exit;
	}

	/**
	 * Simple per-IP ceiling on the callback route.
	 *
	 * @return bool
	 */
	private static function allow_callback() {
		$ip  = Ashna_Helper::get_client_ip();
		$key = 'ashna_sso_cb_' . md5( $ip );
		$hit = (int) get_transient( $key );
		// Generous on purpose: many real visitors can share one CGNAT address, and a single
		// callback costs a transient read, not an SMS. It only has to stop a flood.
		if ( $hit >= 100 ) {
			return false;
		}
		set_transient( $key, $hit + 1, 10 * MINUTE_IN_SECONDS );
		return true;
	}

	/**
	 * Provider endpoints, discovered once and cached.
	 *
	 * @param string $provider Provider id.
	 * @param bool   $refresh  Force a fresh discovery document.
	 * @return array|WP_Error {authorization_endpoint, token_endpoint, jwks_uri}
	 */
	public static function endpoints( $provider, $refresh = false ) {
		$providers = self::providers();
		if ( ! isset( $providers[ $provider ] ) ) {
			return new WP_Error( 'ashna_sso_unknown' );
		}

		$cache_key = 'ashna_sso_disc_' . $provider;
		if ( ! $refresh ) {
			$cached = get_transient( $cache_key );
			if ( is_array( $cached ) && ! empty( $cached['authorization_endpoint'] ) && ! empty( $cached['token_endpoint'] ) ) {
				return $cached;
			}
		}

		$document = self::http_get( $providers[ $provider ]['discovery'], 10 );
		if ( is_wp_error( $document ) || ! is_array( $document ) ) {
			return new WP_Error( 'ashna_sso_network' );
		}

		$needed = array( 'authorization_endpoint', 'token_endpoint' );
		foreach ( $needed as $field ) {
			if ( empty( $document[ $field ] ) || ! is_string( $document[ $field ] ) ) {
				return new WP_Error( 'ashna_sso_network' );
			}
		}
		if ( empty( $document['jwks_uri'] ) ) {
			return new WP_Error( 'ashna_sso_network' );
		}

		$endpoints = array(
			'authorization_endpoint' => $document['authorization_endpoint'],
			'token_endpoint'         => $document['token_endpoint'],
			'jwks_uri'               => $document['jwks_uri'],
		);
		set_transient( $cache_key, $endpoints, 12 * HOUR_IN_SECONDS );

		return $endpoints;
	}

	/**
	 * Exchange an authorization code for tokens.
	 *
	 * @param string $provider  Provider id.
	 * @param string $code      Authorization code.
	 * @param string $verifier  PKCE verifier.
	 * @param array  $endpoints Discovery result.
	 * @return array|WP_Error Token response.
	 */
	private static function exchange_code( $provider, $code, $verifier, array $endpoints ) {
		$body = array(
			'grant_type'    => 'authorization_code',
			'code'          => $code,
			'redirect_uri'  => self::redirect_uri( $provider ),
			'client_id'     => trim( (string) self::setting( $provider, 'client_id' ) ),
			'code_verifier' => $verifier,
		);

		$response = self::http_post(
			$endpoints['token_endpoint'],
			array_merge( $body, array( 'client_secret' => (string) self::setting( $provider, 'client_secret' ) ) ),
			array()
		);

		// Some providers only accept HTTP Basic client authentication; retry once on a clear
		// "invalid_client" answer. The secret never lands in a URL or a log in either case.
		if ( is_array( $response ) && isset( $response['error'] ) && 'invalid_client' === $response['error'] ) {
			$basic     = trim( (string) self::setting( $provider, 'client_id' ) ) . ':' . (string) self::setting( $provider, 'client_secret' );
			$response  = self::http_post( $endpoints['token_endpoint'], $body, array( 'Authorization' => 'Basic ' . base64_encode( $basic ) ) ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- HTTP Basic credentials, not obfuscation.
		}

		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'ashna_sso_network' );
		}
		if ( ! is_array( $response ) || empty( $response['id_token'] ) ) {
			return new WP_Error( 'ashna_sso_token' );
		}

		return $response;
	}

	/**
	 * Verify the ID token against the provider's published keys.
	 *
	 * @param string $provider  Provider id.
	 * @param string $id_token  Compact JWS.
	 * @param string $nonce     Nonce from the state.
	 * @param array  $endpoints Discovery result.
	 * @return array|WP_Error Claims.
	 */
	private static function verify_id_token( $provider, $id_token, $nonce, array $endpoints ) {
		$providers = self::providers();
		$args      = array(
			'iss'   => $providers[ $provider ]['issuer'],
			'aud'   => trim( (string) self::setting( $provider, 'client_id' ) ),
			'nonce' => $nonce,
		);

		$keys = self::jwks( $endpoints['jwks_uri'], false );
		if ( is_wp_error( $keys ) ) {
			return $keys;
		}

		$claims = Ashna_JWT::verify( $id_token, $keys, $args );
		if ( is_wp_error( $claims ) && 'ashna_jwt_kid' === $claims->get_error_code() ) {
			// Key rotation: fetch the JWKS again, once.
			$keys   = self::jwks( $endpoints['jwks_uri'], true );
			$claims = is_wp_error( $keys ) ? $keys : Ashna_JWT::verify( $id_token, $keys, $args );
		}

		return $claims;
	}

	/**
	 * Load (and cache) a JWKS document.
	 *
	 * @param string $url     JWKS URL.
	 * @param bool   $refresh Force a fetch.
	 * @return array|WP_Error List of keys.
	 */
	private static function jwks( $url, $refresh = false ) {
		$cache_key = 'ashna_sso_jwks_' . md5( $url );
		if ( ! $refresh ) {
			$cached = get_transient( $cache_key );
			if ( is_array( $cached ) && ! empty( $cached ) ) {
				return $cached;
			}
		}

		$document = self::http_get( $url, 10 );
		if ( is_wp_error( $document ) || ! is_array( $document ) || empty( $document['keys'] ) || ! is_array( $document['keys'] ) ) {
			return new WP_Error( 'ashna_sso_network' );
		}

		set_transient( $cache_key, $document['keys'], 6 * HOUR_IN_SECONDS );

		return $document['keys'];
	}

	/**
	 * Turn verified claims into a signed-in WordPress user.
	 *
	 * @param string $provider Provider id.
	 * @param array  $claims   Verified ID-token claims.
	 * @return array|WP_Error {user: WP_User, is_new: bool}
	 */
	private static function resolve_user( $provider, array $claims ) {
		$subject = (string) $claims['sub'];

		// 1. A known identity always wins: the provider's opaque subject is the durable key.
		$identity = self::identity_by_subject( $provider, $subject );
		if ( $identity ) {
			$user = get_user_by( 'id', (int) $identity->user_id );
			if ( $user ) {
				self::touch_identity( (int) $identity->id );
				self::remember_profile( $user, $provider, $claims );
				return array( 'user' => $user, 'is_new' => false );
			}
			self::delete_identity( (int) $identity->id ); // The account is gone; drop the stale row.
		}

		$email    = '';
		$verified = false;

		if ( ! empty( $claims['email'] ) && is_string( $claims['email'] ) && is_email( $claims['email'] ) ) {
			$email = $claims['email'];
			// Google sends a boolean; some providers send "true". Only a positive value counts.
			$verified = isset( $claims['email_verified'] ) && filter_var( $claims['email_verified'], FILTER_VALIDATE_BOOLEAN );
		}

		// 2. Link to an existing account only when the provider proved the address.
		if ( '' !== $email ) {
			$existing = get_user_by( 'email', $email );
			if ( $existing ) {
				if ( ! $verified ) {
					return new WP_Error( 'ashna_sso_unverified' );
				}
				if ( Ashna_Auth::is_staff_account( $existing ) ) {
					return new WP_Error( 'ashna_sso_staff' );
				}
				$linked = self::link_identity( $provider, $subject, (int) $existing->ID, $email );
				if ( is_wp_error( $linked ) ) {
					return $linked;
				}
				self::remember_profile( $existing, $provider, $claims );
				return array( 'user' => $existing, 'is_new' => false );
			}
		}

		// 3. Telegram proves the phone number; that is as strong as an OTP to it.
		$phone = self::verified_phone( $provider, $claims );
		if ( is_wp_error( $phone ) ) {
			return $phone;
		}
		if ( '' !== $phone ) {
			$existing = Ashna_Auth::find_user( $phone, 'phone' );
			if ( $existing && $existing->exists() ) {
				if ( Ashna_Auth::is_staff_account( $existing ) ) {
					return new WP_Error( 'ashna_sso_staff' );
				}
				$linked = self::link_identity( $provider, $subject, (int) $existing->ID, '', $phone );
				if ( is_wp_error( $linked ) ) {
					return $linked;
				}
				self::remember_profile( $existing, $provider, $claims );
				return array( 'user' => $existing, 'is_new' => false );
			}
		}

		// 4. Nothing matched: create the account, with whatever proof we actually have.
		if ( ! Ashna_Helper::get_option( 'auto_register', 1 ) ) {
			return new WP_Error( 'ashna_sso_registration' );
		}

		$name = isset( $claims['name'] ) && is_string( $claims['name'] ) ? sanitize_text_field( $claims['name'] ) : '';
		if ( '' === $name && ! empty( $claims['given_name'] ) ) {
			$name = sanitize_text_field( (string) $claims['given_name'] );
		}

		if ( '' !== $email && $verified ) {
			$user = Ashna_Auth::register_user( $email, 'email', array( 'full_name' => $name ) );
		} elseif ( '' !== $phone ) {
			$user = Ashna_Auth::register_user( $phone, 'phone', array( 'full_name' => $name ) );
		} else {
			$user = self::create_profile_only_user( $provider, $subject, $name );
		}

		if ( is_wp_error( $user ) ) {
			return $user;
		}

		if ( '' !== $phone ) {
			Ashna_Auth::sync_user_phone_meta( (int) $user->ID, $phone );
		}

		$linked = self::link_identity( $provider, $subject, (int) $user->ID, $email, $phone );
		if ( is_wp_error( $linked ) ) {
			// The brand-new account exists only to carry this identity. If the identity could not
			// be stored (a parallel request won the race), deleting it is the only outcome that
			// leaves neither an orphan account nor a second account on the next sign-in.
			require_once ABSPATH . 'wp-admin/includes/user.php';
			wp_delete_user( (int) $user->ID );
			return $linked;
		}

		self::remember_profile( $user, $provider, $claims );

		return array( 'user' => $user, 'is_new' => true );
	}

	/**
	 * The phone the provider itself has verified, or '' when none was shared.
	 *
	 * @param string $provider Provider id.
	 * @param array  $claims   Claims.
	 * @return string|WP_Error Normalized local phone.
	 */
	private static function verified_phone( $provider, array $claims ) {
		$providers = self::providers();
		if ( empty( $providers[ $provider ]['phone'] ) ) {
			return '';
		}
		if ( empty( $claims['phone_number'] ) || ! is_string( $claims['phone_number'] ) ) {
			return '';
		}
		if ( isset( $claims['phone_number_verified'] ) && ! filter_var( $claims['phone_number_verified'], FILTER_VALIDATE_BOOLEAN ) ) {
			return new WP_Error( 'ashna_sso_unverified' );
		}

		$phone = Ashna_Helper::normalize_phone( $claims['phone_number'] );
		if ( ! Ashna_Helper::is_valid_phone( $phone ) ) {
			// A number outside the Iranian mobile range cannot identify an Ashna account.
			return '';
		}

		return $phone;
	}

	/**
	 * Create an account for a provider that shared neither an e-mail nor a phone.
	 *
	 * @param string $provider Provider id.
	 * @param string $subject  Opaque subject.
	 * @param string $name     Display name.
	 * @return WP_User|WP_Error
	 */
	private static function create_profile_only_user( $provider, $subject, $name ) {
		$base = sanitize_user( $provider . '_' . substr( $subject, 0, 20 ), true );
		if ( '' === $base ) {
			$base = $provider . '_user';
		}
		$login = $base;
		$i     = 1;
		while ( username_exists( $login ) ) {
			$login = $base . '_' . $i;
			++$i;
		}

		$user_id = wp_insert_user(
			wp_slash(
				array(
					'user_login'   => $login,
					'user_pass'    => wp_generate_password( 32, true, true ),
					'display_name' => '' !== $name ? $name : $login,
					'first_name'   => '' !== $name ? $name : '',
					'role'         => Ashna_Auth::safe_registration_role( Ashna_Helper::get_option( 'default_user_role', 'customer' ) ),
				)
			)
		);

		if ( is_wp_error( $user_id ) ) {
			return $user_id;
		}

		$user = get_user_by( 'id', (int) $user_id );

		return $user ? $user : new WP_Error( 'ashna_sso_registration' );
	}

	/**
	 * Store the profile bits the provider gave us (name, avatar) without ever overwriting a value
	 * the visitor edited by hand.
	 *
	 * @param WP_User $user     User.
	 * @param string  $provider Provider id.
	 * @param array   $claims   Claims.
	 */
	private static function remember_profile( $user, $provider, array $claims ) {
		update_user_meta( $user->ID, 'ashna_sso_provider', $provider );

		if ( ! empty( $claims['picture'] ) && is_string( $claims['picture'] ) && ! get_user_meta( $user->ID, 'ashna_sso_avatar', true ) ) {
			update_user_meta( $user->ID, 'ashna_sso_avatar', esc_url_raw( $claims['picture'] ) );
		}
		if ( ! empty( $claims['preferred_username'] ) && ! get_user_meta( $user->ID, 'ashna_sso_username', true ) ) {
			update_user_meta( $user->ID, 'ashna_sso_username', sanitize_text_field( (string) $claims['preferred_username'] ) );
		}

		// Ask once. "Later" is honoured for a month, then the card may come back if the account
		// still has no phone to recover it with.
		$dismissed = (int) get_user_meta( $user->ID, 'ashna_sso_phone_dismissed', true );
		$muted     = $dismissed > 0 && ( time() - $dismissed ) < 30 * DAY_IN_SECONDS;

		if ( ! get_user_meta( $user->ID, 'ashna_phone', true ) && Ashna_Helper::get_option( 'sso_ask_phone', 1 ) && ! $muted ) {
			update_user_meta( $user->ID, 'ashna_sso_needs_phone', '1' );
		} else {
			delete_user_meta( $user->ID, 'ashna_sso_needs_phone' );
		}
	}

	// ---------------------------------------------------------------------
	// Identity storage
	// ---------------------------------------------------------------------

	/**
	 * Row for a provider subject.
	 *
	 * @param string $provider Provider id.
	 * @param string $subject  Subject.
	 * @return object|null
	 */
	private static function identity_by_subject( $provider, $subject ) {
		global $wpdb;
		$table = self::table_name();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE provider = %s AND subject = %s LIMIT 1", $provider, $subject ) );
	}

	/**
	 * Bind a provider subject to a user (idempotent, never rebinds to another user).
	 *
	 * @param string $provider Provider id.
	 * @param string $subject  Subject.
	 * @param int    $user_id  User id.
	 * @param string $email    Verified e-mail, if any.
	 * @param string $phone    Verified phone, if any.
	 * @return true|WP_Error
	 */
	private static function link_identity( $provider, $subject, $user_id, $email = '', $phone = '' ) {
		global $wpdb;

		$existing = self::identity_by_subject( $provider, $subject );
		if ( $existing ) {
			// Already bound: only the same user may use it. A different user id here means an
			// account was deleted and its id reused — refuse rather than silently rebind.
			return (int) $existing->user_id === (int) $user_id
				? true
				: new WP_Error( 'ashna_sso_blocked' );
		}

		$table = self::table_name();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$ok = $wpdb->insert(
			$table,
			array(
				'provider'   => $provider,
				'subject'    => $subject,
				'user_id'    => (int) $user_id,
				'email'      => $email,
				'phone'      => $phone,
				'created_at' => current_time( 'mysql', true ),
				'last_login' => current_time( 'mysql', true ),
			),
			array( '%s', '%s', '%d', '%s', '%s', '%s', '%s' )
		);

		if ( false === $ok ) {
			// A parallel request won the race; accept it only if it bound the same user.
			$again = self::identity_by_subject( $provider, $subject );
			return ( $again && (int) $again->user_id === (int) $user_id ) ? true : new WP_Error( 'ashna_sso_blocked' );
		}

		update_user_meta( (int) $user_id, 'ashna_sso_' . $provider . '_sub', $subject );

		return true;
	}

	/**
	 * Update the "last seen" stamp.
	 *
	 * @param int $id Row id.
	 */
	private static function touch_identity( $id ) {
		global $wpdb;
		$table = self::table_name();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->update( $table, array( 'last_login' => current_time( 'mysql', true ) ), array( 'id' => (int) $id ), array( '%s' ), array( '%d' ) );
	}

	/**
	 * Remove a row whose user no longer exists.
	 *
	 * @param int $id Row id.
	 */
	private static function delete_identity( $id ) {
		global $wpdb;
		$table = self::table_name();
		// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
		$wpdb->delete( $table, array( 'id' => (int) $id ), array( '%d' ) );
	}

	// ---------------------------------------------------------------------
	// Link a phone to a signed-in social account
	// ---------------------------------------------------------------------

	/**
	 * Show the "add your phone" card to social accounts that have no phone yet.
	 */
	public static function render_phone_prompt() {
		if ( ! is_user_logged_in() || ! Ashna_Helper::get_option( 'sso_ask_phone', 1 ) ) {
			return;
		}

		$user_id = get_current_user_id();
		if ( '1' !== (string) get_user_meta( $user_id, 'ashna_sso_needs_phone', true ) ) {
			return;
		}
		if ( '' !== (string) get_user_meta( $user_id, 'ashna_phone', true ) ) {
			delete_user_meta( $user_id, 'ashna_sso_needs_phone' );
			return;
		}

		// The card can be printed on a page where the frontend bundle never ran (a shortcode-only
		// theme, a cached page the card is injected into). Registering the handles here keeps the
		// card styled in that case without adding a second stylesheet to normal requests.
		if ( ! wp_style_is( 'ashna-otp-frontend', 'registered' ) ) {
			wp_register_style( 'ashna-fonts', ASHNA_OTP_URL . 'assets/css/fonts.css', array(), ASHNA_OTP_VERSION );
			$css_ver = ASHNA_OTP_VERSION . '.' . ( file_exists( ASHNA_OTP_PATH . 'assets/css/frontend.css' ) ? filemtime( ASHNA_OTP_PATH . 'assets/css/frontend.css' ) : '1' );
			wp_register_style( 'ashna-otp-frontend', ASHNA_OTP_URL . 'assets/css/frontend.css', array( 'ashna-fonts' ), $css_ver );
		}
		wp_enqueue_style( 'ashna-otp-frontend' );

		$js_ver = ASHNA_OTP_VERSION . '.' . ( file_exists( ASHNA_OTP_PATH . 'assets/js/sso.js' ) ? filemtime( ASHNA_OTP_PATH . 'assets/js/sso.js' ) : '1' );
		wp_enqueue_script( 'ashna-sso', ASHNA_OTP_URL . 'assets/js/sso.js', array(), $js_ver, true );
		wp_localize_script(
			'ashna-sso',
			'ashnaSSO',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'ashna_sso_phone' ),
				'i18n'    => array(
					'sending' => 'در حال ارسال کد…',
					'verifying' => 'در حال بررسی…',
					'error'   => 'انجام نشد؛ دوباره تلاش کنید.',
					'wrong'   => 'کد وارد شده صحیح نیست.',
					'sent'    => 'کد تأیید به شمارهٔ شما پیامک شد.',
					'added'   => 'شمارهٔ شما ثبت شد. از این پس می‌توانید با کد پیامکی هم وارد شوید.',
				),
			)
		);

		include __DIR__ . '/../templates/sso-phone-prompt.php';
	}

	/**
	 * Step 1 of the phone link: send a code through the normal, rate-limited pipeline.
	 */
	public static function ajax_phone_start() {
		if ( ! self::verify_request() ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- checked in verify_request().
		$raw   = isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ) ) : '';
		$phone = Ashna_Helper::normalize_phone( $raw );

		if ( ! Ashna_Helper::is_valid_phone( $phone ) ) {
			wp_send_json_error( array( 'message' => 'شمارهٔ موبایل معتبر نیست.' ) );
			return;
		}

		$owner = Ashna_Auth::find_user( $phone, 'phone' );
		if ( $owner && $owner->exists() && (int) $owner->ID !== get_current_user_id() ) {
			wp_send_json_error( array( 'message' => self::message_for( 'ashna_sso_phone_taken' ) ) );
			return;
		}

		$ip          = Ashna_Helper::get_client_ip();
		$reservation = Ashna_Rate_Limiter::reserve( $phone, $ip );
		if ( is_wp_error( $reservation ) ) {
			wp_send_json_error(
				array(
					'message' => $reservation->get_error_message(),
					'code'    => $reservation->get_error_code(),
				)
			);
			return;
		}

		$dispatch = Ashna_Gateway_Manager::dispatch_otp( $phone, 'phone', '', '', $reservation );
		if ( is_wp_error( $dispatch ) ) {
			wp_send_json_error( array( 'message' => 'ارسال کد در حال حاضر ممکن نشد. چند دقیقه بعد دوباره تلاش کنید.' ) );
			return;
		}

		wp_send_json_success(
			array(
				'message' => 'کد تأیید به شمارهٔ شما پیامک شد.',
				'phone'   => $phone,
				'masked'  => substr( $phone, 0, 4 ) . '***' . substr( $phone, -4 ),
			)
		);
	}

	/**
	 * Step 2 of the phone link: verify the code and store the number.
	 */
	public static function ajax_phone_verify() {
		if ( ! self::verify_request() ) {
			return;
		}

		// phpcs:ignore WordPress.Security.NonceVerification.Missing -- checked in verify_request().
		$raw   = isset( $_POST['phone'] ) ? sanitize_text_field( wp_unslash( $_POST['phone'] ) ) : '';
		// phpcs:ignore WordPress.Security.NonceVerification.Missing
		$code  = isset( $_POST['code'] ) ? sanitize_text_field( wp_unslash( $_POST['code'] ) ) : '';
		$phone = Ashna_Helper::normalize_phone( $raw );

		if ( ! Ashna_Helper::is_valid_phone( $phone ) ) {
			wp_send_json_error( array( 'message' => 'شمارهٔ موبایل معتبر نیست.' ) );
			return;
		}

		$owner = Ashna_Auth::find_user( $phone, 'phone' );
		if ( $owner && $owner->exists() && (int) $owner->ID !== get_current_user_id() ) {
			wp_send_json_error( array( 'message' => self::message_for( 'ashna_sso_phone_taken' ) ) );
			return;
		}

		$verified = Ashna_Security::verify_otp( $phone, $code );
		if ( is_wp_error( $verified ) ) {
			wp_send_json_error(
				array(
					'message' => $verified->get_error_message(),
					'code'    => $verified->get_error_code(),
				)
			);
			return;
		}

		$user_id = get_current_user_id();
		Ashna_Auth::sync_user_phone_meta( $user_id, $phone );
		update_user_meta( $user_id, 'ashna_phone_verified', time() );
		delete_user_meta( $user_id, 'ashna_sso_needs_phone' );
		delete_user_meta( $user_id, 'ashna_sso_phone_dismissed' );

		do_action( 'ashna_sso_phone_linked', $user_id, $phone );

		wp_send_json_success(
			array(
				'message' => 'شمارهٔ شما ثبت و تأیید شد. از این پس می‌توانید با کد پیامکی هم وارد شوید.',
			)
		);
	}

	/**
	 * "Later": stop asking this account for a number for a while.
	 */
	public static function ajax_phone_dismiss() {
		if ( ! self::verify_request() ) {
			return;
		}
		$user_id = get_current_user_id();
		delete_user_meta( $user_id, 'ashna_sso_needs_phone' );
		update_user_meta( $user_id, 'ashna_sso_phone_dismissed', time() );
		wp_send_json_success( array( 'message' => 'باشه، بعداً.' ) );
	}

	/**
	 * Shared guard for the three phone endpoints: signed-in, nonce, POST.
	 */
	private static function verify_request() {
		if ( ! is_user_logged_in() ) {
			wp_send_json_error( array( 'message' => 'ابتدا وارد شوید.' ), 403 );
			return false; // wp_send_json ends the request in production; fail closed everywhere else.
		}

		$nonce = isset( $_POST['nonce'] ) && is_scalar( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';
		if ( ! wp_verify_nonce( $nonce, 'ashna_sso_phone' ) ) {
			wp_send_json_error( array( 'message' => 'اعتبار صفحه به پایان رسیده بود؛ صفحه را تازه کنید.' ), 403 );
			return false;
		}

		return true;
	}

	// ---------------------------------------------------------------------
	// HTTP + helpers
	// ---------------------------------------------------------------------

	/**
	 * GET JSON, with a filter so tests (and a future self-hosted provider) can answer instead.
	 *
	 * @param string $url     URL.
	 * @param int    $timeout Seconds.
	 * @return array|WP_Error
	 */
	private static function http_get( $url, $timeout ) {
		$override = apply_filters( 'ashna_sso_http_response', null, $url, array( 'method' => 'GET' ) );
		if ( null !== $override ) {
			return $override;
		}

		$response = wp_remote_get( $url, array( 'timeout' => $timeout, 'redirection' => 2 ) );
		return self::parse_http( $response );
	}

	/**
	 * POST form data, with the same filter hook.
	 *
	 * @param string $url     URL.
	 * @param array  $body    Form fields.
	 * @param array  $headers Extra headers.
	 * @return array|WP_Error
	 */
	private static function http_post( $url, array $body, array $headers ) {
		$override = apply_filters( 'ashna_sso_http_response', null, $url, array( 'method' => 'POST', 'body' => $body, 'headers' => $headers ) );
		if ( null !== $override ) {
			return $override;
		}

		$response = wp_remote_post(
			$url,
			array(
				'timeout' => 10,
				'headers' => $headers,
				'body'    => $body,
			)
		);
		return self::parse_http( $response );
	}

	/**
	 * Decode a wp_remote_* response.
	 *
	 * @param array|WP_Error $response Response.
	 * @return array|WP_Error
	 */
	private static function parse_http( $response ) {
		if ( is_wp_error( $response ) ) {
			return new WP_Error( 'ashna_sso_network' );
		}
		$code = (int) wp_remote_retrieve_response_code( $response );
		$body = json_decode( (string) wp_remote_retrieve_body( $response ), true );
		if ( ! is_array( $body ) ) {
			return new WP_Error( 'ashna_sso_network' );
		}
		if ( $code < 200 || $code >= 300 ) {
			$error = isset( $body['error'] ) ? sanitize_key( (string) $body['error'] ) : 'error';
			return array( 'error' => $error );
		}
		return $body;
	}

	/**
	 * Transient key for a state value.
	 *
	 * @param string $state State.
	 * @return string
	 */
	public static function state_key( $state ) {
		return 'ashna_sso_st_' . substr( hash( 'sha256', $state ), 0, 40 );
	}

	/**
	 * Cookie value that binds a callback to this browser.
	 *
	 * @param string $state State.
	 * @return string
	 */
	private static function bind_value( $state ) {
		return hash_hmac( 'sha256', $state, wp_salt( 'auth' ) );
	}

	/**
	 * Write (or clear) the binding cookie.
	 *
	 * @param string $value   Value.
	 * @param int    $expires Expiry; negative clears.
	 */
	private static function set_bind_cookie( $value, $expires = 0 ) {
		if ( headers_sent() ) {
			return;
		}
		$options = array(
			'expires'  => $expires < 0 ? time() - HOUR_IN_SECONDS : time() + self::STATE_TTL,
			'path'     => COOKIEPATH ? COOKIEPATH : '/',
			'domain'   => COOKIE_DOMAIN,
			'secure'   => is_ssl(),
			'httponly' => true,
			'samesite' => 'Lax',
		);
		setcookie( self::BIND_COOKIE, (string) $value, $options );
	}

	/**
	 * Random URL-safe string.
	 *
	 * @param int $bytes Entropy.
	 * @return string
	 */
	private static function random_string( $bytes ) {
		return self::base64url( random_bytes( $bytes ) );
	}

	/**
	 * Base64url encode.
	 *
	 * @param string $bytes Raw bytes.
	 * @return string
	 */
	private static function base64url( $bytes ) {
		return rtrim( strtr( base64_encode( $bytes ), '+/', '-_' ), '=' ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- PKCE encoding, not obfuscation.
	}
}


// ---- Source: includes/services/class-ashna-woocommerce.php ----
/**
 * WooCommerce & WordPress User Profile Integration
 *
 * @package Ashna
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Ashna_WooCommerce {

	/**
	 * Singleton instance
	 *
	 * @var Ashna_WooCommerce|null
	 */
	private static $instance = null;

	/**
	 * The checkout sign-in box was printed in this request (classic hook or checkout block).
	 *
	 * @var bool
	 */
	private static $checkout_box_shown = false;

	/**
	 * Get instance
	 *
	 * @return Ashna_WooCommerce
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor
	 */
	private function __construct() {
		add_filter( 'wc_get_template', array( $this, 'override_myaccount_login_template' ), 99, 2 );
		add_action( 'woocommerce_before_checkout_form', array( $this, 'render_checkout_otp_box' ), 5 );
		add_filter( 'render_block_woocommerce/checkout', array( $this, 'prepend_checkout_otp_box' ), 10, 1 ); // Block checkout (default since WooCommerce 8.3).
		add_filter( 'woocommerce_checkout_get_value', array( $this, 'prefill_checkout_billing_phone' ), 10, 2 );

		add_filter( 'manage_users_columns', array( $this, 'add_user_phone_column' ) );
		add_filter( 'manage_users_custom_column', array( $this, 'render_user_phone_column' ), 10, 3 );
		add_action( 'show_user_profile', array( $this, 'render_user_profile_fields' ) );
		add_action( 'edit_user_profile', array( $this, 'render_user_profile_fields' ) );
		add_action( 'personal_options_update', array( $this, 'save_user_profile_fields' ) );
		add_action( 'edit_user_profile_update', array( $this, 'save_user_profile_fields' ) );
	}

	/**
	 * Replace WooCommerce My Account login form with Ashna form if enabled
	 *
	 * @param string $located       Located template path.
	 * @param string $template_name Template name.
	 * @return string
	 */
	public function override_myaccount_login_template( $located, $template_name ) {
		if ( 'myaccount/form-login.php' === $template_name && ! is_user_logged_in() ) {
			if ( Ashna_Helper::get_option( 'wc_replace_myaccount', 1 ) ) {
				$custom_file = ASHNA_OTP_PATH . 'templates/wc-myaccount-login.php';
				if ( file_exists( $custom_file ) ) {
					return $custom_file;
				}
			}
		}
		return $located;
	}

	/**
	 * Render OTP quick login box on the classic (shortcode) WooCommerce Checkout for guests.
	 */
	public function render_checkout_otp_box() {
		echo $this->checkout_otp_box_html(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- built from escaped parts below.
	}

	/**
	 * Same box above the block-based Checkout (rendered outside the block's React root).
	 *
	 * @param string $block_content Rendered checkout block.
	 * @return string
	 */
	public function prepend_checkout_otp_box( $block_content ) {
		if ( is_admin() || wp_is_json_request() ) {
			return $block_content;
		}
		return $this->checkout_otp_box_html() . $block_content;
	}

	/**
	 * Checkout sign-in box markup (empty for signed-in visitors, when disabled, or when already shown).
	 *
	 * @return string
	 */
	private function checkout_otp_box_html() {
		if ( self::$checkout_box_shown || is_user_logged_in() || ! Ashna_Helper::get_option( 'wc_checkout_otp_box', 1 ) ) {
			return '';
		}
		self::$checkout_box_shown = true;

		$checkout_url = function_exists( 'wc_get_checkout_url' ) ? wc_get_checkout_url() : '';
		$form_html    = Ashna_Frontend::get_login_form_html(
			array(
				'redirect' => $checkout_url,
				'context'  => 'wc-checkout',
			)
		);

		return '<div class="ashna-wc-checkout-banner" dir="rtl">'
			. '<div class="ashna-wc-checkout-notice">'
			. '<span>' . esc_html( 'برای ثبت سریع‌تر سفارش، می‌توانید با کد یکبارمصرف (بدون رمز عبور) وارد شوید:' ) . '</span>'
			. '<button type="button" class="ashna-btn ashna-btn-sm ashna-toggle-checkout-otp" aria-expanded="false">' . esc_html( 'ورود سریع با کد تایید (OTP)' ) . '</button>'
			. '</div>'
			. '<div class="ashna-wc-checkout-form-holder" style="display:none;margin-top:16px;">' . $form_html . '</div>' // Escaped inside templates/login-form.php.
			. '</div>';
	}

	/**
	 * Pre-fill billing_phone in WooCommerce checkout from ashna_phone
	 *
	 * @param mixed  $value Field value.
	 * @param string $input Field name.
	 * @return mixed
	 */
	public function prefill_checkout_billing_phone( $value, $input ) {
		if ( 'billing_phone' === $input && empty( $value ) && is_user_logged_in() ) {
			$phone = get_user_meta( get_current_user_id(), 'ashna_phone', true );
			if ( ! empty( $phone ) ) {
				return $phone;
			}
		}
		return $value;
	}

	/**
	 * Add mobile column to WP Users table
	 *
	 * @param array $columns Existing columns.
	 * @return array
	 */
	public function add_user_phone_column( $columns ) {
		$columns['ashna_phone'] = 'شماره موبایل (OTP)';
		return $columns;
	}

	/**
	 * Render mobile column in WP Users table
	 *
	 * @param string $output      Custom column output.
	 * @param string $column_name Column name.
	 * @param int    $user_id     User ID.
	 * @return string
	 */
	public function render_user_phone_column( $output, $column_name, $user_id ) {
		if ( 'ashna_phone' === $column_name ) {
			$phone = get_user_meta( $user_id, 'ashna_phone', true );
			if ( empty( $phone ) ) {
				$phone = get_user_meta( $user_id, 'billing_phone', true );
			}
			if ( empty( $phone ) ) {
				$phone = get_user_meta( $user_id, 'digits_phone', true );
			}
			return ! empty( $phone ) ? '<code dir="ltr">' . esc_html( $phone ) . '</code>' : '—';
		}
		return $output;
	}

	/**
	 * Render Ashna phone & Bale chat ID fields on user profile screen
	 *
	 * @param WP_User $user User object.
	 */
	public function render_user_profile_fields( $user ) {
		$phone = get_user_meta( $user->ID, 'ashna_phone', true );
		if ( empty( $phone ) ) {
			$phone = get_user_meta( $user->ID, 'billing_phone', true );
		}
		if ( empty( $phone ) ) {
			$phone = get_user_meta( $user->ID, 'digits_phone', true );
		}
		$bale_chat_id = get_user_meta( $user->ID, 'ashna_bale_chat_id', true );
		$can_edit     = self::can_edit_verified_phone( $user->ID );
		?>
		<h2>اطلاعات ورود یکبارمصرف (آشنا)</h2>
		<table class="form-table" role="presentation">
			<tr>
				<th><label for="ashna_phone">شماره موبایل تایید شده</label></th>
				<td>
					<input type="text" name="ashna_phone" id="ashna_phone" value="<?php echo esc_attr( $phone ); ?>" class="regular-text" dir="ltr" placeholder="09123456789" <?php disabled( ! $can_edit ); ?> />
					<?php if ( $can_edit ) : ?>
						<p class="description">شماره موبایل کاربر برای ورود با کد یکبارمصرف (فرمت استاندارد: 09123456789). حساب‌های مدیریتی فقط با شماره‌ای که اینجا ثبت شده با کد وارد می‌شوند.</p>
					<?php else : ?>
						<p class="description">این شماره با ورود موفق با کد تایید شده است و فقط مدیر سایت می‌تواند آن را تغییر دهد.</p>
					<?php endif; ?>
				</td>
			</tr>
			<tr>
				<th><label for="ashna_bale_chat_id">شناسه چت بله (Bale Chat ID)</label></th>
				<td>
					<input type="text" name="ashna_bale_chat_id" id="ashna_bale_chat_id" value="<?php echo esc_attr( $bale_chat_id ); ?>" class="regular-text" dir="ltr" />
					<p class="description">اختیاری — در صورت استفاده از حالت «ربات بله (Bot API)» برای ارسال پیام مستقیم.</p>
				</td>
			</tr>
		</table>
		<?php
	}

	/**
	 * The verified phone decides which account an OTP opens, so users may not change their
	 * own value (that would let anyone claim another person's number); site admins can.
	 *
	 * @param int $user_id Profile being edited.
	 * @return bool
	 */
	private static function can_edit_verified_phone( $user_id ) {
		if ( ! current_user_can( 'edit_user', $user_id ) ) {
			return false;
		}
		return get_current_user_id() !== (int) $user_id || current_user_can( 'manage_options' );
	}

	/**
	 * Save Ashna phone & Bale chat ID from user profile screen
	 *
	 * @param int $user_id User ID.
	 */
	public function save_user_profile_fields( $user_id ) {
		if ( ! current_user_can( 'edit_user', $user_id ) ) {
			return;
		}

		// phpcs:disable WordPress.Security.NonceVerification.Missing
		if ( isset( $_POST['ashna_phone'] ) && self::can_edit_verified_phone( $user_id ) ) {
			$raw_phone  = sanitize_text_field( wp_unslash( $_POST['ashna_phone'] ) );
			$normalized = ! empty( $raw_phone ) ? Ashna_Helper::normalize_phone( $raw_phone ) : '';
			if ( ! empty( $normalized ) ) {
				Ashna_Auth::sync_user_phone_meta( $user_id, $normalized );
			} else {
				update_user_meta( $user_id, 'ashna_phone', '' );
			}
		}

		if ( isset( $_POST['ashna_bale_chat_id'] ) ) {
			$chat_id = sanitize_text_field( wp_unslash( $_POST['ashna_bale_chat_id'] ) );
			update_user_meta( $user_id, 'ashna_bale_chat_id', $chat_id );
		}
		// phpcs:enable
	}
}


// ---- Source: includes/admin/class-ashna-admin.php ----
/**
 * Admin Controller, AJAX Settings Saver, Live Tester, Firewall Manager & CSV Exporter (v2.0)
 *
 * @package Ashna
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Ashna_Admin {

	/**
	 * Singleton instance
	 *
	 * @var Ashna_Admin|null
	 */
	private static $instance = null;

	/**
	 * Output-buffer level before Ashna's admin-AJAX buffer was opened (null outside those requests).
	 *
	 * @var int|null
	 */
	private static $ajax_buffer_level = null;

	/**
	 * Track if settings were already saved during the current request
	 *
	 * @var bool
	 */
	private $settings_saved_in_request = false;

	/**
	 * Get instance
	 *
	 * @return Ashna_Admin
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor
	 */
	private function __construct() {
		if ( wp_doing_ajax() && isset( $_REQUEST['action'] ) && strpos( sanitize_text_field( wp_unslash( $_REQUEST['action'] ) ), 'ashna_admin_' ) === 0 ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			// Catch stray notices other plugins print during our AJAX requests (removed before replying).
			self::$ajax_buffer_level = ob_get_level();
			ob_start();
		}

		add_action( 'admin_menu', array( $this, 'register_menus' ) );
		add_action( 'admin_init', array( $this, 'handle_actions' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_assets' ) );

		// AJAX Endpoints
		add_action( 'wp_ajax_ashna_admin_save_settings', array( $this, 'ajax_save_settings' ) );
		add_action( 'wp_ajax_ashna_admin_test_gateway', array( $this, 'ajax_test_gateway' ) );
		add_action( 'wp_ajax_ashna_admin_unlock_target', array( $this, 'ajax_unlock_target' ) );
		add_action( 'wp_ajax_ashna_admin_import_settings', array( $this, 'ajax_import_settings' ) );
		add_action( 'wp_ajax_ashna_admin_reset_settings', array( $this, 'ajax_reset_settings' ) );
		add_action( 'wp_ajax_ashna_admin_reset_gateway_health', array( $this, 'ajax_reset_gateway_health' ) );
		add_action( 'wp_ajax_ashna_admin_end_attack_mode', array( $this, 'ajax_end_attack_mode' ) );
		add_action( 'wp_ajax_ashna_admin_trust_proxy', array( $this, 'ajax_trust_proxy' ) );
		add_action( 'wp_ajax_ashna_admin_fetch_arvan_ranges', array( $this, 'ajax_fetch_arvan_ranges' ) );
		add_action( 'wp_ajax_ashna_admin_sso_check', array( $this, 'ajax_sso_check' ) );
		add_action( 'admin_notices', array( $this, 'proxy_hint_notice' ) );
	}

	/**
	 * Warn when proxy headers arrive from an untrusted peer: until the CDN is trusted, every
	 * visitor behind it shares one IP and reaches the per-IP limits sooner.
	 */
	public function proxy_hint_notice() {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( $screen && ! in_array( $screen->id, array( 'dashboard', 'plugins', 'toplevel_page_ashna-otp' ), true ) ) {
			return;
		}
		$hint = Ashna_IP::untrusted_proxy_hint();
		if ( ! $hint ) {
			return;
		}
		printf(
			'<div class="notice notice-warning"><p><strong>آشنا:</strong> %s <a href="%s">%s</a></p></div>',
			esc_html( sprintf( 'درخواست‌های ورود با هدر CDN/پراکسی از آی‌پی %s می‌رسند که در فهرست پراکسی‌های مورد اعتماد نیست؛ تا اضافه نشود، کاربران پشت آن یک آی‌پی حساب می‌شوند.', $hint['remote'] ) ),
			esc_url( admin_url( 'admin.php?page=ashna-otp#security_firewall' ) ),
			'بررسی در «امنیت و ضد اسپم»'
		);
	}

	/**
	 * AJAX Handler: end attack mode now.
	 */
	public function ajax_end_attack_mode() {
		// Shape first: core's wp_verify_nonce() casts its argument, and an array casts with a PHP
		// warning on PHP 8. Short-circuit evaluation keeps that from ever reaching core.
		if ( ! isset( $_REQUEST['nonce'] ) || ! is_scalar( $_REQUEST['nonce'] ) || false === check_ajax_referer( 'ashna_admin_nonce', 'nonce', false ) ) {
			// Same refusal WordPress itself sends, and fail closed: wp_die() ends the request, so
			// the return below is only reached if something replaced the wp_die handler.
			wp_die( -1, 403 );
			return;
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			$this->clean_output_buffers();
			wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز.' ) );
			return; // wp_send_json() ends the request: never continue past a response.
		}
		Ashna_Rate_Limiter::end_attack_mode();
		$this->clean_output_buffers();
		wp_send_json_success( array( 'message' => 'حالت حمله پایان یافت؛ فرم به حالت عادی برگشت.' ) );
	}

	/**
	 * AJAX Handler: add a proxy/CDN address to the trusted list.
	 */
	public function ajax_trust_proxy() {
		// Shape first: core's wp_verify_nonce() casts its argument, and an array casts with a PHP
		// warning on PHP 8. Short-circuit evaluation keeps that from ever reaching core.
		if ( ! isset( $_REQUEST['nonce'] ) || ! is_scalar( $_REQUEST['nonce'] ) || false === check_ajax_referer( 'ashna_admin_nonce', 'nonce', false ) ) {
			// Same refusal WordPress itself sends, and fail closed: wp_die() ends the request, so
			// the return below is only reached if something replaced the wp_die handler.
			wp_die( -1, 403 );
			return;
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			$this->clean_output_buffers();
			wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز.' ) );
			return; // wp_send_json() ends the request: never continue past a response.
		}
		$ip = isset( $_POST['ip'] ) ? Ashna_IP::valid( sanitize_text_field( wp_unslash( $_POST['ip'] ) ) ) : '';
		if ( '' === $ip ) {
			$this->clean_output_buffers();
			wp_send_json_error( array( 'message' => 'آی‌پی نامعتبر است.' ) );
			return; // wp_send_json() ends the request: never continue past a response.
		}
		$settings = Ashna_Helper::get_settings();
		$list     = array_filter( array_map( 'trim', preg_split( '/[\s,]+/', (string) $settings['trusted_proxies'] ) ) );
		$list[]   = $ip;
		$settings['trusted_proxies'] = implode( "\n", array_unique( $list ) );
		Ashna_Helper::save_settings( $settings );
		delete_option( 'ashna_otp_proxy_hint' );

		$this->clean_output_buffers();
		wp_send_json_success(
			array(
				'message' => 'آی‌پی به فهرست پراکسی‌های مورد اعتماد اضافه شد.',
				'list'    => $settings['trusted_proxies'],
			)
		);
	}

	/**
	 * AJAX Handler: download ArvanCloud's published edge ranges (admin action only).
	 */
	/**
	 * AJAX: live-check one SSO provider (format + discovery). Reads the saved settings only,
	 * and never sends the client secret anywhere.
	 */
	public function ajax_sso_check() {
		// Shape first: core's wp_verify_nonce() casts its argument, and an array casts with a PHP
		// warning on PHP 8. Short-circuit evaluation keeps that from ever reaching core.
		if ( ! isset( $_REQUEST['nonce'] ) || ! is_scalar( $_REQUEST['nonce'] ) || false === check_ajax_referer( 'ashna_admin_nonce', 'nonce', false ) ) {
			wp_die( -1, 403 );
			return;
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			$this->clean_output_buffers();
			wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز.' ) );
			return;
		}

		$provider = isset( $_POST['provider'] ) ? sanitize_key( wp_unslash( $_POST['provider'] ) ) : '';
		$result   = Ashna_SSO::check_connection( $provider );
		$this->clean_output_buffers();
		if ( is_wp_error( $result ) ) {
			wp_send_json_error( array( 'message' => $result->get_error_message() ) );
			return;
		}
		wp_send_json_success( $result );
	}

	public function ajax_fetch_arvan_ranges() {
		// Shape first: core's wp_verify_nonce() casts its argument, and an array casts with a PHP
		// warning on PHP 8. Short-circuit evaluation keeps that from ever reaching core.
		if ( ! isset( $_REQUEST['nonce'] ) || ! is_scalar( $_REQUEST['nonce'] ) || false === check_ajax_referer( 'ashna_admin_nonce', 'nonce', false ) ) {
			// Same refusal WordPress itself sends, and fail closed: wp_die() ends the request, so
			// the return below is only reached if something replaced the wp_die handler.
			wp_die( -1, 403 );
			return;
		}
		if ( ! current_user_can( 'manage_options' ) ) {
			$this->clean_output_buffers();
			wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز.' ) );
			return; // wp_send_json() ends the request: never continue past a response.
		}
		$response = wp_remote_get( 'https://www.arvancloud.ir/fa/ips.txt', array( 'timeout' => 10 ) );
		$ranges   = array();
		if ( ! is_wp_error( $response ) && 200 === (int) wp_remote_retrieve_response_code( $response ) ) {
			foreach ( preg_split( '/[\s,]+/', (string) wp_remote_retrieve_body( $response ) ) as $range ) {
				$range = trim( $range );
				if ( '' !== $range && Ashna_IP::valid_range( $range ) ) {
					$ranges[] = $range;
				}
			}
		}
		$this->clean_output_buffers();
		if ( empty( $ranges ) ) {
			wp_send_json_error( array( 'message' => 'دریافت فهرست ابرآروان ممکن نشد؛ رنج‌ها را از arvancloud.ir/fa/ips.txt دستی اضافه کنید.' ) );
			return; // wp_send_json() ends the request: never continue past a response.
		}
		wp_send_json_success(
			array(
				'message' => sprintf( '%d رنج ابرآروان دریافت شد؛ برای اعمال، تنظیمات را ذخیره کنید.', count( $ranges ) ),
				'ranges'  => array_values( array_unique( $ranges ) ),
			)
		);
	}

	/**
	 * Register WordPress Admin Menus
	 */
	public function register_menus() {
		add_menu_page(
			'آشنا | ورود و ثبت‌نام یکبارمصرف',
			'ورود پیامکی (آشنا)',
			'manage_options',
			'ashna-otp',
			array( $this, 'render_settings_page' ),
			$this->get_menu_icon(),
			58
		);

		add_submenu_page(
			'ashna-otp',
			'داشبورد و تنظیمات',
			'داشبورد و تنظیمات',
			'manage_options',
			'ashna-otp',
			array( $this, 'render_settings_page' )
		);

		add_submenu_page(
			'ashna-otp',
			'لاگ کدهای ارسالی',
			'لاگ کدهای ارسالی',
			'manage_options',
			'ashna-otp-logs',
			array( $this, 'render_logs_page' )
		);
	}

	/**
	 * Monochrome Ashna shield for the admin menu.
	 *
	 * WordPress repaints base64 SVG menu icons with the user's admin color
	 * scheme, so the icon matches every scheme and its hover/current states.
	 *
	 * @return string Data URI accepted by add_menu_page().
	 */
	private function get_menu_icon() {
		$svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="280 280 464 464">'
			. '<path fill="#a7aaad" d="M491 310 C504 302 519 302 534 310 C578 332 627 350 674 363 C689 367 697 378 697 394 V436 C699 533 679 602 622 661 Q620 664 617 662 L603 654 Q598 652 598 645 V424 C598 412 591 404 579 404 H463 C450 404 443 412 443 424 V640 Q443 645 439 647 L408 663 Q406 664 404 662 C351 608 327 541 327 440 V394 C327 378 334 368 350 363 C403 348 451 330 491 310 Z"/>'
			. '<path fill="#a7aaad" d="M575 423 Q581 421 581 428 V649 Q581 657 588 661 L603 672 Q608 675 603 679 C575 699 540 720 513 720 C487 720 453 701 423 679 Q419 676 423 674 L461 654 Q468 651 468 643 V469 Q468 457 480 453 L575 423 Z"/>'
			. '</svg>';

		return 'data:image/svg+xml;base64,' . base64_encode( $svg ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode -- Documented add_menu_page() icon format.
	}

	/**
	 * Enqueue Admin CSS, Fonts, Media Uploader & JS on Ashna pages
	 *
	 * @param string $hook Current admin page hook.
	 */
	public function enqueue_admin_assets( $hook ) {
		$current_page = isset( $_GET['page'] ) ? sanitize_text_field( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( strpos( (string) $hook, 'ashna-otp' ) === false && strpos( $current_page, 'ashna-otp' ) === false ) {
			return;
		}

		if ( function_exists( 'wp_enqueue_media' ) ) {
			wp_enqueue_media();
		}

		wp_enqueue_style(
			'ashna-fonts',
			ASHNA_OTP_URL . 'assets/css/fonts.css',
			array(),
			ASHNA_OTP_VERSION
		);

		$css_file = ASHNA_OTP_PATH . 'assets/css/admin.css';
		$js_file  = ASHNA_OTP_PATH . 'assets/js/admin.js';

		// Inject CSS & JS directly from disk via WordPress inline APIs to bypass aggressive browser/CDN/LiteSpeed static file caches
		wp_register_style( 'ashna-otp-admin-core', false, array( 'ashna-fonts' ), ASHNA_OTP_VERSION );
		wp_enqueue_style( 'ashna-otp-admin-core' );
		if ( file_exists( $css_file ) ) {
			wp_add_inline_style( 'ashna-otp-admin-core', (string) file_get_contents( $css_file ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		}

		wp_register_script( 'ashna-otp-admin-core', false, array( 'jquery' ), ASHNA_OTP_VERSION, true );
		wp_enqueue_script( 'ashna-otp-admin-core' );
		// Only what the script actually reads: endpoint + nonce. The settings array used to be
		// printed here as well, which put every gateway API key and both SSO client secrets into
		// the page source (readable by any browser extension and every "view source" on an admin
		// screen). The script never used it; the export box gets its JSON from AJAX instead.
		wp_localize_script(
			'ashna-otp-admin-core',
			'ashnaAdminParams',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'ashna_admin_nonce' ),
			)
		);
		if ( file_exists( $js_file ) ) {
			wp_add_inline_script( 'ashna-otp-admin-core', (string) file_get_contents( $js_file ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		}
	}

	/**
	 * Sanitize settings array
	 *
	 * @param array $raw Raw input settings array.
	 * @return array
	 */
	private function sanitize_settings_payload( $raw ) {
		$defaults = Ashna_Helper::default_settings();
		$clean    = array();
		$existing = Ashna_Helper::get_settings();

		// A secret field is never rendered with its value, so an empty submit means "unchanged".
		$secret_keys = array( 'sso_google_client_secret', 'sso_telegram_client_secret' );

		$checkbox_keys = array(
			'auto_register',
			'allow_password_login',
			'enable_passkey',
			'passkey_prompt_after_otp',
			'passkey_wc_myaccount',
			'show_terms_checkbox',
			'send_welcome_message',
			'show_debug_code_in_toast',
			'wc_replace_myaccount',
			'wc_checkout_otp_box',
			'wp_login_integration',
			'enable_global_modal',
			'modal_mobile_sheet',
			'canvas_show_back_link',
			'glassmorphism',
			'otp_auto_submit',
			'error_shake_effect',
			'trust_proxy_headers',
			'delete_data_on_uninstall',
			'gateway_adaptive',
			'gateway_probe',
			'session_remember',
			'respect_login_gates',
			'respect_plugin_redirects',
			'login_url_to_ashna',
			'replace_member_forms',
			'dokan_vendor_signup',
			'sso_google_enabled',
			'sso_telegram_enabled',
			'sso_show_on_forms',
			'sso_ask_phone',
		);

		$int_keys = array(
			'otp_length',
			'otp_expiry',
			'resend_cooldown',
			'border_radius',
			'form_max_width',
			'standalone_page_id',
			'card_bg_opacity',
			'backdrop_blur',
			'card_padding',
			'title_font_size',
			'subtitle_font_size',
			'btn_font_size',
			'input_height',
			'digit_box_size',
			'digit_box_gap',
			'max_requests_per_hour',
			'max_ip_requests_per_hour',
			'max_verify_attempts',
			'lockout_duration',
			'log_retention_days',
			'gateway_timeout',
			'gateway_cooldown',
			'msgway_sms_line',
			'msgway_messenger_provider',
			'session_days',
			'max_requests_per_day',
			'max_ip_requests_per_minute',
			'max_subnet_requests_per_minute',
			'attack_mode_threshold',
			'attack_mode_minutes',
			'daily_send_cap',
		);

		// Integer settings where 0 means "off" — including the four windows that switch a flood
		// limit off completely (0 = unlimited), which used to be silently floored to 1.
		$zero_ok_keys = array(
			'standalone_page_id',
			'max_subnet_requests_per_minute',
			'attack_mode_threshold',
			'daily_send_cap',
			'max_requests_per_hour',
			'max_requests_per_day',
			'max_ip_requests_per_minute',
			'max_ip_requests_per_hour',
		);

		$textarea_keys = array(
			'bale_message_template',
			'email_body_text',
			'welcome_message_text',
			'split_features',
			'custom_css',
			'blocked_phones',
			'blocked_ips',
			'whitelisted_identifiers',
			'trusted_proxies',
		);

		$url_keys = array(
			'redirect_url',
			'custom_redirect_url',
			'admin_redirect_url',
			'terms_url',
			'logo_url',
			'split_image_url',
			'canvas_bg_image',
		);

		// Destinations a visitor is sent to after signing in must stay on this site: an imported
		// file (or a typo) cannot turn the login form into an open redirect.
		$redirect_url_keys = array( 'redirect_url', 'custom_redirect_url', 'admin_redirect_url' );

		foreach ( $defaults as $key => $default_val ) {
			if ( 'role_redirects' === $key ) {
				// role => URL; unknown roles and empty URLs are dropped.
				$clean[ $key ] = array();
				$roles         = function_exists( 'wp_roles' ) ? wp_roles()->get_names() : array();
				if ( isset( $raw[ $key ] ) && is_array( $raw[ $key ] ) ) {
					foreach ( $raw[ $key ] as $role => $url ) {
						$role = sanitize_key( (string) $role );
						$url  = is_scalar( $url ) ? esc_url_raw( trim( (string) $url ) ) : '';
						$url  = '' !== $url ? wp_validate_redirect( $url, '' ) : '';
						if ( '' !== $url && isset( $roles[ $role ] ) ) {
							$clean[ $key ][ $role ] = $url;
						}
					}
				}
				continue;
			}
			if ( isset( $raw[ $key ] ) && ! is_scalar( $raw[ $key ] ) ) {
				unset( $raw[ $key ] ); // A list/object where one value belongs (tampered request): keep the default.
			}
			if ( in_array( $key, $checkbox_keys, true ) ) {
				$clean[ $key ] = ! empty( $raw[ $key ] ) ? 1 : 0;
			} elseif ( in_array( $key, $int_keys, true ) ) {
				$val = isset( $raw[ $key ] ) ? absint( Ashna_Helper::convert_digits( $raw[ $key ] ) ) : $default_val;
				if ( 'border_radius' === $key || 'backdrop_blur' === $key ) {
					$clean[ $key ] = min( 32, $val );
				} elseif ( 'card_bg_opacity' === $key ) {
					$clean[ $key ] = max( 20, min( 100, $val > 0 ? $val : 85 ) );
				} elseif ( 'card_padding' === $key ) {
					$clean[ $key ] = max( 16, min( 56, $val > 0 ? $val : 32 ) );
				} elseif ( in_array( $key, $zero_ok_keys, true ) ) {
					$clean[ $key ] = $val;
				} else {
					$clean[ $key ] = $val > 0 ? $val : $default_val;
				}
			} elseif ( in_array( $key, $textarea_keys, true ) ) {
				$clean[ $key ] = isset( $raw[ $key ] ) ? sanitize_textarea_field( $raw[ $key ] ) : $default_val;
			} elseif ( in_array( $key, $url_keys, true ) ) {
				$clean[ $key ] = isset( $raw[ $key ] ) ? esc_url_raw( trim( $raw[ $key ] ) ) : '';
			} else {
				$clean[ $key ] = isset( $raw[ $key ] ) ? sanitize_text_field( $raw[ $key ] ) : $default_val;
			}
		}

		foreach ( $secret_keys as $secret_key ) {
			if ( '' === trim( (string) $clean[ $secret_key ] ) ) {
				$clean[ $secret_key ] = isset( $existing[ $secret_key ] ) ? (string) $existing[ $secret_key ] : '';
			}
		}

		foreach ( $redirect_url_keys as $redirect_key ) {
			if ( '' !== (string) $clean[ $redirect_key ] ) {
				$clean[ $redirect_key ] = wp_validate_redirect( (string) $clean[ $redirect_key ], '' );
			}
		}

		if ( isset( $raw['custom_redirect_url'] ) ) {
			$clean['redirect_url'] = $clean['custom_redirect_url'];
		} elseif ( ! empty( $clean['redirect_url'] ) && empty( $clean['custom_redirect_url'] ) ) {
			$clean['custom_redirect_url'] = $clean['redirect_url'];
		}

		$clean['otp_length']       = max( 4, min( 8, $clean['otp_length'] ) );
		$clean['form_max_width']   = max( 320, min( 640, $clean['form_max_width'] ) );
		$clean['gateway_timeout']  = max( 2, min( 15, $clean['gateway_timeout'] ) );
		$clean['gateway_cooldown'] = max( 1, min( 60, $clean['gateway_cooldown'] ) );
		$clean['session_days']     = max( 1, min( 365, $clean['session_days'] ) );
		$clean['attack_mode_minutes'] = max( 5, min( 1440, $clean['attack_mode_minutes'] ) );

		// Trusted proxies: keep valid IPs/CIDRs only, one per line.
		$proxies = array();
		foreach ( preg_split( '/[\s,]+/', (string) $clean['trusted_proxies'] ) as $range ) {
			$range = trim( $range );
			if ( '' !== $range && Ashna_IP::valid_range( $range ) ) {
				$proxies[] = $range;
			}
		}
		$clean['trusted_proxies'] = implode( "\n", array_unique( $proxies ) );
		if ( ! in_array( $clean['default_user_role'], array( 'customer', 'subscriber' ), true ) ) {
			$clean['default_user_role'] = Ashna_Auth::safe_registration_role( $clean['default_user_role'] );
		}

		return $clean;
	}

	/**
	 * Clean all active PHP output buffers before emitting JSON
	 */
	private function clean_output_buffers() {
		if ( null !== self::$ajax_buffer_level ) {
			// Drop only what was printed after our own buffer started; outer buffers (compression,
			// caching, the server's own) belong to someone else and stay untouched.
			while ( ob_get_level() > self::$ajax_buffer_level + 1 ) {
				ob_end_clean();
			}
			if ( ob_get_level() === self::$ajax_buffer_level + 1 && ob_get_length() ) {
				ob_clean();
			}
			return;
		}
		// No buffer of ours: drop stray output from this request only if there is any.
		if ( ob_get_level() > 0 && ob_get_length() ) {
			ob_clean();
		}
	}

	/**
	 * Verify admin settings request nonce (accepts either AJAX nonce or form nonce)
	 *
	 * @return bool
	 */
	private function verify_settings_nonce() {
		if ( isset( $_POST['nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['nonce'] ) ), 'ashna_admin_nonce' ) ) {
			return true;
		}
		if ( isset( $_POST['ashna_settings_nonce'] ) && wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['ashna_settings_nonce'] ) ), 'ashna_save_settings_action' ) ) {
			return true;
		}
		return false;
	}

	/**
	 * Handle form submissions (Fallback POST Save, Clear Logs, Export CSV)
	 */
	public function handle_actions() {
		if ( wp_doing_ajax() || ! current_user_can( 'manage_options' ) ) {
			return;
		}

		// 1. Classic Form POST Save Settings
		if ( isset( $_POST['ashna_save_settings'] ) && $this->verify_settings_nonce() ) {
			$raw   = isset( $_POST['ashna'] ) && is_array( $_POST['ashna'] ) ? wp_unslash( $_POST['ashna'] ) : array(); // phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			$clean = $this->sanitize_settings_payload( $raw );

			Ashna_Helper::save_settings( $clean );
			Ashna_Failover::reset_circuits(); // Retry sidelined gateways right after a settings change.
			$this->settings_saved_in_request = true;

			if ( ! headers_sent() ) {
				wp_safe_redirect( add_query_arg( 'settings-updated', 'true', admin_url( 'admin.php?page=ashna-otp' ) ) );
				exit;
			}
			$_GET['settings-updated'] = 'true';
		}

		// 2. Clear Logs
		if ( isset( $_POST['ashna_clear_logs'] ) && check_admin_referer( 'ashna_clear_logs_action', 'ashna_logs_nonce' ) ) {
			$clear_type = isset( $_POST['clear_type'] ) ? sanitize_text_field( wp_unslash( $_POST['clear_type'] ) ) : 'old';
			Ashna_Logger::clear_logs( 'all' === $clear_type );

			wp_safe_redirect( add_query_arg( 'logs-cleared', 'true', admin_url( 'admin.php?page=ashna-otp-logs' ) ) );
			exit;
		}

		// 3. Export CSV Logs
		if ( isset( $_GET['ashna_export_logs_csv'] ) && check_admin_referer( 'ashna_export_csv_action', 'nonce' ) ) {
			header( 'Content-Type: text/csv; charset=utf-8' );
			header( 'Content-Disposition: attachment; filename=ashna-otp-logs-' . gmdate( 'Y-m-d' ) . '.csv' );

			$out = fopen( 'php://output', 'w' );
			self::write_logs_csv( $out );
			fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- php://output stream, not a file.
			exit;
		}
	}

	/**
	 * Write the latest 2000 log rows as CSV (UTF-8 BOM for Excel).
	 *
	 * @param resource $out Writable stream.
	 */
	public static function write_logs_csv( $out ) {
		$logs_data = Ashna_Logger::get_logs(
			array(
				'per_page' => 2000,
				'paged'    => 1,
			)
		);
		fwrite( $out, "\xEF\xBB\xBF" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
		// Plain RFC 4180 quoting (empty $escape): PHP 8.4 deprecates relying on the old "\\" default.
		fputcsv( $out, array( 'ID', 'Recipient', 'Channel', 'Gateway', 'OTP Code', 'Status', 'Attempts', 'IP Address', 'Response', 'Created At', 'Verified At' ), ',', '"', '' );
		foreach ( $logs_data['items'] as $row ) {
			fputcsv(
				$out,
				array_map(
					array( __CLASS__, 'csv_cell' ),
					array( $row->id, $row->recipient, $row->channel, $row->gateway, $row->otp_code, $row->status, $row->attempts, $row->ip_address, $row->response_message, $row->created_at, $row->verified_at )
				),
				',',
				'"',
				''
			);
		}
	}

	/**
	 * Neutralize spreadsheet formulas: a cell starting with = + - @ (or tab/CR) is prefixed
	 * with an apostrophe, so e.g. an e-mail like "=1+1@x.co" is shown as text in Excel.
	 *
	 * @param mixed $value Cell value.
	 * @return string
	 */
	public static function csv_cell( $value ) {
		$value = (string) $value;
		if ( '' !== $value && in_array( $value[0], array( '=', '+', '-', '@', "\t", "\r" ), true ) ) {
			return "'" . $value;
		}
		return $value;
	}

	/**
	 * AJAX Handler: Live Save Settings without page reload
	 */
	public function ajax_save_settings() {
		if ( ! current_user_can( 'manage_options' ) || ! $this->verify_settings_nonce() ) {
			$this->clean_output_buffers();
			wp_send_json_error( array( 'message' => 'نشست امنیتی منقضی شده است؛ لطفاً صفحه را رفرش کنید.' ) );
			return; // wp_send_json() ends the request: never continue past a response.
		}

		$raw   = isset( $_POST['ashna'] ) && is_array( $_POST['ashna'] ) ? wp_unslash( $_POST['ashna'] ) : array(); // phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$clean = $this->sanitize_settings_payload( $raw );

		Ashna_Helper::save_settings( $clean );
		Ashna_Failover::reset_circuits(); // Retry sidelined gateways right after a settings change.

		$this->clean_output_buffers();

		wp_send_json_success(
			array(
				'message'  => 'تنظیمات با موفقیت ذخیره شد!',
				'settings' => $clean,
			)
		);
	}

	/**
	 * AJAX Handler: Test Gateway from Admin Panel
	 */
	public function ajax_test_gateway() {
		// Shape first: core's wp_verify_nonce() casts its argument, and an array casts with a PHP
		// warning on PHP 8. Short-circuit evaluation keeps that from ever reaching core.
		if ( ! isset( $_REQUEST['nonce'] ) || ! is_scalar( $_REQUEST['nonce'] ) || false === check_ajax_referer( 'ashna_admin_nonce', 'nonce', false ) ) {
			// Same refusal WordPress itself sends, and fail closed: wp_die() ends the request, so
			// the return below is only reached if something replaced the wp_die handler.
			wp_die( -1, 403 );
			return;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			$this->clean_output_buffers();
			wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز.' ) );
			return; // wp_send_json() ends the request: never continue past a response.
		}

		$recipient  = isset( $_POST['recipient'] ) ? sanitize_text_field( wp_unslash( $_POST['recipient'] ) ) : '';
		$channel    = isset( $_POST['channel'] ) ? sanitize_text_field( wp_unslash( $_POST['channel'] ) ) : 'sms';
		$gateway_id = isset( $_POST['gateway_id'] ) ? sanitize_text_field( wp_unslash( $_POST['gateway_id'] ) ) : '';

		if ( empty( $recipient ) ) {
			$this->clean_output_buffers();
			wp_send_json_error( array( 'message' => 'لطفاً شماره موبایل یا ایمیل تست را وارد کنید.' ) );
			return; // wp_send_json() ends the request: never continue past a response.
		}

		$parsed = Ashna_Helper::parse_identifier( $recipient );
		if ( 'invalid' === $parsed['type'] ) {
			$this->clean_output_buffers();
			wp_send_json_error( array( 'message' => 'شماره موبایل یا آدرس ایمیل وارد شده معتبر نیست.' ) );
			return; // wp_send_json() ends the request: never continue past a response.
		}

		$result = Ashna_Gateway_Manager::dispatch_otp( $parsed['normalized'], $parsed['type'], $channel, $gateway_id );
		$this->clean_output_buffers();
		if ( is_wp_error( $result ) ) {
			wp_send_json_error(
				array(
					'message' => 'خطا در ارسال تست: ' . $result->get_error_message(),
				)
			);
			return; // wp_send_json() ends the request: never continue past a response.
		}

		wp_send_json_success(
			array(
				'message' => sprintf(
					'ارسال تست موفق! کد تولیدشده: %s | درگاه: %s | زمان: %s ثانیه | پاسخ: %s',
					$result['code'],
					$result['gateway'],
					number_format( $result['elapsed_ms'] / 1000, 1 ),
					$result['response']
				),
			)
		);
	}

	/**
	 * AJAX Handler: Clear gateway health data and bring sidelined gateways back
	 */
	public function ajax_reset_gateway_health() {
		// Shape first: core's wp_verify_nonce() casts its argument, and an array casts with a PHP
		// warning on PHP 8. Short-circuit evaluation keeps that from ever reaching core.
		if ( ! isset( $_REQUEST['nonce'] ) || ! is_scalar( $_REQUEST['nonce'] ) || false === check_ajax_referer( 'ashna_admin_nonce', 'nonce', false ) ) {
			// Same refusal WordPress itself sends, and fail closed: wp_die() ends the request, so
			// the return below is only reached if something replaced the wp_die handler.
			wp_die( -1, 403 );
			return;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			$this->clean_output_buffers();
			wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز.' ) );
			return; // wp_send_json() ends the request: never continue past a response.
		}

		Ashna_Failover::reset_all();

		$this->clean_output_buffers();
		wp_send_json_success( array( 'message' => 'وضعیت درگاه‌ها بازنشانی شد؛ همه درگاه‌ها دوباره در مسیر ارسال قرار گرفتند.' ) );
	}

	/**
	 * AJAX Handler: Unlock a locked-out phone or IP immediately
	 */
	public function ajax_unlock_target() {
		// Shape first: core's wp_verify_nonce() casts its argument, and an array casts with a PHP
		// warning on PHP 8. Short-circuit evaluation keeps that from ever reaching core.
		if ( ! isset( $_REQUEST['nonce'] ) || ! is_scalar( $_REQUEST['nonce'] ) || false === check_ajax_referer( 'ashna_admin_nonce', 'nonce', false ) ) {
			// Same refusal WordPress itself sends, and fail closed: wp_die() ends the request, so
			// the return below is only reached if something replaced the wp_die handler.
			wp_die( -1, 403 );
			return;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			$this->clean_output_buffers();
			wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز.' ) );
			return; // wp_send_json() ends the request: never continue past a response.
		}

		$target = isset( $_POST['target'] ) ? sanitize_text_field( wp_unslash( $_POST['target'] ) ) : '';
		if ( empty( $target ) ) {
			$this->clean_output_buffers();
			wp_send_json_error( array( 'message' => 'شناسه نامعتبر است.' ) );
			return; // wp_send_json() ends the request: never continue past a response.
		}

		Ashna_Security::unlock_target( $target );
		$this->clean_output_buffers();
		wp_send_json_success( array( 'message' => 'رفع مسدودی با موفقیت انجام شد.' ) );
	}

	/**
	 * AJAX Handler: Import JSON Settings
	 */
	public function ajax_import_settings() {
		// Shape first: core's wp_verify_nonce() casts its argument, and an array casts with a PHP
		// warning on PHP 8. Short-circuit evaluation keeps that from ever reaching core.
		if ( ! isset( $_REQUEST['nonce'] ) || ! is_scalar( $_REQUEST['nonce'] ) || false === check_ajax_referer( 'ashna_admin_nonce', 'nonce', false ) ) {
			// Same refusal WordPress itself sends, and fail closed: wp_die() ends the request, so
			// the return below is only reached if something replaced the wp_die handler.
			wp_die( -1, 403 );
			return;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			$this->clean_output_buffers();
			wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز.' ) );
			return; // wp_send_json() ends the request: never continue past a response.
		}

		$json_raw = isset( $_POST['json_data'] ) ? Ashna_Helper::as_string( wp_unslash( $_POST['json_data'] ) ) : ''; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$decoded  = json_decode( $json_raw, true );

		if ( ! is_array( $decoded ) ) {
			$this->clean_output_buffers();
			wp_send_json_error( array( 'message' => 'فرمت فایل یا متن JSON معتبر نیست.' ) );
			return; // wp_send_json() ends the request: never continue past a response.
		}

		// A file from an older version (or a partial one) lacks newer keys. On/off settings that
		// are missing must keep their defaults instead of being read as "unchecked" (= off).
		$clean = $this->sanitize_settings_payload( array_merge( Ashna_Helper::default_settings(), $decoded ) );
		Ashna_Helper::save_settings( $clean );
		Ashna_Failover::reset_circuits();

		$this->clean_output_buffers();
		wp_send_json_success( array( 'message' => 'تنظیمات با موفقیت درون‌ریزی شد! در حال بارگذاری مجدد...' ) );
	}

	/**
	 * AJAX Handler: Reset Settings to Factory Defaults
	 */
	public function ajax_reset_settings() {
		// Shape first: core's wp_verify_nonce() casts its argument, and an array casts with a PHP
		// warning on PHP 8. Short-circuit evaluation keeps that from ever reaching core.
		if ( ! isset( $_REQUEST['nonce'] ) || ! is_scalar( $_REQUEST['nonce'] ) || false === check_ajax_referer( 'ashna_admin_nonce', 'nonce', false ) ) {
			// Same refusal WordPress itself sends, and fail closed: wp_die() ends the request, so
			// the return below is only reached if something replaced the wp_die handler.
			wp_die( -1, 403 );
			return;
		}

		if ( ! current_user_can( 'manage_options' ) ) {
			$this->clean_output_buffers();
			wp_send_json_error( array( 'message' => 'دسترسی غیرمجاز.' ) );
			return; // wp_send_json() ends the request: never continue past a response.
		}

		Ashna_Helper::save_settings( Ashna_Helper::default_settings() );
		Ashna_Failover::reset_circuits(); // Retry sidelined gateways right after a settings change.

		$this->clean_output_buffers();
		wp_send_json_success( array( 'message' => 'تمام تنظیمات به حالت پیش‌فرض بازنشانی شد!' ) );
	}

	/**
	 * Render Settings Page
	 */
	public function render_settings_page() {
		if ( ! $this->settings_saved_in_request && isset( $_POST['ashna_save_settings'] ) && current_user_can( 'manage_options' ) && $this->verify_settings_nonce() ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			$raw   = isset( $_POST['ashna'] ) && is_array( $_POST['ashna'] ) ? wp_unslash( $_POST['ashna'] ) : array(); // phpcs:ignore WordPress.Security.NonceVerification.Missing,WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			$clean = $this->sanitize_settings_payload( $raw );

			Ashna_Helper::save_settings( $clean );
			Ashna_Failover::reset_circuits(); // Retry sidelined gateways right after a settings change.
			$this->settings_saved_in_request = true;
			$_GET['settings-updated']        = 'true';
		}

		$settings        = Ashna_Helper::get_settings();
		$sms_gateways    = Ashna_Gateway_Manager::get_sms_gateways();
		$stats           = Ashna_Logger::get_stats();
		$chart_data      = Ashna_Logger::get_daily_chart_data( 7 );
		$recent_logs     = Ashna_Logger::get_logs( array( 'per_page' => 6, 'paged' => 1 ) )['items'];
		$active_lockouts = Ashna_Security::get_active_lockouts();

		include __DIR__ . '/admin/views/settings-page.php';
	}

	/**
	 * Render Logs Page
	 */
	public function render_logs_page() {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended
		$paged   = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1;
		$search  = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
		$status  = isset( $_GET['status'] ) ? sanitize_text_field( wp_unslash( $_GET['status'] ) ) : '';
		$channel = isset( $_GET['channel'] ) ? sanitize_text_field( wp_unslash( $_GET['channel'] ) ) : '';
		// phpcs:enable

		$per_page  = 20;
		$logs_data = Ashna_Logger::get_logs(
			array(
				'per_page' => $per_page,
				'paged'    => $paged,
				'search'   => $search,
				'status'   => $status,
				'channel'  => $channel,
			)
		);
		$stats     = Ashna_Logger::get_stats();

		include __DIR__ . '/admin/views/logs-page.php';
	}
}


// ---- Source: includes/integrations/class-ashna-integrations.php ----
/**
 * Integrations with other plugins: one login page for every "log in" link, member login
 * forms (Paid Memberships Pro, Ultimate Member, MemberPress) served by Ashna, per-role
 * destinations after sign-in, Dokan vendors and Ultimate Member account approval.
 *
 * Everything goes through hooks those plugins and WordPress already expose, so nothing
 * here runs unless the related plugin is active.
 *
 * @package Ashna
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Ashna_Integrations {

	/**
	 * Shortcodes whose guest login form Ashna replaces.
	 */
	const MEMBER_LOGIN_SHORTCODES = array( 'pmpro_login', 'mepr-login-form', 'ultimatemember' );

	/**
	 * Register hooks once WordPress and all plugins are loaded.
	 */
	public static function init() {
		if ( did_action( 'init' ) ) {
			self::boot();
		} else {
			add_action( 'init', array( __CLASS__, 'boot' ), 1 );
		}
	}

	/**
	 * Hook everything up.
	 */
	public static function boot() {
		static $booted = false;
		if ( $booted ) {
			return;
		}
		$booted = true;

		add_filter( 'login_url', array( __CLASS__, 'filter_login_url' ), 99, 3 );
		add_filter( 'register_url', array( __CLASS__, 'filter_register_url' ), 99 );
		add_filter( 'pmpro_login_url', array( __CLASS__, 'filter_login_url' ), 99, 3 );
		add_filter( 'pre_do_shortcode_tag', array( __CLASS__, 'replace_member_login_form' ), 10, 3 );
		add_filter( 'ashna_otp_pinned_redirect', array( __CLASS__, 'role_redirect' ), 10, 2 );

		Ashna_Integration_Dokan::boot();
		Ashna_Integration_UM::boot();
	}

	/**
	 * URL of Ashna's dedicated login page ('' when none is set up).
	 *
	 * @param string $redirect Optional destination after sign-in.
	 * @return string
	 */
	public static function login_page_url( $redirect = '' ) {
		$page_id = absint( Ashna_Helper::get_option( 'standalone_page_id', 0 ) );
		if ( $page_id <= 0 || 'publish' !== get_post_status( $page_id ) ) {
			return '';
		}
		$url = (string) get_permalink( $page_id );
		if ( '' !== $url && '' !== (string) $redirect ) {
			$url = add_query_arg( 'redirect_to', rawurlencode( $redirect ), $url );
		}
		return $url;
	}

	/**
	 * Send front-end "log in" links (themes, comments, Paid Memberships Pro, any plugin using
	 * wp_login_url()) to Ashna's login page. wp-admin keeps wp-login.php (session-expired
	 * pop-up and re-authentication need it).
	 *
	 * @param string $login_url    Login URL.
	 * @param string $redirect     Destination after sign-in.
	 * @param bool   $force_reauth Re-authentication requested.
	 * @return string
	 */
	public static function filter_login_url( $login_url, $redirect = '', $force_reauth = false ) {
		if ( $force_reauth || is_admin() || ! Ashna_Helper::get_option( 'login_url_to_ashna', 1 ) ) {
			return $login_url;
		}
		$page = self::login_page_url( $redirect );
		return '' !== $page ? $page : $login_url;
	}

	/**
	 * "Register" links lead to the same page: the first OTP sign-in creates the account.
	 *
	 * @param string $register_url Registration URL.
	 * @return string
	 */
	public static function filter_register_url( $register_url ) {
		if ( is_admin() || ! Ashna_Helper::get_option( 'login_url_to_ashna', 1 ) || ! Ashna_Helper::get_option( 'auto_register', 1 ) ) {
			return $register_url;
		}
		$page = self::login_page_url();
		return '' !== $page ? $page : $register_url;
	}

	/**
	 * Show Ashna's form instead of the guest login form of membership plugins:
	 * [pmpro_login] (Paid Memberships Pro), [mepr-login-form] (MemberPress) and Ultimate
	 * Member login forms ([ultimatemember form_id="…"] whose form mode is "login").
	 * Logged-in visitors and password-reset screens keep the plugin's own output.
	 *
	 * @param false|string $output Short-circuit output.
	 * @param string       $tag    Shortcode tag.
	 * @param array|string $attr   Attributes.
	 * @return false|string
	 */
	public static function replace_member_login_form( $output, $tag, $attr ) {
		if ( false !== $output || ! in_array( $tag, self::MEMBER_LOGIN_SHORTCODES, true ) ) {
			return $output;
		}
		if ( is_user_logged_in() || ! Ashna_Helper::get_option( 'replace_member_forms', 1 ) ) {
			return $output;
		}
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- read-only routing of a public page.
		if ( isset( $_GET['action'] ) && in_array( sanitize_key( Ashna_Helper::as_string( wp_unslash( $_GET['action'] ) ) ), array( 'lostpassword', 'reset_pass', 'resetpass', 'rp', 'forgot_password', 'reset' ), true ) ) {
			return $output;
		}
		if ( 'ultimatemember' === $tag ) {
			$form_id = is_array( $attr ) && isset( $attr['form_id'] ) ? absint( $attr['form_id'] ) : 0;
			if ( ! $form_id || 'login' !== get_post_meta( $form_id, '_um_mode', true ) ) {
				return $output;
			}
		}
		$redirect = isset( $_REQUEST['redirect_to'] ) ? esc_url_raw( Ashna_Helper::as_string( wp_unslash( $_REQUEST['redirect_to'] ) ) ) : '';
		if ( '' === $redirect && is_array( $attr ) && ! empty( $attr['redirect'] ) ) {
			$redirect = esc_url_raw( $attr['redirect'] );
		}
		// phpcs:enable

		Ashna_Frontend::instance()->enqueue_assets( true );
		return Ashna_Frontend::get_login_form_html(
			array(
				'redirect' => $redirect,
				'context'  => 'member-' . sanitize_key( $tag ),
			)
		);
	}

	/**
	 * Destination pinned for the user's role (Integrations tab).
	 *
	 * @param string  $pinned Already pinned URL.
	 * @param WP_User $user   User.
	 * @return string
	 */
	public static function role_redirect( $pinned, $user ) {
		if ( '' !== (string) $pinned || ! $user instanceof WP_User ) {
			return $pinned;
		}
		$map = Ashna_Helper::get_option( 'role_redirects', array() );
		if ( ! is_array( $map ) ) {
			return $pinned;
		}
		foreach ( (array) $user->roles as $role ) {
			if ( ! empty( $map[ $role ] ) ) {
				return esc_url_raw( $map[ $role ] );
			}
		}
		return $pinned;
	}

	/**
	 * Supported plugins found on this site (for the settings screen).
	 *
	 * @return array<string, array{name: string, active: bool}>
	 */
	public static function detected() {
		return array(
			'woocommerce' => array(
				'name'   => 'ووکامرس',
				'active' => class_exists( 'WooCommerce' ),
			),
			'dokan'       => array(
				'name'   => 'دکان (Dokan)',
				'active' => Ashna_Integration_Dokan::active(),
			),
			'um'          => array(
				'name'   => 'Ultimate Member',
				'active' => Ashna_Integration_UM::active(),
			),
			'pmpro'       => array(
				'name'   => 'Paid Memberships Pro',
				'active' => defined( 'PMPRO_VERSION' ) || function_exists( 'pmpro_login_url' ),
			),
			'memberpress' => array(
				'name'   => 'MemberPress',
				'active' => defined( 'MEPR_VERSION' ) || class_exists( 'MeprUser' ),
			),
			'wcm'         => array(
				'name'   => 'WooCommerce Memberships',
				'active' => function_exists( 'wc_memberships' ),
			),
		);
	}
}


// ---- Source: includes/integrations/class-ashna-integration-dokan.php ----
/**
 * Dokan (multi-vendor marketplace) integration.
 *
 * - Vendors signing in with a code land on their vendor dashboard: Ashna applies the same
 *   `woocommerce_login_redirect` / `woocommerce_registration_redirect` filters Dokan uses on
 *   WooCommerce's own forms (dashboard, or the vendor setup wizard after signing up).
 * - Vendor sign-up inside the OTP form: shop name, shop URL, name; the verified mobile is
 *   the store phone. The account is created through WooCommerce's customer pipeline, so
 *   Dokan's own code (Registration::set_new_vendor_names / save_vendor_info, the
 *   "enable selling" rule on user_register and `dokan_new_seller_created`) sets the vendor up.
 * - Dokan's "please log in" redirect for its dashboard points to Ashna's login page.
 * - Vendors whose mobile only lives in their store profile can sign in with it.
 *
 * @package Ashna
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// phpcs:disable WordPress.Security.NonceVerification.Missing -- every AJAX handler below calls Ashna_Session::verify_request() first.
class Ashna_Integration_Dokan {

	/**
	 * Nonce action of Ashna's dedicated vendor sign-up form ([ashna_otp_login vendor="yes"]).
	 */
	const VENDOR_FORM_ACTION = 'ashna_vendor_form';

	/**
	 * Request state saved while Dokan's sign-up hooks run.
	 *
	 * @var array|null
	 */
	private static $pending = null;

	/**
	 * Whether Dokan is active.
	 *
	 * @return bool
	 */
	public static function active() {
		return function_exists( 'dokan' ) || function_exists( 'dokan_get_option' );
	}

	/**
	 * Register hooks (only with Dokan).
	 */
	public static function boot() {
		if ( ! self::active() ) {
			return;
		}
		add_filter( 'dokan_redirect_login', array( __CLASS__, 'login_page' ) );
		add_filter( 'ashna_otp_registration_data', array( __CLASS__, 'registration_data' ), 10, 4 );
		add_filter( 'ashna_otp_registration_errors', array( __CLASS__, 'validate' ), 10, 4 );
		add_action( 'ashna_otp_before_register_user', array( __CLASS__, 'before_register' ), 10, 3 );
		add_action( 'ashna_otp_after_register_user', array( __CLASS__, 'after_register' ), 10, 4 );
		add_filter( 'ashna_otp_phone_candidates', array( __CLASS__, 'phone_candidates' ), 10, 2 );
		add_action( 'wp_ajax_nopriv_ashna_dokan_check_shopurl', array( __CLASS__, 'ajax_check_shopurl' ) );
		add_action( 'wp_ajax_ashna_dokan_check_shopurl', array( __CLASS__, 'ajax_check_shopurl' ) );
	}

	/**
	 * Whether visitors may sign up as vendors in this form.
	 *
	 * @param bool $vendor_form True on a dedicated vendor sign-up page (like Dokan's own
	 *                          vendor registration page, it ignores the "show vendor option
	 *                          on the WooCommerce form" setting).
	 * @return bool
	 */
	public static function vendor_signup_allowed( $vendor_form = false ) {
		if ( ! self::active() || ! Ashna_Helper::get_option( 'dokan_vendor_signup', 1 ) || ! Ashna_Helper::get_option( 'auto_register', 1 ) ) {
			return false;
		}
		if ( $vendor_form ) {
			return true;
		}
		return ! function_exists( 'dokan_get_option' ) || 'off' !== dokan_get_option( 'show_register_as_vendor', 'dokan_appearance', 'on' );
	}

	/**
	 * Store URL prefix shown next to the shop URL field.
	 *
	 * @return string
	 */
	public static function store_url_base() {
		$base = function_exists( 'dokan_get_option' ) ? (string) dokan_get_option( 'custom_store_url', 'dokan_general', 'store' ) : 'store';
		return trailingslashit( home_url( '/' . trim( '' !== $base ? $base : 'store', '/' ) ) );
	}

	/**
	 * Dokan sends guests from the vendor dashboard to a login page: use Ashna's.
	 *
	 * @param string $url Login URL.
	 * @return string
	 */
	public static function login_page( $url ) {
		if ( ! Ashna_Helper::get_option( 'login_url_to_ashna', 1 ) ) {
			return $url;
		}
		$dashboard = function_exists( 'dokan_get_navigation_url' ) ? dokan_get_navigation_url() : '';
		$page      = Ashna_Integrations::login_page_url( $dashboard );
		return '' !== $page ? $page : $url;
	}

	/**
	 * Normalize a shop URL slug (Latin letters, digits and hyphens).
	 *
	 * @param string $raw Raw value.
	 * @return string
	 */
	public static function shop_slug( $raw ) {
		$slug = strtolower( remove_accents( sanitize_text_field( Ashna_Helper::as_string( $raw ) ) ) );
		$slug = preg_replace( '/[^a-z0-9]+/', '-', $slug );
		return substr( trim( (string) $slug, '-' ), 0, 50 );
	}

	/**
	 * Read the vendor fields of the verify request.
	 *
	 * @param array  $data       Sign-up data.
	 * @param array  $post       Request.
	 * @param string $identifier Normalized phone/email.
	 * @param string $type       phone|email.
	 * @return array
	 */
	public static function registration_data( $data, $post, $identifier, $type ) {
		if ( ! isset( $post['account_type'] ) || 'seller' !== sanitize_key( $post['account_type'] ) ) {
			return $data;
		}
		$field = static function ( $key ) use ( $post ) {
			return isset( $post[ $key ] ) ? trim( sanitize_text_field( $post[ $key ] ) ) : '';
		};

		$vendor_form = isset( $post['vendor_form_nonce'] ) && false !== wp_verify_nonce( sanitize_key( $post['vendor_form_nonce'] ), self::VENDOR_FORM_ACTION );
		$phone       = 'phone' === $type ? $identifier : Ashna_Helper::normalize_phone( $field( 'phone' ) );

		$data['account_type'] = 'seller';
		$data['vendor']       = array(
			'fname'       => $field( 'fname' ),
			'lname'       => $field( 'lname' ),
			'shopname'    => $field( 'shopname' ),
			'shopurl'     => self::shop_slug( $field( 'shopurl' ) ),
			'phone'       => $phone,
			'vendor_form' => $vendor_form,
		);
		if ( empty( $data['full_name'] ) ) {
			$data['full_name'] = trim( $data['vendor']['fname'] . ' ' . $data['vendor']['lname'] );
		}
		return $data;
	}

	/**
	 * Validate vendor sign-up before the code is checked (Dokan's required fields + unique URL).
	 *
	 * @param null|WP_Error $error      Error so far.
	 * @param array         $data       Sign-up data.
	 * @param string        $identifier Normalized phone/email.
	 * @param string        $type       phone|email.
	 * @return null|WP_Error
	 */
	public static function validate( $error, $data, $identifier, $type ) {
		if ( is_wp_error( $error ) || empty( $data['account_type'] ) || 'seller' !== $data['account_type'] ) {
			return $error;
		}
		$vendor = $data['vendor'];
		if ( ! self::vendor_signup_allowed( ! empty( $vendor['vendor_form'] ) ) ) {
			return new WP_Error( 'ashna_vendor_disabled', 'ثبت‌نام فروشنده در این فرم فعال نیست.' );
		}

		$messages = array(
			'fname'    => 'لطفاً نام خود را وارد کنید.',
			'lname'    => 'لطفاً نام خانوادگی خود را وارد کنید.',
			'phone'    => 'لطفاً شماره موبایل فروشگاه را وارد کنید.',
			'shopname' => 'لطفاً نام فروشگاه را وارد کنید.',
			'shopurl'  => 'لطفاً آدرس فروشگاه را با حروف انگلیسی وارد کنید.',
		);
		// Dokan decides which fields are required (its own filter); Ashna shows Persian messages.
		$required = apply_filters( 'dokan_seller_registration_required_fields', $messages );
		foreach ( (array) $required as $key => $message ) {
			if ( ! array_key_exists( $key, $vendor ) ) {
				continue; // Fields added by other plugins are validated by them.
			}
			if ( '' === (string) $vendor[ $key ] ) {
				return new WP_Error( 'ashna_vendor_' . $key, isset( $messages[ $key ] ) ? $messages[ $key ] : wp_strip_all_tags( (string) $message ), $key );
			}
		}
		if ( 'email' === $type && '' !== $vendor['phone'] && ! Ashna_Helper::is_valid_phone( $vendor['phone'] ) ) {
			return new WP_Error( 'ashna_vendor_phone', 'شماره موبایل فروشگاه معتبر نیست. (مثال: 09123456789)', 'phone' );
		}
		if ( '' !== $vendor['shopurl'] && get_user_by( 'slug', $vendor['shopurl'] ) ) {
			return new WP_Error( 'ashna_vendor_shopurl_taken', 'این آدرس فروشگاه قبلاً ثبت شده است؛ آدرس دیگری انتخاب کنید.', 'shopurl' );
		}
		return $error;
	}

	/**
	 * Let Dokan set up the vendor during the account creation.
	 *
	 * @param string $identifier Normalized phone/email.
	 * @param string $type       phone|email.
	 * @param array  $extra      Sign-up data.
	 */
	public static function before_register( $identifier, $type, $extra ) {
		if ( empty( $extra['account_type'] ) || 'seller' !== $extra['account_type'] || empty( $extra['vendor'] ) ) {
			return;
		}
		$vendor        = $extra['vendor'];
		self::$pending = array(
			'post'   => $_POST, // phpcs:ignore WordPress.Security.NonceVerification.Missing -- restored right after.
			'vendor' => $vendor,
		);

		// Dokan reads its sign-up fields from the request, exactly as on its own forms.
		$_POST['role']     = 'seller';
		$_POST['fname']    = $vendor['fname'];
		$_POST['lname']    = $vendor['lname'];
		$_POST['shopname'] = $vendor['shopname'];
		$_POST['shopurl']  = $vendor['shopurl'];
		$_POST['phone']    = $vendor['phone'];

		// Ashna already verified its form nonce and the one-time code; this documented Dokan
		// switch lets third-party sign-ups skip the WooCommerce register-form nonce.
		add_filter( 'dokan_register_nonce_check', '__return_false', 99 );
	}

	/**
	 * Clean up and make sure the vendor exists even on Dokan versions without those hooks.
	 *
	 * @param WP_User|WP_Error $result     New user.
	 * @param string           $identifier Normalized phone/email.
	 * @param string           $type       phone|email.
	 * @param array            $extra      Sign-up data.
	 */
	public static function after_register( $result, $identifier, $type, $extra ) {
		if ( null === self::$pending ) {
			return;
		}
		$pending       = self::$pending;
		self::$pending = null;
		remove_filter( 'dokan_register_nonce_check', '__return_false', 99 );
		$_POST = $pending['post'];

		if ( ! $result instanceof WP_User ) {
			return;
		}
		$user   = get_user_by( 'id', $result->ID );
		$vendor = $pending['vendor'];
		if ( $user && ! in_array( 'seller', (array) $user->roles, true ) && function_exists( 'dokan_user_update_to_seller' ) ) {
			dokan_user_update_to_seller(
				$user,
				array(
					'fname'    => $vendor['fname'],
					'lname'    => $vendor['lname'],
					'shopname' => $vendor['shopname'],
					'shopurl'  => $vendor['shopurl'],
					'phone'    => $vendor['phone'],
					'address'  => array(),
				)
			);
		}
		update_user_meta( $result->ID, 'ashna_registered_as_vendor', 1 );
	}

	/**
	 * Vendors whose mobile is only stored in their Dokan store profile.
	 *
	 * @param int[]  $ids        Candidates so far.
	 * @param string $identifier Normalized phone.
	 * @return int[]
	 */
	public static function phone_candidates( $ids, $identifier ) {
		$forms = array_unique(
			array(
				$identifier,
				Ashna_Helper::to_international_phone( $identifier, true ),
				Ashna_Helper::to_international_phone( $identifier, false ),
				ltrim( $identifier, '0' ),
			)
		);
		$query = array( 'relation' => 'OR' );
		foreach ( $forms as $form ) {
			$query[] = array(
				'key'     => 'dokan_profile_settings',
				'value'   => sprintf( '"phone";s:%d:"%s";', strlen( $form ), $form ),
				'compare' => 'LIKE',
			);
		}
		$found = get_users(
			array(
				'meta_query'  => $query, // phpcs:ignore WordPress.DB.SlowDBQuery.slow_db_query_meta_query
				'number'      => 5,
				'fields'      => 'ID',
				'count_total' => false,
			)
		);
		return array_merge( (array) $ids, array_map( 'absint', (array) $found ) );
	}

	/**
	 * AJAX: is a shop URL free?
	 */
	public static function ajax_check_shopurl() {
		if ( true !== Ashna_Session::verify_request() ) {
			return;
		}
		$slug = self::shop_slug( isset( $_POST['shopurl'] ) ? wp_unslash( $_POST['shopurl'] ) : '' ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized -- shop_slug() sanitizes.
		Ashna_Session::send_json(
			true,
			array(
				'slug'      => $slug,
				'available' => '' !== $slug && ! get_user_by( 'slug', $slug ),
				'url'       => self::store_url_base() . $slug,
			)
		);
		return; // wp_send_json() ends the request: never continue past a response.
	}
}
// phpcs:enable WordPress.Security.NonceVerification.Missing


// ---- Source: includes/integrations/class-ashna-integration-um.php ----
/**
 * Ultimate Member integration.
 *
 * - Account status is respected: inactive, rejected and not-yet-approved accounts cannot
 *   sign in with a code either (same rule UM applies on wp-login.php).
 * - New accounts get the status of their role's registration setting (approved / pending
 *   review). An "awaiting e-mail confirmation" account that proves its e-mail with an OTP
 *   is approved, because the code just confirmed that address.
 * - On UM login pages served by Ashna, users go where the role's "after login" setting says
 *   (profile, URL, wp-admin or the same page) unless a destination was requested.
 *
 * @package Ashna
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Ashna_Integration_UM {

	/**
	 * Statuses that cannot sign in, with the message shown.
	 */
	const BLOCKED = array(
		'inactive'                    => 'حساب کاربری شما غیرفعال شده است.',
		'awaiting_admin_review'       => 'حساب کاربری شما هنوز توسط مدیر سایت تأیید نشده است. پس از تأیید می‌توانید وارد شوید.',
		'awaiting_email_confirmation' => 'حساب کاربری شما در انتظار تأیید ایمیل است. لینک تأیید را در ایمیل خود باز کنید.',
		'rejected'                    => 'درخواست عضویت شما رد شده است.',
	);

	/**
	 * Whether Ultimate Member is active.
	 *
	 * @return bool
	 */
	public static function active() {
		return function_exists( 'UM' );
	}

	/**
	 * Register hooks (only with Ultimate Member).
	 */
	public static function boot() {
		if ( ! self::active() ) {
			return;
		}
		add_filter( 'ashna_otp_can_login', array( __CLASS__, 'gate' ), 10, 3 );
		add_action( 'ashna_otp_user_registered', array( __CLASS__, 'new_user_status' ), 10, 4 );
		add_filter( 'ashna_otp_default_redirect', array( __CLASS__, 'after_login_url' ), 10, 3 );
	}

	/**
	 * UM account status of a user.
	 *
	 * @param int $user_id User ID.
	 * @return string
	 */
	public static function status( $user_id ) {
		$users = self::users_api();
		if ( $users && method_exists( $users, 'get_status' ) ) {
			return (string) $users->get_status( $user_id );
		}
		return (string) get_user_meta( $user_id, 'account_status', true );
	}

	/**
	 * Refuse sign-ins UM would refuse.
	 *
	 * @param true|WP_Error $allowed Allowed so far.
	 * @param WP_User       $user    User.
	 * @param array         $context Sign-in context.
	 * @return true|WP_Error
	 */
	public static function gate( $allowed, $user, $context ) {
		if ( is_wp_error( $allowed ) ) {
			return $allowed;
		}
		$status = self::status( $user->ID );
		if ( 'awaiting_email_confirmation' === $status && self::otp_proved_email( $user, $context ) ) {
			self::approve( $user->ID );
			return $allowed;
		}
		if ( isset( self::BLOCKED[ $status ] ) ) {
			return new WP_Error( 'ashna_um_' . $status, self::BLOCKED[ $status ] );
		}
		return $allowed;
	}

	/**
	 * Give a new account the status of its role's registration setting.
	 *
	 * @param int    $user_id    New user.
	 * @param string $identifier Normalized phone/email.
	 * @param string $type       phone|email.
	 * @param array  $extra      Sign-up data.
	 */
	public static function new_user_status( $user_id, $identifier, $type, $extra ) {
		$registration_status = '';
		if ( function_exists( 'um_fetch_user' ) && function_exists( 'um_user' ) ) {
			um_fetch_user( $user_id );
			$registration_status = (string) um_user( 'status' );
		}
		if ( 'pending' === $registration_status ) {
			$users = self::users_api();
			if ( $users && method_exists( $users, 'set_as_pending' ) ) {
				$users->set_as_pending( $user_id, true );
			} else {
				update_user_meta( $user_id, 'account_status', 'awaiting_admin_review' );
			}
			return;
		}
		// approved, or checkmail: the one-time code already confirmed the phone/e-mail.
		self::approve( $user_id );
	}

	/**
	 * Where UM sends this role after login (only on UM login pages served by Ashna).
	 *
	 * @param string  $redirect Current destination.
	 * @param WP_User $user     User.
	 * @param array   $context  Sign-in context.
	 * @return string
	 */
	public static function after_login_url( $redirect, $user, $context ) {
		if ( empty( $context['form'] ) || 'member-ultimatemember' !== $context['form'] || ! function_exists( 'um_fetch_user' ) || ! function_exists( 'um_user' ) ) {
			return $redirect;
		}
		um_fetch_user( $user->ID );
		switch ( (string) um_user( 'after_login' ) ) {
			case 'redirect_admin':
				return admin_url();
			case 'redirect_url':
				$url = apply_filters( 'um_login_redirect_url', um_user( 'login_redirect_url' ), $user->ID );
				return is_string( $url ) && '' !== $url ? $url : $redirect;
			case 'refresh':
				return $redirect;
			default:
				return function_exists( 'um_user_profile_url' ) ? (string) um_user_profile_url( $user->ID ) : $redirect;
		}
	}

	/**
	 * Whether this sign-in was an OTP sent to the account's own e-mail.
	 *
	 * @param WP_User $user    User.
	 * @param array   $context Sign-in context.
	 * @return bool
	 */
	private static function otp_proved_email( $user, $context ) {
		return isset( $context['method'], $context['identifier'] ) && 'otp' === $context['method']
			&& is_email( $context['identifier'] ) && strtolower( $context['identifier'] ) === strtolower( $user->user_email );
	}

	/**
	 * Approve an account through UM (falls back to the status meta on old UM versions).
	 *
	 * @param int $user_id User ID.
	 */
	private static function approve( $user_id ) {
		$users = self::users_api();
		if ( $users && method_exists( $users, 'approve' ) ) {
			$users->approve( $user_id, true );
			return;
		}
		update_user_meta( $user_id, 'account_status', 'approved' );
	}

	/**
	 * UM()->common()->users() (UM 2.8.7+), or null.
	 *
	 * @return object|null
	 */
	private static function users_api() {
		$um = UM();
		if ( is_object( $um ) && method_exists( $um, 'common' ) ) {
			$common = $um->common();
			if ( is_object( $common ) && method_exists( $common, 'users' ) ) {
				return $common->users();
			}
		}
		return null;
	}
}


// ---- Source: includes/integrations/elementor/class-ashna-elementor.php ----
/**
 * Elementor Page Builder Native Integration
 *
 * Registers the "Ashna" Elementor category and native widgets:
 * 1. Ashna_Elementor_Login_Widget (Inline Login / Registration Card)
 * 2. Ashna_Elementor_Modal_Button_Widget (Header / Popup Trigger Button)
 *
 * @package Ashna
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class Ashna_Elementor {

	/**
	 * Singleton instance
	 *
	 * @var Ashna_Elementor|null
	 */
	private static $instance = null;

	/**
	 * Get instance
	 *
	 * @return Ashna_Elementor
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	/**
	 * Constructor
	 */
	private function __construct() {
		add_action( 'elementor/elements/categories_registered', array( $this, 'register_category' ) );

		// Elementor 3.5.0+ hook with fallback for older Elementor versions
		if ( version_compare( defined( 'ELEMENTOR_VERSION' ) ? ELEMENTOR_VERSION : '3.5.0', '3.5.0', '>=' ) ) {
			add_action( 'elementor/widgets/register', array( $this, 'register_widgets' ) );
		} else {
			add_action( 'elementor/widgets/widgets_registered', array( $this, 'register_widgets_legacy' ) );
		}

		add_action( 'elementor/preview/enqueue_styles', array( $this, 'enqueue_preview_assets' ) );
	}

	/**
	 * Register dedicated "Ashna" category in Elementor panel
	 *
	 * @param \Elementor\Elements_Manager $elements_manager Elementor elements manager.
	 */
	public function register_category( $elements_manager ) {
		if ( ! is_object( $elements_manager ) || ! method_exists( $elements_manager, 'add_category' ) ) {
			return;
		}

		$elements_manager->add_category(
			'ashna-otp',
			array(
				'title' => 'احراز هویت آشنا',
				'icon'  => 'eicon-lock-user',
			)
		);
	}

	/**
	 * Register widgets in Elementor 3.5+
	 *
	 * @param \Elementor\Widgets_Manager $widgets_manager Elementor widgets manager.
	 */
	public function register_widgets( $widgets_manager ) {
		if ( ! class_exists( '\Elementor\Widget_Base' ) ) {
			return;
		}

		require_once __DIR__ . '/integrations/elementor/class-ashna-elementor-login-widget.php';
		require_once __DIR__ . '/integrations/elementor/class-ashna-elementor-modal-button-widget.php';

		$widgets_manager->register( new Ashna_Elementor_Login_Widget() );
		$widgets_manager->register( new Ashna_Elementor_Modal_Button_Widget() );
	}

	/**
	 * Register widgets in legacy Elementor (< 3.5)
	 */
	public function register_widgets_legacy() {
		if ( ! class_exists( '\Elementor\Plugin' ) || ! class_exists( '\Elementor\Widget_Base' ) ) {
			return;
		}

		require_once __DIR__ . '/integrations/elementor/class-ashna-elementor-login-widget.php';
		require_once __DIR__ . '/integrations/elementor/class-ashna-elementor-modal-button-widget.php';

		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Ashna_Elementor_Login_Widget() );
		\Elementor\Plugin::instance()->widgets_manager->register_widget_type( new Ashna_Elementor_Modal_Button_Widget() );
	}

	/**
	 * Ensure Ashna frontend CSS is always loaded inside Elementor live preview iframe
	 */
	public function enqueue_preview_assets() {
		Ashna_Frontend::instance()->enqueue_assets( true );
	}

	/**
	 * Helper: Check if we are currently inside Elementor's editor or preview mode
	 *
	 * @return bool
	 */
	public static function is_editor_or_preview() {
		if ( ! class_exists( '\Elementor\Plugin' ) ) {
			return false;
		}

		$plugin = \Elementor\Plugin::$instance;
		if ( isset( $plugin->editor ) && method_exists( $plugin->editor, 'is_edit_mode' ) && $plugin->editor->is_edit_mode() ) {
			return true;
		}
		if ( isset( $plugin->preview ) && method_exists( $plugin->preview, 'is_preview_mode' ) && $plugin->preview->is_preview_mode() ) {
			return true;
		}

		return false;
	}
}


				}
			}
		}
	} catch (\ReflectionException $e) {
		// بررسی لایسنس ناموفق بود.
	}
}

// ----------------------------------------------------------------------------------------------------- End RTL License
